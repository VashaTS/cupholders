# Chase Game (Lazarus / Free Pascal)

A small 2D survival game: stay on the white floor of a bitmap map, keep away
from NPCs as long as you can. Score is time survived.

## Open and run

1. Install [Lazarus](https://www.lazarus-ide.org/) (with Free Pascal).
2. Open `ChaseGame.lpi`.
3. Run (`F9`).

The first build creates `ChaseGame` / `ChaseGame.exe` in the project folder.
Keep the `data` folder next to the executable (it already sits next to the
project file).

Needed package: **LCL** only. JPEG/PNG loading is built into modern Lazarus
(`Graphics` / `TPicture`). Older docs mention `lazjpeg` / `lazpng`; those are
not separate downloads anymore. If the IDE still asks for extra image support,
add the bundled package **ImagesForLazarus** (Project Inspector → Add →
New requirement), or just use the `.bmp` copies in `data/sprites/`.

## Controls

| Key | Action |
|-----|--------|
| WASD or arrows | Move |
| Space / Enter | Start or play again |
| Enter (on name box) | Save high score |
| Esc | Back to menu, or quit from the menu |

## How a map works

A map is a pair of files with the **same name** in `data/maps/`:

- `level1.bmp` — the picture used both as the background and as collision.
- `level1.ini` — spawn points and rules.

**Collision rule:** a pixel the player or an NPC can stand on is **white**
(R, G and B all ≥ 220). Any other colour is a wall.

### `level1.ini` layout

```ini
[Map]
File=level1.bmp
Title=Warehouse

[PlayerSpawns]
Count=10
1=36,36
2=444,36

[NPCSpawns]
Count=6
1=240,40
2=40,180

[Gameplay]
ChaseDistance=110
FastDistance=46
WanderSpeed=1.35
ChaseSpeed=2.15
FastSpeed=3.25
PlayerSpeed=2.70
CatchDistance=24
NPCSpawnInterval=12
MaxNPCs=4
PointsPerSecond=10
SpriteRadius=13
WanderTurnMin=0.6
WanderTurnMax=1.8
```

Coordinates are **pixels in the bitmap**, at the centre of the actor.

- The player starts on a **random** entry from `[PlayerSpawns]`.
- The first NPC starts on an `[NPCSpawns]` point far from the player.
- Every `NPCSpawnInterval` seconds another NPC appears, up to `MaxNPCs`.

## NPC behaviour

1. Wander in a random direction, picking a new heading now and then.
2. If the player is closer than `ChaseDistance`, turn toward the player.
3. If closer than `FastDistance`, use `FastSpeed`.
4. If the centre-to-centre distance is ≤ `CatchDistance` → game over.

Ring colour: purple = wandering, orange = chasing, red = sprinting.

## Sprites (drawn as circles)

Put files in `data/sprites/`:

- Player: `player1.jpg`, `player2.jpg`, … (png/bmp also accepted)
- NPCs: `npc1.jpg`, `npc2.jpg`, …

At the start of a run the player image is chosen at random from every
`player*` file. Extra NPCs cycle through `npc1`, `npc2`, …

## High scores

Top 10 scores are stored in `data/highscores.ini`. If a run beats the board,
you are asked for a name before the game-over screen.

## Adding another map

1. Paint a bitmap. White corridors must be wide enough for `SpriteRadius`
   (about 30+ pixels of white).
2. Save it as `data/maps/mymap.bmp`.
3. Copy `level1.ini` to `data/maps/mymap.ini`, point `File=` at the bitmap,
   and list spawn coordinates that sit on white pixels.
4. Restart the game and pick the map from the list.

## Project layout

```
ChaseGame/
  ChaseGame.lpi
  ChaseGame.lpr
  src/uMain.pas        form, input, overlays
  src/uGame.pas        map, movement, AI, drawing
  src/uHighScore.pas
  data/maps/
  data/sprites/
```

All UI is created in code (no `.lfm`), so the project opens cleanly on any
Lazarus widgetset (Win32, Qt, GTK).
