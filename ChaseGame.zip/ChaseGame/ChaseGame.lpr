program ChaseGame;

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  {$ENDIF}
  Interfaces,
  Forms,
  uMain;

{$R *.res}

begin
  RequireDerivedFormResource := False;
  Application.Title := 'Chase Game';
  Application.Initialize;
  Application.Scaled := True;
  { CreateForm registers the window as Application.MainForm.
    A plain TForm.Create + Run leaves a process with no visible window. }
  Application.CreateForm(TGameForm, GameForm);
  GameForm.Show;
  GameForm.BringToFront;
  Application.Run;
end.
