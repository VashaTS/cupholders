program ChaseGame;

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  {$ENDIF}
  Interfaces,
  Forms,
  uMain;

{$R *.res}

begin
  RequireDerivedFormResource := False;
  Application.Scaled := True;
  Application.Title := 'Chase Game';
  Application.Initialize;
  GameForm := TGameForm.Create(Application);
  Application.Run;
end.
