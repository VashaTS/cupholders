unit uGame;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Graphics, Types, Math, IniFiles, FileUtil;

type
  TGameState = (gsMenu, gsPlaying, gsGameOver, gsEnterName);

  TPointF = record
    X, Y: Double;
  end;

  TEntity = record
    Pos: TPointF;
    Radius: Double;
    Sprite: TBitmap;
    Alive: Boolean;
    Angle: Double;
    Speed: Double;
    WanderTimer: Double;
    IsChasing: Boolean;
    IsFast: Boolean;
  end;

  TSpawn = record
    X, Y: Integer;
  end;

  { TChaseGame }

  TChaseGame = class
  private
    FMap: TBitmap;
    FWalk: array of array of Boolean;
    FMapW, FMapH: Integer;
    FPlayerSpawns: array of TSpawn;
    FNpcSpawns: array of TSpawn;
    FPlayerSprites: array of TBitmap;
    FNpcSprites: array of TBitmap;
    FPlayer: TEntity;
    FNpcs: array of TEntity;
    FNpcCount: Integer;
    FState: TGameState;
    FElapsed: Double;
    FScore: Integer;
    FNextNpcAt: Double;
    FMapTitle: string;
    FMapIniPath: string;
    FSpriteDir: string;
    FCaughtBy: Integer;
    FFlash: Double;
    function IsWhiteWalkable(C: TColor): Boolean;
    procedure BuildWalkGrid;
    procedure ClearSprites(var Arr: array of TBitmap);
    procedure LoadSpriteFolder;
    function MakeCircleSprite(Src: TBitmap; Diameter: Integer): TBitmap;
    function CanOccupy(const X, Y, Radius: Double): Boolean;
    function TryMove(var E: TEntity; DX, DY: Double): Boolean;
    procedure ResetEntity(var E: TEntity);
    procedure SpawnPlayer;
    procedure SpawnNpc;
    procedure UpdatePlayer(DT: Double; MoveX, MoveY: Integer);
    procedure UpdateNpc(var N: TEntity; DT: Double);
    function DistToPlayer(const E: TEntity): Double;
    function FarthestNpcSpawn: TSpawn;
  public
    ChaseDistance: Double;
    FastDistance: Double;
    WanderSpeed: Double;
    ChaseSpeed: Double;
    FastSpeed: Double;
    PlayerSpeed: Double;
    CatchDistance: Double;
    NPCSpawnInterval: Double;
    MaxNPCs: Integer;
    PointsPerSecond: Integer;
    SpriteRadius: Integer;
    WanderTurnMin: Double;
    WanderTurnMax: Double;

    constructor Create;
    destructor Destroy; override;
    procedure LoadMap(const IniPath: string);
    procedure NewGame;
    procedure Update(DT: Double; MoveX, MoveY: Integer);
    procedure Draw(Dest: TCanvas; const DestRect: TRect);
    function WorldToScreen(const P: TPointF; const DestRect: TRect): TPoint;
    function ScreenScale(const DestRect: TRect): Double;

    property State: TGameState read FState write FState;
    property Score: Integer read FScore;
    property Elapsed: Double read FElapsed;
    property NpcCount: Integer read FNpcCount;
    property MapTitle: string read FMapTitle;
    property MapWidth: Integer read FMapW;
    property MapHeight: Integer read FMapH;
    property MapIniPath: string read FMapIniPath;
    property CaughtBy: Integer read FCaughtBy;
  end;

function FindDataRoot: string;
function MapsDir: string;
function SpritesDir: string;

implementation

uses
  Forms, LCLIntf, LCLType;

function FindDataRoot: string;
var
  Candidates: array[0..5] of string;
  I: Integer;
begin
  Candidates[0] := IncludeTrailingPathDelimiter(ExtractFilePath(ParamStr(0))) + 'data';
  Candidates[1] := IncludeTrailingPathDelimiter(GetCurrentDir) + 'data';
  Candidates[2] := IncludeTrailingPathDelimiter(ExtractFilePath(ParamStr(0))) +
    '..' + PathDelim + 'data';
  Candidates[3] := IncludeTrailingPathDelimiter(ExtractFilePath(ParamStr(0))) +
    '..' + PathDelim + '..' + PathDelim + 'data';
  {$IFDEF DARWIN}
  Candidates[4] := IncludeTrailingPathDelimiter(ExtractFilePath(ParamStr(0))) +
    '..' + PathDelim + 'Resources' + PathDelim + 'data';
  {$ELSE}
  Candidates[4] := Candidates[0];
  {$ENDIF}
  Candidates[5] := IncludeTrailingPathDelimiter(ExtractFilePath(ParamStr(0))) +
    'ChaseGame' + PathDelim + 'data';

  for I := Low(Candidates) to High(Candidates) do
  begin
    Result := ExpandFileName(Candidates[I]);
    if DirectoryExists(Result) and
       DirectoryExists(IncludeTrailingPathDelimiter(Result) + 'maps') then
      Exit;
  end;
  Result := ExpandFileName(Candidates[0]);
end;

function MapsDir: string;
begin
  Result := IncludeTrailingPathDelimiter(FindDataRoot) + 'maps';
end;

function SpritesDir: string;
begin
  Result := IncludeTrailingPathDelimiter(FindDataRoot) + 'sprites';
end;

function MakePointF(X, Y: Double): TPointF;
begin
  Result.X := X;
  Result.Y := Y;
end;

procedure CollectUniqueSprites(const Dir, Prefix: string; Sl: TStringList);
var
  Raw: TStringList;
  Chosen: TStringList;
  I, Idx: Integer;
  Base, Ext, Path, PrevExt: string;

  function Rank(const E: string): Integer;
  begin
    if E = '.jpg' then Exit(0);
    if E = '.jpeg' then Exit(1);
    if E = '.png' then Exit(2);
    Result := 3;
  end;

  procedure ScanMask(const Mask: string);
  begin
    FindAllFiles(Raw, Dir, Mask, False);
  end;

begin
  Sl.Clear;
  Raw := TStringList.Create;
  Chosen := TStringList.Create;
  try
    Chosen.Sorted := False;
    Chosen.NameValueSeparator := '=';
    ScanMask(Prefix + '*.jpg');
    ScanMask(Prefix + '*.jpeg');
    ScanMask(Prefix + '*.png');
    ScanMask(Prefix + '*.bmp');
    for I := 0 to Raw.Count - 1 do
    begin
      Path := Raw[I];
      Base := LowerCase(ChangeFileExt(ExtractFileName(Path), ''));
      Ext := LowerCase(ExtractFileExt(Path));
      Idx := Chosen.IndexOfName(Base);
      if Idx < 0 then
        Chosen.Add(Base + '=' + Path)
      else
      begin
        PrevExt := LowerCase(ExtractFileExt(Chosen.ValueFromIndex[Idx]));
        if Rank(Ext) < Rank(PrevExt) then
          Chosen.Strings[Idx] := Base + '=' + Path;
      end;
    end;
    for I := 0 to Chosen.Count - 1 do
      Sl.Add(Chosen.ValueFromIndex[I]);
    Sl.Sort;
  finally
    Chosen.Free;
    Raw.Free;
  end;
end;

{ TChaseGame }

constructor TChaseGame.Create;
begin
  inherited Create;
  FMap := TBitmap.Create;
  FState := gsMenu;
  FSpriteDir := SpritesDir;
  ChaseDistance := 110;
  FastDistance := 46;
  WanderSpeed := 1.35;
  ChaseSpeed := 2.15;
  FastSpeed := 3.25;
  PlayerSpeed := 2.70;
  CatchDistance := 24;
  NPCSpawnInterval := 12;
  MaxNPCs := 4;
  PointsPerSecond := 10;
  SpriteRadius := 13;
  WanderTurnMin := 0.6;
  WanderTurnMax := 1.8;
  LoadSpriteFolder;
end;

destructor TChaseGame.Destroy;
begin
  ClearSprites(FPlayerSprites);
  ClearSprites(FNpcSprites);
  FMap.Free;
  inherited Destroy;
end;

procedure TChaseGame.ClearSprites(var Arr: array of TBitmap);
var
  I: Integer;
begin
  for I := Low(Arr) to High(Arr) do
  begin
    Arr[I].Free;
    Arr[I] := nil;
  end;
end;

procedure TChaseGame.LoadSpriteFolder;
var
  Sl: TStringList;
  I: Integer;
  Pic: TPicture;
  B: TBitmap;
begin
  ClearSprites(FPlayerSprites);
  ClearSprites(FNpcSprites);
  SetLength(FPlayerSprites, 0);
  SetLength(FNpcSprites, 0);
  FSpriteDir := SpritesDir;
  Sl := TStringList.Create;
  Pic := TPicture.Create;
  try
    if DirectoryExists(FSpriteDir) then
    begin
      CollectUniqueSprites(FSpriteDir, 'player', Sl);
      SetLength(FPlayerSprites, Sl.Count);
      for I := 0 to Sl.Count - 1 do
      begin
        Pic.LoadFromFile(Sl[I]);
        B := TBitmap.Create;
        B.Assign(Pic.Graphic);
        FPlayerSprites[I] := B;
      end;
      CollectUniqueSprites(FSpriteDir, 'npc', Sl);
      SetLength(FNpcSprites, Sl.Count);
      for I := 0 to Sl.Count - 1 do
      begin
        Pic.LoadFromFile(Sl[I]);
        B := TBitmap.Create;
        B.Assign(Pic.Graphic);
        FNpcSprites[I] := B;
      end;
    end;
  finally
    Pic.Free;
    Sl.Free;
  end;
end;

function TChaseGame.IsWhiteWalkable(C: TColor): Boolean;
var
  R, G, B: Byte;
begin
  R := Red(C);
  G := Green(C);
  B := Blue(C);
  Result := (R >= 220) and (G >= 220) and (B >= 220);
end;

procedure TChaseGame.BuildWalkGrid;
var
  X, Y: Integer;
begin
  FMapW := FMap.Width;
  FMapH := FMap.Height;
  SetLength(FWalk, FMapW, FMapH);
  for Y := 0 to FMapH - 1 do
    for X := 0 to FMapW - 1 do
      FWalk[X, Y] := IsWhiteWalkable(FMap.Canvas.Pixels[X, Y]);
end;

procedure TChaseGame.LoadMap(const IniPath: string);
var
  Ini: TIniFile;
  MapFile, Base: string;
  I, N, P: Integer;
  S: string;
  Pic: TPicture;
begin
  FMapIniPath := IniPath;
  Base := ExtractFilePath(IniPath);
  Ini := TIniFile.Create(IniPath);
  Pic := TPicture.Create;
  try
    MapFile := Ini.ReadString('Map', 'File', ChangeFileExt(ExtractFileName(IniPath), '.bmp'));
    if not FileExists(MapFile) then
      MapFile := Base + MapFile;
    if not FileExists(MapFile) then
      raise Exception.Create('Map bitmap not found: ' + MapFile);
    Pic.LoadFromFile(MapFile);
    FMap.Assign(Pic.Graphic);
    FMap.PixelFormat := pf24bit;
    FMapTitle := Ini.ReadString('Map', 'Title', ChangeFileExt(ExtractFileName(IniPath), ''));

    N := Ini.ReadInteger('PlayerSpawns', 'Count', 0);
    SetLength(FPlayerSpawns, N);
    for I := 1 to N do
    begin
      S := Ini.ReadString('PlayerSpawns', IntToStr(I), '');
      P := Pos(',', S);
      if P > 0 then
      begin
        FPlayerSpawns[I - 1].X := StrToIntDef(Trim(Copy(S, 1, P - 1)), 0);
        FPlayerSpawns[I - 1].Y := StrToIntDef(Trim(Copy(S, P + 1, MaxInt)), 0);
      end;
    end;

    N := Ini.ReadInteger('NPCSpawns', 'Count', 0);
    SetLength(FNpcSpawns, N);
    for I := 1 to N do
    begin
      S := Ini.ReadString('NPCSpawns', IntToStr(I), '');
      P := Pos(',', S);
      if P > 0 then
      begin
        FNpcSpawns[I - 1].X := StrToIntDef(Trim(Copy(S, 1, P - 1)), 0);
        FNpcSpawns[I - 1].Y := StrToIntDef(Trim(Copy(S, P + 1, MaxInt)), 0);
      end;
    end;

    ChaseDistance := Ini.ReadFloat('Gameplay', 'ChaseDistance', ChaseDistance);
    FastDistance := Ini.ReadFloat('Gameplay', 'FastDistance', FastDistance);
    WanderSpeed := Ini.ReadFloat('Gameplay', 'WanderSpeed', WanderSpeed);
    ChaseSpeed := Ini.ReadFloat('Gameplay', 'ChaseSpeed', ChaseSpeed);
    FastSpeed := Ini.ReadFloat('Gameplay', 'FastSpeed', FastSpeed);
    PlayerSpeed := Ini.ReadFloat('Gameplay', 'PlayerSpeed', PlayerSpeed);
    CatchDistance := Ini.ReadFloat('Gameplay', 'CatchDistance', CatchDistance);
    NPCSpawnInterval := Ini.ReadFloat('Gameplay', 'NPCSpawnInterval', NPCSpawnInterval);
    MaxNPCs := Ini.ReadInteger('Gameplay', 'MaxNPCs', MaxNPCs);
    PointsPerSecond := Ini.ReadInteger('Gameplay', 'PointsPerSecond', PointsPerSecond);
    SpriteRadius := Ini.ReadInteger('Gameplay', 'SpriteRadius', SpriteRadius);
    WanderTurnMin := Ini.ReadFloat('Gameplay', 'WanderTurnMin', WanderTurnMin);
    WanderTurnMax := Ini.ReadFloat('Gameplay', 'WanderTurnMax', WanderTurnMax);
  finally
    Pic.Free;
    Ini.Free;
  end;
  BuildWalkGrid;
end;

function TChaseGame.MakeCircleSprite(Src: TBitmap; Diameter: Integer): TBitmap;
var
  Tmp: TBitmap;
  X, Y, R, CX, CY, DX, DY: Integer;
  Magenta: TColor;
begin
  Result := TBitmap.Create;
  Result.SetSize(Diameter, Diameter);
  Result.PixelFormat := pf24bit;
  Magenta := RGBToColor(255, 0, 255);
  Result.Transparent := True;
  Result.TransparentColor := Magenta;
  Result.Canvas.Brush.Color := Magenta;
  Result.Canvas.FillRect(0, 0, Diameter, Diameter);
  Result.Canvas.StretchDraw(Rect(0, 0, Diameter, Diameter), Src);

  CX := Diameter div 2;
  CY := Diameter div 2;
  R := Diameter div 2 - 1;
  for Y := 0 to Diameter - 1 do
    for X := 0 to Diameter - 1 do
    begin
      DX := X - CX;
      DY := Y - CY;
      if DX * DX + DY * DY > R * R then
        Result.Canvas.Pixels[X, Y] := Magenta;
    end;
end;

function TChaseGame.CanOccupy(const X, Y, Radius: Double): Boolean;
  function WalkAt(IX, IY: Integer): Boolean;
  begin
    if (IX < 0) or (IY < 0) or (IX >= FMapW) or (IY >= FMapH) then
      Exit(False);
    Result := FWalk[IX, IY];
  end;

var
  I, Samples: Integer;
  A, RR: Double;
begin
  if not WalkAt(Round(X), Round(Y)) then
    Exit(False);
  RR := Radius * 0.85;
  Samples := 12;
  for I := 0 to Samples - 1 do
  begin
    A := I * 2 * Pi / Samples;
    if not WalkAt(Round(X + Cos(A) * RR), Round(Y + Sin(A) * RR)) then
      Exit(False);
  end;
  Result := True;
end;

function TChaseGame.TryMove(var E: TEntity; DX, DY: Double): Boolean;
var
  NX, NY: Double;
begin
  Result := False;
  NX := E.Pos.X + DX;
  NY := E.Pos.Y + DY;
  if CanOccupy(NX, NY, E.Radius) then
  begin
    E.Pos.X := NX;
    E.Pos.Y := NY;
    Exit(True);
  end;
  if CanOccupy(NX, E.Pos.Y, E.Radius) then
  begin
    E.Pos.X := NX;
    Exit(True);
  end;
  if CanOccupy(E.Pos.X, NY, E.Radius) then
  begin
    E.Pos.Y := NY;
    Exit(True);
  end;
end;

procedure TChaseGame.ResetEntity(var E: TEntity);
begin
  E.Pos := MakePointF(0, 0);
  E.Radius := SpriteRadius;
  E.Sprite := nil;
  E.Alive := False;
  E.Angle := Random * 2 * Pi;
  E.Speed := WanderSpeed;
  E.WanderTimer := 0;
  E.IsChasing := False;
  E.IsFast := False;
end;

procedure TChaseGame.SpawnPlayer;
var
  I: Integer;
  S: TSpawn;
begin
  ResetEntity(FPlayer);
  FPlayer.Alive := True;
  FPlayer.Radius := SpriteRadius;
  FPlayer.Speed := PlayerSpeed;
  if Length(FPlayerSprites) > 0 then
    FPlayer.Sprite := FPlayerSprites[Random(Length(FPlayerSprites))]
  else
    FPlayer.Sprite := nil;

  if Length(FPlayerSpawns) > 0 then
  begin
    S := FPlayerSpawns[Random(Length(FPlayerSpawns))];
    FPlayer.Pos := MakePointF(S.X, S.Y);
  end
  else
    FPlayer.Pos := MakePointF(FMapW / 2, FMapH / 2);

  if not CanOccupy(FPlayer.Pos.X, FPlayer.Pos.Y, FPlayer.Radius) then
    for I := 0 to High(FPlayerSpawns) do
      if CanOccupy(FPlayerSpawns[I].X, FPlayerSpawns[I].Y, FPlayer.Radius) then
      begin
        FPlayer.Pos := MakePointF(FPlayerSpawns[I].X, FPlayerSpawns[I].Y);
        Break;
      end;
end;

function TChaseGame.FarthestNpcSpawn: TSpawn;
var
  I, J: Integer;
  BestD, D, NearD: Double;
  Blocked: Boolean;
begin
  Result.X := FMapW div 2;
  Result.Y := FMapH div 2;
  BestD := -1;
  for I := 0 to High(FNpcSpawns) do
  begin
    if not CanOccupy(FNpcSpawns[I].X, FNpcSpawns[I].Y, SpriteRadius) then
      Continue;
    D := Hypot(FNpcSpawns[I].X - FPlayer.Pos.X, FNpcSpawns[I].Y - FPlayer.Pos.Y);
    NearD := 1e9;
    for J := 0 to FNpcCount - 1 do
      if FNpcs[J].Alive then
        NearD := Min(NearD, Hypot(FNpcSpawns[I].X - FNpcs[J].Pos.X,
          FNpcSpawns[I].Y - FNpcs[J].Pos.Y));
    if NearD < SpriteRadius * 3 then
      Continue;
    if D > BestD then
    begin
      BestD := D;
      Result := FNpcSpawns[I];
    end;
    Blocked := False;
    if Blocked then ;
  end;
  if BestD < 0 then
    if Length(FNpcSpawns) > 0 then
      Result := FNpcSpawns[0];
end;

procedure TChaseGame.SpawnNpc;
var
  S: TSpawn;
  N: Integer;
begin
  if FNpcCount >= MaxNPCs then
    Exit;
  if Length(FNpcSpawns) = 0 then
    Exit;
  N := FNpcCount;
  SetLength(FNpcs, N + 1);
  ResetEntity(FNpcs[N]);
  S := FarthestNpcSpawn;
  FNpcs[N].Pos := MakePointF(S.X, S.Y);
  FNpcs[N].Alive := True;
  FNpcs[N].Radius := SpriteRadius;
  FNpcs[N].Angle := Random * 2 * Pi;
  FNpcs[N].WanderTimer := WanderTurnMin + Random * (WanderTurnMax - WanderTurnMin);
  if Length(FNpcSprites) > 0 then
    FNpcs[N].Sprite := FNpcSprites[N mod Length(FNpcSprites)]
  else
    FNpcs[N].Sprite := nil;
  Inc(FNpcCount);
  FFlash := 0.35;
end;

procedure TChaseGame.NewGame;
begin
  if FMapW = 0 then
    raise Exception.Create('No map loaded');
  FElapsed := 0;
  FScore := 0;
  FNpcCount := 0;
  SetLength(FNpcs, 0);
  FCaughtBy := -1;
  FFlash := 0;
  FNextNpcAt := NPCSpawnInterval;
  SpawnPlayer;
  SpawnNpc;
  FState := gsPlaying;
end;

function TChaseGame.DistToPlayer(const E: TEntity): Double;
begin
  Result := Hypot(E.Pos.X - FPlayer.Pos.X, E.Pos.Y - FPlayer.Pos.Y);
end;

procedure TChaseGame.UpdatePlayer(DT: Double; MoveX, MoveY: Integer);
var
  Len, VX, VY: Double;
begin
  if (MoveX = 0) and (MoveY = 0) then
    Exit;
  Len := Hypot(MoveX, MoveY);
  VX := (MoveX / Len) * PlayerSpeed * DT * 60.0;
  VY := (MoveY / Len) * PlayerSpeed * DT * 60.0;
  TryMove(FPlayer, VX, VY);
end;

procedure TChaseGame.UpdateNpc(var N: TEntity; DT: Double);
var
  D, VX, VY: Double;
  Tries: Integer;
begin
  D := DistToPlayer(N);
  N.IsFast := D <= FastDistance;
  N.IsChasing := D <= ChaseDistance;
  if N.IsFast then
    N.Speed := FastSpeed
  else if N.IsChasing then
    N.Speed := ChaseSpeed
  else
    N.Speed := WanderSpeed;

  if N.IsChasing then
    N.Angle := ArcTan2(FPlayer.Pos.Y - N.Pos.Y, FPlayer.Pos.X - N.Pos.X)
  else
  begin
    N.WanderTimer := N.WanderTimer - DT;
    if N.WanderTimer <= 0 then
    begin
      N.Angle := Random * 2 * Pi;
      N.WanderTimer := WanderTurnMin + Random * (WanderTurnMax - WanderTurnMin);
    end;
  end;

  VX := Cos(N.Angle) * N.Speed * DT * 60.0;
  VY := Sin(N.Angle) * N.Speed * DT * 60.0;
  if not TryMove(N, VX, VY) then
  begin
    Tries := 0;
    repeat
      N.Angle := Random * 2 * Pi;
      VX := Cos(N.Angle) * N.Speed * DT * 60.0;
      VY := Sin(N.Angle) * N.Speed * DT * 60.0;
      Inc(Tries);
    until TryMove(N, VX, VY) or (Tries > 10);
    N.WanderTimer := WanderTurnMin;
  end;
end;

procedure TChaseGame.Update(DT: Double; MoveX, MoveY: Integer);
var
  I: Integer;
begin
  if FState <> gsPlaying then
    Exit;
  if DT > 0.05 then
    DT := 0.05;

  FElapsed := FElapsed + DT;
  FScore := Trunc(FElapsed * PointsPerSecond);
  if FFlash > 0 then
    FFlash := FFlash - DT;

  UpdatePlayer(DT, MoveX, MoveY);

  if (FNpcCount < MaxNPCs) and (FElapsed >= FNextNpcAt) then
  begin
    SpawnNpc;
    FNextNpcAt := FNextNpcAt + NPCSpawnInterval;
  end;

  for I := 0 to FNpcCount - 1 do
    if FNpcs[I].Alive then
    begin
      UpdateNpc(FNpcs[I], DT);
      if DistToPlayer(FNpcs[I]) <= CatchDistance then
      begin
        FCaughtBy := I;
        FState := gsGameOver;
        Exit;
      end;
    end;
end;

function TChaseGame.ScreenScale(const DestRect: TRect): Double;
var
  SX, SY: Double;
begin
  if (FMapW <= 0) or (FMapH <= 0) then
    Exit(1);
  SX := (DestRect.Right - DestRect.Left) / FMapW;
  SY := (DestRect.Bottom - DestRect.Top) / FMapH;
  Result := Min(SX, SY);
end;

function TChaseGame.WorldToScreen(const P: TPointF; const DestRect: TRect): TPoint;
var
  S: Double;
begin
  S := ScreenScale(DestRect);
  Result.X := DestRect.Left + Round(P.X * S);
  Result.Y := DestRect.Top + Round(P.Y * S);
end;

procedure TChaseGame.Draw(Dest: TCanvas; const DestRect: TRect);
var
  S: Double;
  MapR: TRect;
  I, RX: Integer;
  PT: TPoint;
  Outline: TColor;

  procedure DrawEntity(const E: TEntity; Ring: TColor);
  var
    C: TBitmap;
    P: TPoint;
    D: Integer;
  begin
    if not E.Alive then
      Exit;
    P := WorldToScreen(E.Pos, DestRect);
    D := Max(8, Round(E.Radius * 2 * S));
    Dest.Pen.Width := 2;
    Dest.Pen.Color := Ring;
    Dest.Brush.Style := bsClear;
    if E.Sprite <> nil then
    begin
      C := MakeCircleSprite(E.Sprite, D);
      try
        Dest.Draw(P.X - D div 2, P.Y - D div 2, C);
      finally
        C.Free;
      end;
    end
    else
    begin
      Dest.Brush.Style := bsSolid;
      Dest.Brush.Color := Ring;
      Dest.Ellipse(P.X - D div 2, P.Y - D div 2, P.X + D div 2, P.Y + D div 2);
    end;
    Dest.Brush.Style := bsClear;
    Dest.Pen.Color := Ring;
    Dest.Pen.Width := 2;
    Dest.Ellipse(P.X - D div 2, P.Y - D div 2, P.X + D div 2, P.Y + D div 2);
  end;

begin
  Dest.Brush.Color := RGBToColor(18, 14, 24);
  Dest.FillRect(DestRect);
  if FMapW <= 0 then
    Exit;
  S := ScreenScale(DestRect);
  MapR := Rect(DestRect.Left, DestRect.Top,
    DestRect.Left + Round(FMapW * S),
    DestRect.Top + Round(FMapH * S));
  Dest.StretchDraw(MapR, FMap);

  for I := 0 to FNpcCount - 1 do
  begin
    if FNpcs[I].IsFast then
      Outline := RGBToColor(255, 70, 70)
    else if FNpcs[I].IsChasing then
      Outline := RGBToColor(255, 170, 40)
    else
      Outline := RGBToColor(180, 80, 200);
    DrawEntity(FNpcs[I], Outline);
  end;
  DrawEntity(FPlayer, RGBToColor(80, 200, 255));

  if (FFlash > 0) and (FState = gsPlaying) then
  begin
    Dest.Brush.Style := bsClear;
    Dest.Pen.Color := RGBToColor(255, 230, 80);
    Dest.Pen.Width := 3;
    I := FNpcCount - 1;
    if (I >= 0) and FNpcs[I].Alive then
    begin
      PT := WorldToScreen(FNpcs[I].Pos, DestRect);
      RX := Round((SpriteRadius * 2 * S) + 10 + FFlash * 30);
      Dest.Ellipse(PT.X - RX, PT.Y - RX, PT.X + RX, PT.Y + RX);
    end;
  end;
end;

end.
