unit uMain;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  LCLType, LCLIntf, Types, FileUtil, uGame, uHighScore;

type
  { TGameForm }

  TGameForm = class(TForm)
  private
    FGame: TChaseGame;
    FScores: THighScores;
    FTimer: TTimer;
    FPaint: TPaintBox;
    FBuffer: TBitmap;
    FHud: TPanel;
    FLblScore: TLabel;
    FLblTime: TLabel;
    FLblNpcs: TLabel;
    FLblBest: TLabel;
    FLblMap: TLabel;
    FBtnStart: TButton;
    FCmbMap: TComboBox;
    FEdtName: TEdit;
    FKeys: set of Byte;
    FLastTick: QWord;
    procedure BuildUI;
    procedure CollectMaps;
    procedure LoadSelectedMap;
    procedure StartClicked(Sender: TObject);
    procedure MapChanged(Sender: TObject);
    procedure Tick(Sender: TObject);
    procedure PaintGame(Sender: TObject);
    procedure FormResized(Sender: TObject);
    procedure KeyDownEvt(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure KeyUpEvt(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure NameSubmit(Sender: TObject);
    procedure DrawOverlay(C: TCanvas; const R: TRect);
    procedure RefreshHud;
    function MoveVector(out MX, MY: Integer): Boolean;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
  end;

var
  GameForm: TGameForm;

implementation

{ TGameForm }

constructor TGameForm.Create(AOwner: TComponent);
begin
  inherited CreateNew(AOwner);
  Caption := 'Chase Game';
  Color := RGBToColor(16, 12, 22);
  Position := poScreenCenter;
  Width := 980;
  Height := 740;
  KeyPreview := True;
  Constraints.MinWidth := 720;
  Constraints.MinHeight := 520;
  DoubleBuffered := True;

  FGame := TChaseGame.Create;
  FScores := THighScores.Create(IncludeTrailingPathDelimiter(FindDataRoot) + 'highscores.ini');
  FScores.Load;
  FBuffer := TBitmap.Create;
  FKeys := [];

  BuildUI;
  CollectMaps;
  LoadSelectedMap;

  OnKeyDown := @KeyDownEvt;
  OnKeyUp := @KeyUpEvt;
  OnResize := @FormResized;

  FTimer := TTimer.Create(Self);
  FTimer.Interval := 16;
  FTimer.OnTimer := @Tick;
  FTimer.Enabled := True;
  FLastTick := GetTickCount64;
end;

destructor TGameForm.Destroy;
begin
  FTimer.Enabled := False;
  FGame.Free;
  FScores.Free;
  FBuffer.Free;
  inherited Destroy;
end;

procedure TGameForm.BuildUI;
begin
  FHud := TPanel.Create(Self);
  FHud.Parent := Self;
  FHud.Align := alTop;
  FHud.Height := 56;
  FHud.BevelOuter := bvNone;
  FHud.Color := RGBToColor(28, 22, 40);
  FHud.ParentBackground := False;

  FLblMap := TLabel.Create(Self);
  FLblMap.Parent := FHud;
  FLblMap.Left := 12;
  FLblMap.Top := 8;
  FLblMap.Font.Color := RGBToColor(220, 210, 255);
  FLblMap.Caption := 'Map';

  FCmbMap := TComboBox.Create(Self);
  FCmbMap.Parent := FHud;
  FCmbMap.Left := 12;
  FCmbMap.Top := 26;
  FCmbMap.Width := 180;
  FCmbMap.Style := csDropDownList;
  FCmbMap.OnChange := @MapChanged;

  FLblScore := TLabel.Create(Self);
  FLblScore.Parent := FHud;
  FLblScore.Left := 210;
  FLblScore.Top := 18;
  FLblScore.Font.Size := 14;
  FLblScore.Font.Style := [fsBold];
  FLblScore.Font.Color := clWhite;
  FLblScore.Caption := 'Score  0';

  FLblTime := TLabel.Create(Self);
  FLblTime.Parent := FHud;
  FLblTime.Left := 360;
  FLblTime.Top := 18;
  FLblTime.Font.Size := 12;
  FLblTime.Font.Color := RGBToColor(180, 220, 255);
  FLblTime.Caption := 'Time  0.0s';

  FLblNpcs := TLabel.Create(Self);
  FLblNpcs.Parent := FHud;
  FLblNpcs.Left := 500;
  FLblNpcs.Top := 18;
  FLblNpcs.Font.Size := 12;
  FLblNpcs.Font.Color := RGBToColor(255, 180, 120);
  FLblNpcs.Caption := 'NPCs  0';

  FLblBest := TLabel.Create(Self);
  FLblBest.Parent := FHud;
  FLblBest.Left := 620;
  FLblBest.Top := 18;
  FLblBest.Font.Size := 12;
  FLblBest.Font.Color := RGBToColor(255, 220, 90);
  FLblBest.Caption := 'Best  0';

  FBtnStart := TButton.Create(Self);
  FBtnStart.Parent := FHud;
  FBtnStart.Caption := 'Start';
  FBtnStart.Width := 100;
  FBtnStart.Height := 32;
  FBtnStart.AnchorSideRight.Control := FHud;
  FBtnStart.AnchorSideRight.Side := asrRight;
  FBtnStart.AnchorSideTop.Control := FHud;
  FBtnStart.AnchorSideTop.Side := asrCenter;
  FBtnStart.BorderSpacing.Right := 12;
  FBtnStart.Anchors := [akRight, akTop];
  FBtnStart.OnClick := @StartClicked;

  FPaint := TPaintBox.Create(Self);
  FPaint.Parent := Self;
  FPaint.Align := alClient;
  FPaint.OnPaint := @PaintGame;

  FEdtName := TEdit.Create(Self);
  FEdtName.Parent := Self;
  FEdtName.Visible := False;
  FEdtName.Width := 220;
  FEdtName.MaxLength := 16;
  FEdtName.OnKeyDown := @KeyDownEvt;
end;

procedure TGameForm.CollectMaps;
var
  Sl: TStringList;
  I: Integer;
begin
  FCmbMap.Items.Clear;
  Sl := TStringList.Create;
  try
    if DirectoryExists(MapsDir) then
      FindAllFiles(Sl, MapsDir, '*.ini', False);
    Sl.Sort;
    for I := 0 to Sl.Count - 1 do
      FCmbMap.Items.Add(Sl[I]);
  finally
    Sl.Free;
  end;
  if FCmbMap.Items.Count > 0 then
    FCmbMap.ItemIndex := 0
  else
    ShowMessage('No maps found in:' + LineEnding + MapsDir + LineEnding +
      'Put a bitmap + matching .ini file in data/maps.');
end;

procedure TGameForm.LoadSelectedMap;
begin
  if FCmbMap.ItemIndex < 0 then
    Exit;
  try
    FGame.LoadMap(FCmbMap.Items[FCmbMap.ItemIndex]);
    FLblMap.Caption := FGame.MapTitle;
    FGame.State := gsMenu;
    FPaint.Invalidate;
  except
    on E: Exception do
      ShowMessage('Could not load map:' + LineEnding + E.Message);
  end;
end;

procedure TGameForm.MapChanged(Sender: TObject);
begin
  if FGame.State = gsPlaying then
    Exit;
  LoadSelectedMap;
end;

procedure TGameForm.StartClicked(Sender: TObject);
begin
  if FGame.MapWidth = 0 then
    LoadSelectedMap;
  if FGame.MapWidth = 0 then
    Exit;
  Randomize;
  FEdtName.Visible := False;
  FCmbMap.Enabled := False;
  FBtnStart.Caption := 'Restart';
  FGame.NewGame;
  FLastTick := GetTickCount64;
  RefreshHud;
  FPaint.SetFocus;
end;

function TGameForm.MoveVector(out MX, MY: Integer): Boolean;
begin
  MX := 0;
  MY := 0;
  if (VK_LEFT in FKeys) or (VK_A in FKeys) or (Ord('a') in FKeys) then Dec(MX);
  if (VK_RIGHT in FKeys) or (VK_D in FKeys) or (Ord('d') in FKeys) then Inc(MX);
  if (VK_UP in FKeys) or (VK_W in FKeys) or (Ord('w') in FKeys) then Dec(MY);
  if (VK_DOWN in FKeys) or (VK_S in FKeys) or (Ord('s') in FKeys) then Inc(MY);
  Result := (MX <> 0) or (MY <> 0);
end;

procedure TGameForm.Tick(Sender: TObject);
var
  NowTick: QWord;
  DT: Double;
  MX, MY: Integer;
begin
  NowTick := GetTickCount64;
  DT := (NowTick - FLastTick) / 1000.0;
  FLastTick := NowTick;

  MoveVector(MX, MY);
  if FGame.State = gsPlaying then
    FGame.Update(DT, MX, MY);

  if FGame.State = gsGameOver then
  begin
    FCmbMap.Enabled := True;
    FBtnStart.Caption := 'Play again';
    if FScores.Qualifies(FGame.Score) then
    begin
      FGame.State := gsEnterName;
      FEdtName.Text := '';
      FEdtName.Visible := True;
      FEdtName.Left := (ClientWidth - FEdtName.Width) div 2;
      FEdtName.Top := FHud.Height + (ClientHeight - FHud.Height) div 2 + 36;
      FEdtName.SetFocus;
    end;
  end;

  RefreshHud;
  FPaint.Invalidate;
end;

procedure TGameForm.RefreshHud;
begin
  FLblScore.Caption := Format('Score  %d', [FGame.Score]);
  FLblTime.Caption := Format('Time  %.1fs', [FGame.Elapsed]);
  FLblNpcs.Caption := Format('NPCs  %d/%d', [FGame.NpcCount, FGame.MaxNPCs]);
  FLblBest.Caption := Format('Best  %d', [FScores.Best]);
end;

procedure TGameForm.FormResized(Sender: TObject);
begin
  if FEdtName.Visible then
  begin
    FEdtName.Left := (ClientWidth - FEdtName.Width) div 2;
    FEdtName.Top := FHud.Height + (ClientHeight - FHud.Height) div 2 + 36;
  end;
end;

procedure TGameForm.KeyDownEvt(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if Key <= High(Byte) then
    Include(FKeys, Byte(Key));
  if (Key = VK_RETURN) or (Key = VK_SPACE) then
  begin
    if FGame.State = gsEnterName then
    begin
      NameSubmit(nil);
      Key := 0;
      Exit;
    end;
    if FGame.State in [gsMenu, gsGameOver] then
    begin
      StartClicked(nil);
      Key := 0;
      Exit;
    end;
  end;
  if Key = VK_ESCAPE then
  begin
    if FGame.State = gsPlaying then
    begin
      FGame.State := gsMenu;
      FCmbMap.Enabled := True;
      FBtnStart.Caption := 'Start';
    end
    else
      Close;
  end;
end;

procedure TGameForm.KeyUpEvt(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if Key <= High(Byte) then
    Exclude(FKeys, Byte(Key));
end;

procedure TGameForm.NameSubmit(Sender: TObject);
begin
  if FGame.State <> gsEnterName then
    Exit;
  FScores.Add(FEdtName.Text, FGame.Score);
  FEdtName.Visible := False;
  FGame.State := gsGameOver;
  RefreshHud;
end;

procedure TGameForm.DrawOverlay(C: TCanvas; const R: TRect);
var
  CX, CY, I, Y: Integer;
  Title, Sub: string;
  Box: TRect;
begin
  CX := (R.Left + R.Right) div 2;
  CY := (R.Top + R.Bottom) div 2;

  C.Brush.Style := bsSolid;
  C.Brush.Color := RGBToColor(10, 8, 16);
  C.Pen.Color := RGBToColor(140, 110, 200);
  C.Pen.Width := 2;
  Box := Rect(CX - 240, CY - 170, CX + 240, CY + 190);
  C.RoundRect(Box, 16, 16);

  C.Brush.Style := bsClear;
  C.Font.Quality := fqCleartype;
  C.Font.Color := clWhite;
  C.Font.Size := 22;
  C.Font.Style := [fsBold];

  case FGame.State of
    gsMenu:
    begin
      Title := 'CHASE GAME';
      Sub := 'Survive. Do not get caught.';
    end;
    gsGameOver:
    begin
      Title := 'GAME OVER';
      Sub := Format('Score  %d    Time  %.1fs', [FGame.Score, FGame.Elapsed]);
    end;
    gsEnterName:
    begin
      Title := 'NEW HIGH SCORE';
      Sub := Format('%d points  —  type your name and press Enter', [FGame.Score]);
    end;
  else
    Exit;
  end;

  C.TextOut(CX - C.TextWidth(Title) div 2, Box.Top + 18, Title);
  C.Font.Size := 11;
  C.Font.Style := [];
  C.Font.Color := RGBToColor(210, 200, 230);
  C.TextOut(CX - C.TextWidth(Sub) div 2, Box.Top + 58, Sub);

  C.Font.Size := 10;
  C.Font.Color := RGBToColor(160, 150, 190);
  C.TextOut(Box.Left + 24, Box.Top + 88, 'HIGH SCORES');
  Y := Box.Top + 108;
  if FScores.Count = 0 then
  begin
    C.TextOut(Box.Left + 24, Y, 'No scores yet');
    Y := Y + 18;
  end
  else
    for I := 0 to FScores.Count - 1 do
    begin
      C.Font.Color := RGBToColor(255, 220, 120);
      C.TextOut(Box.Left + 24, Y,
        Format('%2d.  %-16s  %6d', [I + 1, FScores.Names[I], FScores.Scores[I]]));
      Y := Y + 16;
    end;

  C.Font.Color := RGBToColor(180, 210, 255);
  C.TextOut(Box.Left + 24, Box.Bottom - 52, 'Move  WASD / arrows');
  C.TextOut(Box.Left + 24, Box.Bottom - 34, 'Start / restart  Space or Enter     Esc  menu / quit');
end;

procedure TGameForm.PaintGame(Sender: TObject);
var
  R: TRect;
begin
  if FPaint.Width < 2 then
    Exit;
  if (FBuffer.Width <> FPaint.Width) or (FBuffer.Height <> FPaint.Height) then
    FBuffer.SetSize(FPaint.Width, FPaint.Height);

  R := Rect(0, 0, FBuffer.Width, FBuffer.Height);
  FGame.Draw(FBuffer.Canvas, R);
  if FGame.State <> gsPlaying then
    DrawOverlay(FBuffer.Canvas, R);
  FPaint.Canvas.Draw(0, 0, FBuffer);
end;

end.
