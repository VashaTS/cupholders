unit uHighScore;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, IniFiles;

const
  MaxHighScores = 10;

type
  TScoreEntry = record
    Name: string;
    Score: Integer;
  end;

  THighScores = class
  private
    FFileName: string;
    FItems: array[0..MaxHighScores - 1] of TScoreEntry;
    FCount: Integer;
    procedure Sort;
  public
    constructor Create(const AFileName: string);
    procedure Load;
    procedure Save;
    function Qualifies(AScore: Integer): Boolean;
    function Add(const AName: string; AScore: Integer): Integer;
    function Count: Integer;
    function GetName(Index: Integer): string;
    function GetScore(Index: Integer): Integer;
    function Best: Integer;
    property Names[Index: Integer]: string read GetName;
    property Scores[Index: Integer]: Integer read GetScore;
  end;

implementation

constructor THighScores.Create(const AFileName: string);
begin
  inherited Create;
  FFileName := AFileName;
  FCount := 0;
end;

procedure THighScores.Sort;
var
  I, J: Integer;
  Tmp: TScoreEntry;
begin
  for I := 0 to FCount - 2 do
    for J := I + 1 to FCount - 1 do
      if FItems[J].Score > FItems[I].Score then
      begin
        Tmp := FItems[I];
        FItems[I] := FItems[J];
        FItems[J] := Tmp;
      end;
end;

procedure THighScores.Load;
var
  Ini: TIniFile;
  I: Integer;
begin
  FCount := 0;
  if not FileExists(FFileName) then
    Exit;
  Ini := TIniFile.Create(FFileName);
  try
    FCount := Ini.ReadInteger('Scores', 'Count', 0);
    if FCount > MaxHighScores then
      FCount := MaxHighScores;
    if FCount < 0 then
      FCount := 0;
    for I := 0 to FCount - 1 do
    begin
      FItems[I].Name := Ini.ReadString('Scores', Format('Name%d', [I + 1]), 'Player');
      FItems[I].Score := Ini.ReadInteger('Scores', Format('Score%d', [I + 1]), 0);
    end;
    Sort;
  finally
    Ini.Free;
  end;
end;

procedure THighScores.Save;
var
  Ini: TIniFile;
  I: Integer;
begin
  ForceDirectories(ExtractFilePath(FFileName));
  Ini := TIniFile.Create(FFileName);
  try
    Ini.WriteInteger('Scores', 'Count', FCount);
    for I := 0 to FCount - 1 do
    begin
      Ini.WriteString('Scores', Format('Name%d', [I + 1]), FItems[I].Name);
      Ini.WriteInteger('Scores', Format('Score%d', [I + 1]), FItems[I].Score);
    end;
    Ini.UpdateFile;
  finally
    Ini.Free;
  end;
end;

function THighScores.Qualifies(AScore: Integer): Boolean;
begin
  if AScore <= 0 then
    Exit(False);
  if FCount < MaxHighScores then
    Exit(True);
  Result := AScore > FItems[FCount - 1].Score;
end;

function THighScores.Add(const AName: string; AScore: Integer): Integer;
var
  Entry: TScoreEntry;
  NameToUse: string;
begin
  Result := -1;
  if AScore <= 0 then
    Exit;
  NameToUse := Trim(AName);
  if NameToUse = '' then
    NameToUse := 'Player';
  if Length(NameToUse) > 16 then
    NameToUse := Copy(NameToUse, 1, 16);

  if FCount < MaxHighScores then
  begin
    FItems[FCount].Name := NameToUse;
    FItems[FCount].Score := AScore;
    Inc(FCount);
  end
  else if AScore > FItems[FCount - 1].Score then
  begin
    FItems[FCount - 1].Name := NameToUse;
    FItems[FCount - 1].Score := AScore;
  end
  else
    Exit;

  Sort;
  Save;
  for Result := 0 to FCount - 1 do
    if (FItems[Result].Score = AScore) and (FItems[Result].Name = NameToUse) then
      Break;
end;

function THighScores.Count: Integer;
begin
  Result := FCount;
end;

function THighScores.GetName(Index: Integer): string;
begin
  if (Index >= 0) and (Index < FCount) then
    Result := FItems[Index].Name
  else
    Result := '';
end;

function THighScores.GetScore(Index: Integer): Integer;
begin
  if (Index >= 0) and (Index < FCount) then
    Result := FItems[Index].Score
  else
    Result := 0;
end;

function THighScores.Best: Integer;
begin
  if FCount > 0 then
    Result := FItems[0].Score
  else
    Result := 0;
end;

end.
