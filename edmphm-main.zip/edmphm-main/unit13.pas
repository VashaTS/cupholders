unit Unit13;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls,
  ExtCtrls, Unit10, inifiles;

type

  { TForm12 }

  TForm12 = class(TForm)
    Button1: TButton;
    Image1: TImage;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Memo1: TMemo;
    procedure FormCreate(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form12: TForm12;

implementation

{$R *.lfm}

{ TForm12 }

procedure TForm12.FormCreate(Sender: TObject);
var ust:TIniFile;
  lang:string;
begin
   ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
  lang:=ust.ReadString('settings','lang','PL');
  ust.Free;
  Form12.Caption:=DataModule1.getString(lang,111); //form title
  Label3.Caption:=DataModule1.getString(lang,112); //zamiast
  Label2.Caption:=DataModule1.getString(lang,113); //przyklad drazenia z podwymiarem
  Label1.Caption:=DataModule1.getString(lang,108); //uwaga (big red)
end;

end.

