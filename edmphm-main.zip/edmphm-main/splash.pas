unit Splash;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, ExtCtrls,
  StdCtrls, Windows;

type

  { TSplashForm }

  TSplashForm = class (TForm)
  Image1: TImage;
  CloseTimer: TTimer;
  Label1: TLabel;
  Label2: TLabel;
  Label3: TLabel;
  Label4: TLabel;
  Label5: TLabel;
  StaticText1: TStaticText;
  Timer1: TTimer;
  procedure CloseTimerTimer(Sender: TObject);
  procedure FormCreate(Sender: TObject);
  procedure FormClose(Sender: TObject; var CAction: TCloseAction);
  procedure FormDestroy(Sender: TObject);
private
  FStartTicks: integer;
  FOKToClose: boolean;
public
  property OKToClose: boolean read FOKToClose write FOKToClose;
end;

var
  SplashForm: TSplashForm;

implementation

{$R *.lfm}
 procedure TSplashForm.FormCreate(Sender: TObject);
begin
  FStartTicks := GetTickCount;
end;

procedure TSplashForm.CloseTimerTimer(Sender: TObject);
const
  CTimeout = 3000;
begin
  Label4.Caption:=Label4.Caption+'.';
  if (GetTickCount - FStartTicks > CTimeout) and OKToClose then
    Close;
  Application.ProcessMessages;
end;

procedure TSplashForm.FormClose(Sender: TObject; var CAction: TCloseAction);
begin
  CAction := caFree;
end;

procedure TSplashForm.FormDestroy(Sender: TObject);
begin
  SplashForm := nil;
end;
end.

