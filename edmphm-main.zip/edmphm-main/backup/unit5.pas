unit Unit5;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls,inifiles, Unit10;

type

  { TForm5 }

  TForm5 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Memo1: TMemo;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure loadMan(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form5: TForm5;

implementation

{$R *.lfm}

{ TForm5 }

procedure TForm5.Button1Click(Sender: TObject);
begin
  Form5.Close;
end;

procedure TForm5.FormCreate(Sender: TObject);
var ust:TIniFile;
  lang:string;
begin
  ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   lang:=ust.ReadString('settings','lang','PL');
   ust.Free;
   Button1.Caption:=DataModule1.getString(lang,120);
   Form5.Caption:=DataModule1.getString(lang,121);
   Button2.Click;
end;

procedure TForm5.loadMan(Sender: TObject);
var ust:TIniFile;
  lang,fn:string;
begin
   ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   lang:=ust.ReadString('settings','lang','PL');
   ust.Free;
   fn:='man\'+lang+'_'+(Sender as TButton).Caption+'.txt';
   if FileExists(fn) then begin
      Memo1.Lines.LoadFromFile(fn);
   end
   else begin

     //showmessage('Wybrana instrukcja nie istnieje:'+AnsiString(#13#10)+fn);

   end;
end;

end.

