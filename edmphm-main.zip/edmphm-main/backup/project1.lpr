program project1;

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}{$IFDEF UseCThreads}
  cthreads,
  {$ENDIF}{$ENDIF}
  Interfaces, // this includes the LCL widgetset
  Forms, printer4lazarus, main, elValues, Settings, About, Help, Log, Unit7,
  AgieSaveConfirm, Unit10, Unit11, Unit12, Unit13, CalcFP, ElStat, Unit16, Splash,
  OrderSel, Unit19, piecedonpalet, sharedtypes, NXCoordConverter, ExitConfirm, NXSelectWp
  { you can add units after this };

{$R *.res}

begin


  Application.Title:='edmpgm';
  RequireDerivedFormResource := True;
  Application.Initialize;
  Application.ShowMainForm:=false;
  Application.CreateForm(TSplashForm, SplashForm);
  //SplashForm := TSplashForm.Create(nil);
  SplashForm.Show;
  SplashForm.Update;
  Application.ProcessMessages;

  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TForm2, Form2);
  Application.CreateForm(TForm3, Form3);
  Application.CreateForm(TForm4, Form4);
  Application.CreateForm(TForm5, Form5);
  Application.CreateForm(TForm6, Form6);
  Application.CreateForm(TForm7, Form7);
  Application.CreateForm(TForm8, Form8);
  Application.CreateForm(TDataModule1, DataModule1);
  Application.CreateForm(TForm10, Form10);
  Application.CreateForm(TForm11, Form11);
  Application.CreateForm(TForm12, Form12);
  Application.CreateForm(TForm14, Form14);
  Application.CreateForm(TForm15, Form15);
  Application.CreateForm(TForm16, Form16);
  Application.CreateForm(TForm17, Form17);
  Application.CreateForm(TForm18, Form18);
  Application.CreateForm(TFormZ, FormZ);
  Application.CreateForm(TForm13, Form13);
  Application.CreateForm(TForm9, Form9);
  Form1.handleparams(Form1);
   if Assigned(SplashForm) then
    SplashForm.OkToClose := True;
   SplashForm.Free;
   Application.ShowMainForm:=true;
   Form1.Show;
   Form1.ShowInTaskBar:=stAlways;
   SplashForm.FormDestroy(Form1);

  Application.Run;




end.

