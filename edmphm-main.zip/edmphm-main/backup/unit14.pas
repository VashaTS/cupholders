unit Unit14;

{$mode objfpc}{$H+}

interface

uses
  ShareMem, Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs,
  StdCtrls, ExtCtrls, strutils, Unit10, inifiles;

type

  { TForm13 }

  TForm13 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Edit4: TEdit;
    Edit5: TEdit;
    Edit6: TEdit;
    Label1: TLabel;
    Label10: TLabel;
    Label11: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    procedure calc(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormActivate(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form13: TForm13;

implementation

{$R *.lfm}
 function isSignedFloat(s:string):boolean; stdcall; external 'libsaj64.dll';
 function isNumeric(s:string):boolean; stdcall; external 'libsaj64.dll';
{ TForm13 }

procedure TForm13.FormCreate(Sender: TObject);
var ust:TIniFile;
  lang:string;
begin
   ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   lang:=ust.ReadString('settings','lang','PL');
   ust.Free;
   Form13.Caption:=DataModule1.getString(lang,108); //oblicz pole powierzchni
   Label6.Caption:=DataModule1.getString(lang,109); //wynik
   Label5.Caption:='------'+DataModule1.getString(lang,110)+'-------'; //lub
   Button2.Caption:=DataModule1.getString(lang,53); //anuluj
end;

procedure TForm13.calc(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  //showmessage((Sender as TEdit).Name);
  if AnsiContainsStr((Sender as TEdit).Text,',') then begin
        (Sender as TEdit).Text:=StringReplace((Sender as TEdit).Text,',','.',[rfReplaceAll]);
        (Sender as TEdit).SelStart:=high(Integer);
     end;
  if (((Sender as TEdit).Name=Edit3.Name) or ((Sender as TEdit).Name=Edit6.Name)) then begin
    //circle
    if ((length(Edit3.Text)>0) and (length(Edit6.Text)>0)) then begin
    if ((isSignedFloat(Edit3.Text)) and (isSignedFloat(Edit5.Text))) then begin
      Edit4.Text:=floattostr(round((strtofloat(Edit3.Text)/2)*(strtofloat(Edit3.Text)/2)*3.14159*strtofloat(Edit6.Text))/100);
      Edit3.Color:=clLime;
      Edit6.Color:=clLime;
      Edit1.Color:=clDefault;
      Edit2.Color:=clDefault;
      Edit5.Color:=clDefault;
    end
    else begin
         Edit3.Color:=clRed;
         Edit6.Color:=clRed;
    end;

    end;
  end
  else begin
    //rect
      if ((length(Edit1.Text)>0) and (length(Edit2.Text)>0) and (length(Edit5.Text)>0)) then begin
    if ((isSignedFloat(Edit1.Text)) and (isSignedFloat(Edit2.Text)) and (isSignedFloat(Edit5.Text))) then begin
      Edit4.Text:=floattostr(round(strtofloat(Edit1.text)*strtofloat(Edit2.text)*strtofloat(Edit5.Text))/100);
      Edit3.Color:=clDefault;
      Edit6.Color:=clDefault;
      Edit1.Color:=clLime;
      Edit2.Color:=clLime;
      Edit5.Color:=clLime;
    end
    else begin
        Edit1.Color:=clRed;
        Edit2.Color:=clRed;
        Edit5.Color:=clRed;
   end;
      end;
  end;
end;

procedure TForm13.FormActivate(Sender: TObject);
begin
  //to remove previous calculation, if any
  Edit1.Text:='0';
  Edit2.Text:='0';
  Edit3.Text:='0';
  Edit4.Text:='0';
  Edit5.Text:='1';
  Edit6.Text:='1';
  Edit1.Color:=clDefault;
  Edit2.Color:=clDefault;
  Edit3.Color:=clDefault;
  Edit5.Color:=clDefault;
  Edit6.Color:=clDefault;
  Edit1.SetFocus;
end;

end.

