unit Unit9;

{$mode objfpc}{$H+}

interface

uses
  ShareMem,Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls, inifiles,DateUtils,Unit10;

type

  { TForm9 }

  TForm9 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    ListBox1: TListBox;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form9: TForm9;

implementation

{$R *.lfm}

{ TForm9 }
function logToFile(path, inp: string): boolean; stdcall; external 'libsaj64.dll';

procedure TForm9.Button1Click(Sender: TObject);
begin
  Form9.Close;
end;

procedure TForm9.Button2Click(Sender: TObject);
var ust:TIniFile;
begin
  ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
     SysUtils.ExecuteProcess('explorer.exe','/select,'+ust.ReadString('settings','pathOutput','c:\')+'\'+Label2.Caption);
     ust.Free;
     logToFile(Application.Location,'INF opened explorer at program location');
     Form9.Close;
end;

procedure TForm9.FormCreate(Sender: TObject);
var lang:string;
ust:TIniFile;
begin
  ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
  lang:=ust.ReadString('settings','lang','PL');
  ust.Free;
  Label1.Caption:=DataModule1.GetString(lang,105);
  Label3.Caption:=DataModule1.GetString(lang,106);
  Button2.Caption:=DataModule1.GetString(lang,107);
end;

end.

