unit Settings;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, ExtCtrls,
  StdCtrls, ComCtrls,inifiles, ShlObj, Registry, DateUtils, Unit10;

type

  { TForm3 }

  TForm3 = class(TForm)
    Button1: TButton;
    Button10: TButton;
    Button11: TButton;
    Button12: TButton;
    Button13: TButton;
    Button14: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    CheckBox1: TCheckBox;
    CheckBox10: TCheckBox;
    CheckBox11: TCheckBox;
    CheckBox12: TCheckBox;
    CheckBox13: TCheckBox;
    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;
    CheckBox4: TCheckBox;
    CheckBox5: TCheckBox;
    CheckBox6: TCheckBox;
    CheckBox7: TCheckBox;
    CheckBox8: TCheckBox;
    CheckBox9: TCheckBox;
    ComboBox1: TComboBox;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Edit4: TEdit;
    GroupBox1: TGroupBox;
    GroupBox2: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    LabeledEdit1: TLabeledEdit;
    LabeledEdit10: TLabeledEdit;
    LabeledEdit11: TLabeledEdit;
    LabeledEdit12: TLabeledEdit;
    LabeledEdit13: TLabeledEdit;
    LabeledEdit14: TLabeledEdit;
    LabeledEdit15: TLabeledEdit;
    LabeledEdit16: TLabeledEdit;
    LabeledEdit17: TLabeledEdit;
    LabeledEdit18: TLabeledEdit;
    LabeledEdit19: TLabeledEdit;
    LabeledEdit2: TLabeledEdit;
    LabeledEdit20: TLabeledEdit;
    LabeledEdit21: TLabeledEdit;
    LabeledEdit22: TLabeledEdit;
    LabeledEdit23: TLabeledEdit;
    LabeledEdit24: TLabeledEdit;
    LabeledEdit25: TLabeledEdit;
    LabeledEdit26: TLabeledEdit;
    LabeledEdit27: TLabeledEdit;
    LabeledEdit3: TLabeledEdit;
    LabeledEdit4: TLabeledEdit;
    LabeledEdit5: TLabeledEdit;
    LabeledEdit6: TLabeledEdit;
    LabeledEdit7: TLabeledEdit;
    LabeledEdit8: TLabeledEdit;
    LabeledEdit9: TLabeledEdit;
    PageControl1: TPageControl;
    RadioButton1: TRadioButton;
    RadioButton10: TRadioButton;
    RadioButton11: TRadioButton;
    RadioButton12: TRadioButton;
    RadioButton13: TRadioButton;
    RadioButton2: TRadioButton;
    RadioButton3: TRadioButton;
    RadioButton4: TRadioButton;
    RadioButton5: TRadioButton;
    RadioButton6: TRadioButton;
    RadioButton7: TRadioButton;
    RadioButton8: TRadioButton;
    RadioButton9: TRadioButton;
    RadioGroup1: TRadioGroup;
    RadioGroup2: TRadioGroup;
    RadioGroup3: TRadioGroup;
    RadioGroup4: TRadioGroup;
    RadioGroup5: TRadioGroup;
    SelectDirectoryDialog1: TSelectDirectoryDialog;
    SelectDirectoryDialog2: TSelectDirectoryDialog;
    SelectDirectoryDialog3: TSelectDirectoryDialog;
    SelectDirectoryDialog4: TSelectDirectoryDialog;
    SelectDirectoryDialog5: TSelectDirectoryDialog;
    SelectDirectoryDialog6: TSelectDirectoryDialog;
    SelectDirectoryDialog7: TSelectDirectoryDialog;
    SelectDirectoryDialog8: TSelectDirectoryDialog;
    SelectDirectoryDialog9: TSelectDirectoryDialog;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    TabSheet4: TTabSheet;
    TabSheet5: TTabSheet;
    TabSheet6: TTabSheet;
    procedure Button10Click(Sender: TObject);
    procedure Button11Click(Sender: TObject);
    procedure Button12Click(Sender: TObject);
    procedure Button13Click(Sender: TObject);
    procedure Button14Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure LabeledEdit12Change(Sender: TObject);
    procedure PageControl1Change(Sender: TObject);
    procedure validateHMIver(Sender: TObject; var Key: Word; Shift: TShiftState
      );
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form3: TForm3;

implementation

{$R *.lfm}

procedure logToFile(inp,typ:string);
var lf:TextFile;
  fd:string;
begin
   DateTimeToString(fd,'yyyy-mm-dd hh:nn:ss',Now);
   AssignFile(lf,Application.Location+'\logfile'+inttostr(YearOf(Now))+'.log');
   if (fileexists(Application.Location+'\logfile'+inttostr(YearOf(Now))+'.log')=false) then begin
     rewrite(lf);
     writeln(lf,fd+' Log started');
     end
   else Append(lf);
   writeln(lf,fd+' '+typ+' '+inp);
   CloseFile(lf);
end;

{ TForm3 }

procedure TForm3.Button1Click(Sender: TObject);
var ust:TIniFile;
begin
   ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   ust.WriteString('settings','isogap_i1',Edit1.Text);
   ust.WriteString('settings','isogap_i2',Edit2.Text);
   ust.WriteString('settings','isogap_b1',Edit3.Text);
   ust.WriteString('settings','isogap_b2',Edit4.Text);
   ust.WriteString('settings','defaultNoOfRows',LabeledEdit1.Text);
   ust.WriteString('settings','defaultElectrodeMaterial',LabeledEdit2.Text);
   ust.WriteString('settings','defaultPieceMaterial',inttostr(ComboBox1.ItemIndex));
   ust.WriteString('settings','pathDXF',LabeledEdit4.Text);
   ust.WriteString('settings','pathMES',LabeledEdit5.Text);
   ust.WriteString('settings','pathOutput',LabeledEdit6.Text);
   ust.WriteString('settings','maxPositionInMagazine',LabeledEdit7.Text);
   ust.WriteString('settings','defaultSideOffset',LabeledEdit8.Text);
   ust.WriteString('settings','pp',LabeledEdit9.Text);
   ust.WriteString('settings','defaultZOffset',LabeledEdit10.Text);
   ust.WriteString('settings','pathVDM',LabeledEdit11.Text);
   ust.WriteString('settings','pathCSV',LabeledEdit3.Text);
   ust.WriteString('settings','pathCSVexport',LabeledEdit13.Text);
   ust.WriteString('settings','minPositionInMagazine',LabeledEdit12.Text);
   ust.WriteSTring('settings','GCn1x',LabeledEdit14.Text);
   ust.WriteSTring('settings','GCn1y',LabeledEdit15.Text);
   ust.WriteSTring('settings','GCn2x',LabeledEdit16.Text);
   ust.WriteSTring('settings','GCn2y',LabeledEdit17.Text);
   ust.WriteString('settings','GCLineLength',LabeledEdit18.Text);
   ust.WriteString('settings','lang',LabeledEdit19.Text);
   if RadioButton1.Checked then ust.WriteString('settings','electrodeStrategy','1')
   else if RadioButton2.Checked then ust.WriteString('settings','electrodeStrategy','2')
   else if RadioButton3.Checked then ust.WriteString('settings','electrodeStrategy','3');
   if RadioButton4.Checked then ust.WriteString('settings','tabOrderF2','stary')
   else if RadioButton5.Checked then ust.WriteString('settings','tabOrderF2','nowy');
   if RadioButton6.Checked then ust.WriteString('settings','f2_ellist','magpos')
   else if RadioButton7.Checked then ust.WriteString('settings','f2_ellist','number')
   else if RadioButton8.Checked then ust.WriteString('settings','f2_ellist','chipid');
   if RadioButton9.Checked then ust.WriteString('settings','dateFormat','-')
   else if RadioButton10.Checked then ust.WriteString('settings','dateFormat','.');
   if RadioButton11.Checked then ust.WriteString('settings','imnaz','technolog')
   else if RadioButton12.Checked then ust.WriteString('settings','imnaz','konstruktor')
   else if RadioButton13.Checked then ust.WriteString('settings','imnaz','none');
   ust.WriteBool('settings','createFolder',CheckBox1.Checked);
   ust.WriteBool('settings','naPen',CheckBox2.Checked);
   ust.WriteBool('settings','autoCSVCerta',CheckBox3.Checked);
   ust.WriteBool('settings','fifoSize',CheckBox4.Checked);
   ust.WriteBool('settings','precalculatedElectrodeData',CheckBox6.Checked);
   ust.WriteBool('settings','moreInterlines',CheckBox7.Checked);
   ust.WriteBool('settings','GCDrawWorkpiece',CheckBox8.Checked);
   ust.WriteBool('settings','allowZeroUndersize',CheckBox9.Checked);
   ust.WriteBool('settings','autoRemoveELFR',CheckBox10.Checked);
   ust.WriteString('settings','verboseMode',LabeledEdit20.Text);
   ust.WriteString('settings','pathXMLJ',LabeledEdit21.Text);
   ust.WriteString('settings','elCheckZdiff',LabeledEdit22.Text);
   ust.WriteString('settings','xmljVersion',LabeledEdit23.Text);
   ust.WriteBool('mag','strictMode',CheckBox11.Checked);
   ust.WriteBool('settings','autoDelLinesCmd',CheckBox12.Checked);
   ust.WriteBool('settings','showPrioSelector',CheckBox13.Checked);
   ust.WriteString('mag','workpiece',LabeledEdit24.Text);
   ust.WriteString('mag','chipDBLocation',LabeledEdit25.Text);
   ust.WriteString('mag','idOutputLocation',LabeledEdit26.Text);
   ust.WriteInteger('settings','additionalTime',strtoint(LabeledEdit27.Text));
   ust.Free;
   logToFile('settings saved','INF');
   //Form3.ModalResult:=mrOk;
   //Form3.Close;
end;

procedure TForm3.Button10Click(Sender: TObject);
begin
  if SelectDirectoryDialog5.Execute then begin
    LabeledEdit3.Text:=SelectDirectoryDialog5.FileName;
    logToFile('Changed CSV Import folder','INF');
  end;
end;

procedure TForm3.Button11Click(Sender: TObject);
begin
  if SelectDirectoryDialog6.Execute then begin
    LabeledEdit13.Text:=SelectDirectoryDialog6.FileName;
    logToFile('Changed CSV Export folder','INF');
  end;
end;

procedure TForm3.Button12Click(Sender: TObject);
begin
  if SelectDirectoryDialog7.Execute then begin
    LabeledEdit21.Text:=SelectDirectoryDialog7.FileName;
    logToFile('Changed XMLJ folder','INF');
  end;
end;

procedure TForm3.Button13Click(Sender: TObject);
begin
  if SelectDirectoryDialog8.Execute then begin
    LabeledEdit25.Text:=SelectDirectoryDialog8.FileName;
    logToFile('Changed Chip DB folder','INF');
  end;
end;

procedure TForm3.Button14Click(Sender: TObject);
begin
  if SelectDirectoryDialog9.Execute then begin
    LabeledEdit26.Text:=SelectDirectoryDialog9.FileName;
    logToFile('Changed idOutput folder','INF');
  end;
end;

procedure TForm3.Button2Click(Sender: TObject);
begin
  Form3.Close;
end;

procedure TForm3.Button3Click(Sender: TObject);
begin
  if SelectDirectoryDialog1.Execute then begin
    LabeledEdit4.Text:=SelectDirectoryDialog1.FileName;
    logToFile('Changed DXF folder','INF');
  end;
end;

procedure TForm3.Button4Click(Sender: TObject);
begin
  if SelectDirectoryDialog2.Execute then begin
    LabeledEdit5.Text:=SelectDirectoryDialog2.FileName;
    logToFile('Changed MES folder','INF');
  end;
end;

procedure TForm3.Button5Click(Sender: TObject);
begin
  if SelectDirectoryDialog3.Execute then begin
    LabeledEdit6.Text:=SelectDirectoryDialog3.FileName;
    logToFile('Changed AgieVision Export folder','INF');
  end;
end;

procedure TForm3.Button6Click(Sender: TObject);
begin
  with TRegistry.Create do
    try
      RootKey:=HKEY_CURRENT_USER;
      if OpenKey('\Software\Classes\.edf', true) then WriteString('','EdfFile');
      if OpenKey('\Software\Classes\EdfFile', true) then WriteString('','EDF File');
      if OpenKey('\Software\Classes\EdfFile\DefaultIcon', true) then WriteString('',Application.Location+'edf.ico');
      if OpenKey('\Software\Classes\EdfFile\shell\open\command', true) then WriteString('',Application.ExeName+' "%1"');
     // RootKey:=HKEY_CLASSES_ROOT;
     // if OpenKey('\Applications\dxf2agiehp.exe\shell\open', true) then WriteString('FriendlyAppName','DXF 2 AGIE HP');
    finally
      Free;
    end;
  SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, nil, nil);
  logToFile('Attempted adding EDF file to registry','INF');
end;

procedure TForm3.Button7Click(Sender: TObject);
begin
  with TRegistry.Create do
    try
      RootKey:=HKEY_CURRENT_USER;
      if OpenKey('\Software\Classes\.mi', true) then WriteString('','MI_FILE');
      if OpenKey('\Software\Classes\MI_FILE', true) then WriteString('','MI File');
      //if OpenKey('\Software\Classes\Dxf2AgiehpFile\DefaultIcon', true) then WriteString('',Application.Location+'icon_file.ico');
      if OpenKey('\Software\Classes\MI_FILE\shell\open\command', true) then WriteString('',Application.ExeName+' "%1"');
    finally
      Free;
    end;
  SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, nil, nil);
  logToFile('Attempted adding MI file to registry','INF');
end;

procedure TForm3.Button8Click(Sender: TObject);
begin
  if SelectDirectoryDialog4.Execute then begin
    LabeledEdit11.Text:=SelectDirectoryDialog4.FileName;
    logToFile('Changed EDF folder','INF');
  end;
end;

procedure TForm3.FormCreate(Sender: TObject);
var ust:TIniFile;
rad,tabf2,lang,f2ell,df,imnaz:string;
begin
   ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   Edit1.Text:=ust.ReadString('settings','isogap_i1','3');
   Edit2.Text:=ust.ReadString('settings','isogap_i2','4');
   Edit3.Text:=ust.ReadString('settings','isogap_b1','0');
   Edit4.Text:=ust.ReadString('settings','isogap_b2','4');
   LabeledEdit1.Text:=ust.ReadString('settings','defaultNoOfRows','10');
   LabeledEdit2.Text:=ust.ReadString('settings','defaultElectrodeMaterial','Graphite2');
   ComboBox1.ItemIndex:=strtoint(ust.ReadString('settings','defaultPieceMaterial','0'));
   LabeledEdit4.Text:=ust.ReadString('settings','pathDXF','C:\Intel\LazarusPortable\dxf test');
   LabeledEdit5.Text:=ust.ReadString('settings','pathMES','C:\korekty\AGIEVISION_2');
   LabeledEdit6.Text:=ust.ReadString('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output');
   LabeledEdit7.Text:=ust.ReadString('settings','maxPositionInMagazine','50');
   LabeledEdit8.Text:=ust.ReadString('settings','defaultSideOffset','5');
   LabeledEdit9.Text:=ust.ReadString('settings','pp','30');
   LabeledEdit10.Text:=ust.ReadString('settings','defaultZOffset','-0.03');
   LabeledEdit11.Text:=ust.ReadString('settings','pathVDM','C:\VDM');
   LabeledEdit3.Text:=ust.ReadString('settings','pathCSV','C:\CSV');
   LabeledEdit13.Text:=ust.ReadString('settings','pathCSVexport','V:\Import\CSV');
   LabeledEdit12.Text:=ust.ReadString('settings','minPositionInMagazine','1');
   LabeledEdit14.Text:=ust.ReadString('settings','GCn1x','0');
   LabeledEdit15.Text:=ust.ReadString('settings','GCn1y','0');
   LabeledEdit16.Text:=ust.ReadString('settings','GCn2x','20');
   LabeledEdit17.Text:=ust.ReadString('settings','GCn2y','20');
   LabeledEdit18.Text:=ust.ReadString('settings','GCLineLength','20');
   LabeledEdit19.Text:=ust.ReadString('settings','lang','PL');
   LabeledEdit20.Text:=ust.ReadString('settings','verbseMode','1');
   LabeledEdit21.Text:=ust.ReadString('settings','pathXMLJ','C:\XMLJ');
   LabeledEdit22.Text:=ust.ReadString('settings','elCheckZdiff','0.03');
   LabeledEdit23.Text:=ust.ReadString('settings','xmljVersion','9.0.0');
   LabeledEdit24.Text:=ust.ReadString('mag','workpiece','1,2,3');
   LabeledEdit25.Text:=ust.ReadString('mag','chipDBLocation','P:\lus\s1\chipdb.txt');
   LabeledEdit26.Text:=ust.ReadString('mag','idOutputLocation','\\desktop-v4e319t\IdOutput');
   LabeledEdit27.Text:=inttostr(ust.ReadInteger('settings','additionalTime',1800));
   rad:=ust.ReadString('settings','electrodeStrategy','1');
   tabf2:=ust.ReadString('settings','tabOrderF2','nowy');
   f2ell:=ust.ReadString('settings','f2_ellist','magpos');
   df:=ust.ReadString('settings','dateFormat','.');
   if rad='1' then RadioButton1.Checked:=True
   else if rad='2' then RadioButton2.CHecked:=True
   else RadioButton3.Checked:=True;
   CheckBox1.Checked:=ust.ReadBool('settings','createFolder',true);
   CheckBox2.Checked:=ust.ReadBool('settings','naPen',true);
   CheckBox3.Checked:=ust.ReadBool('settings','autoCSVCerta',false);
   if tabf2='stary' then RadioButton4.Checked:=True
   else if tabf2='nowy' then RadioButton5.Checked:=True;
   CheckBox6.Checked:=ust.ReadBool('settings','precalculatedElectrodeData',true);
   CheckBox7.Checked:=ust.ReadBool('settings','moreInterlines',true);
   CheckBox8.Checked:=ust.ReadBool('settings','GCDrawWorkpiece',false);
   CheckBox9.Checked:=ust.ReadBool('settings','allowZeroUndersize',false);
   if f2ell='magpos' then RadioButton6.Checked:=True
   else if f2ell='number' then RadioButton7.Checked:=True
   else RadioButton8.Checked:=True;
   CheckBox10.Checked:=ust.ReadBool('settings','autoRemoveELFR',false);
   CheckBox11.Checked:=ust.ReadBool('mag','strictMode',true);
   CheckBox12.Checked:=ust.ReadBool('settings','autoDelLinesCmd',false);
   CheckBox13.Checked:=ust.ReadBool('settings','showPrioSelector',true);
   if df='.' then RadioButton10.Checked:=True
   else if df='-' then RadioButton9.Checked:=True;
   imnaz:=ust.ReadString('settings','imnaz','none');
   if imnaz='technolog' then RadioButton11.Checked:=true
   else if imnaz='konstruktor' then RadioButton12.Checked:=true
   else RadioButton13.Checked:=true;
   CheckBox4.Checked:=ust.ReadBool('settings','fifoSize',false);
   lang:=ust.ReadString('settings','lang','PL');
   LabeledEdit2.EditLabel.Caption:=DataModule1.getString(lang,60);
   Label1.Caption:=DataModule1.getString(lang,61);
   LabeledEdit4.EditLabel.Caption:=DataModule1.getString(lang,62)+' DXF';
   LabeledEdit5.EditLabel.Caption:=DataModule1.getString(lang,62)+' MES';
   LabeledEdit6.EditLabel.Caption:=DataModule1.getString(lang,62)+' AGIE';
   LabeledEdit11.EditLabel.Caption:=DataModule1.getString(lang,62)+' EDF';
   LabeledEdit3.EditLabel.Caption:=DataModule1.getString(lang,62)+' CSV';
   LabeledEdit13.EditLabel.Caption:=DataModule1.getString(lang,62)+' Dirstruct';
   LabeledEdit8.EditLabel.Caption:=DataModule1.getString(lang,63);  //odl dr bok
   LabeledEdit10.EditLabel.Caption:=DataModule1.getString(lang,64); //offset z
   CheckBox6.Caption:=DataModule1.getString(lang,65); // obrót el o C
   CheckBox7.Caption:=DataModule1.getString(lang,66); //interline
   RadioGroup1.Caption:=DataModule1.getString(lang,67); //strategia tw el
   RadioButton1.Caption:=DataModule1.getString(lang,68);
   RadioButton2.Caption:=DataModule1.getString(lang,69);
   RadioButton3.Caption:=DataModule1.getString(lang,70);
   CheckBox1.Caption:=DataModule1.getString(lang,71); //utwórz folder
   CheckBox2.Caption:=DataModule1.getString(lang,72); //wyslij na pen
   RadioGroup2.Caption:=DataModule1.getString(lang,74); //kolejnosc pol
   CheckBox8.Caption:=DataModule1.getString(lang,75); //rysuj detal
   Label2.Caption:=DataModule1.getString(lang,76)+' 1';
   Label3.Caption:=DataModule1.getString(lang,76)+' 2';
   LabeledEdit18.EditLabel.Caption:=DataModule1.getString(lang,77); //dlugosc linii
   LabeledEdit19.EditLabel.Caption:=DataModule1.getString(lang,78); //kod jezyka
   LabeledEdit19.Hint:=DataModule1.getString(lang,79)+' PL, EN, DE';
   Button2.Caption:=DataModule1.getString(lang,53);
   Button1.Caption:=DataModule1.getString(lang,80);
   Form3.Caption:=DataModule1.getString(lang,81);
   CheckBox9.Caption:=DataModule1.getString(lang,96); //allow zero undersize electrode

   ust.Free;
end;

procedure TForm3.LabeledEdit12Change(Sender: TObject);
begin

end;

procedure TForm3.PageControl1Change(Sender: TObject);
begin

end;

procedure TForm3.validateHMIver(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if ((LabeledEdit23.Text<>'9.0.0') and (LabeledEdit23.Text<>'9.3.1')) then begin
    LabeledEdit23.Color:=clRed;
    Button1.Enabled:=false;
  end
  else begin
    LabeledEdit23.Color:=clDefault;
    Button1.Enabled:=True;
  end;
end;

end.

