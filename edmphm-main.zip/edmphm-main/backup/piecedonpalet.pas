unit PiecedOnPalet;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, LResources, Forms, Controls, Graphics, Dialogs, ExtCtrls,
  StdCtrls, sharedtypes;

type

  { TForm18 }

  TForm18 = class(TForm)
    PaintBox1: TPaintBox;
    procedure FormPaint(Sender: TObject);
    procedure PaintBox1Paint(Sender: TObject);
  private

  public
    pieces: Array of TPiece
  end;

var
  Form18: TForm18;

implementation

{ TForm18 }

procedure TForm18.PaintBox1Paint(Sender: TObject);
var i,rx,ry,ref_size,piece_size,p,p_start,p_height:integer;
  magnes:TPoint;
begin
  //showmessage(inttostr(length(pieces)));
  magnes.X:=100;
  magnes.Y:=170;
  ref_size:=20;
  piece_size:=10;
  //Label1.Caption:=inttostr(pieces[0].pos);
  with (Sender as TPaintBox).Canvas do begin
      //magnes
      Brush.Color:=clSilver;
      Fillrect(0,0,(Sender as TPaintBox).Width,(Sender as TPaintBox).Height);
      p_start:=20;
      p_height:=8;
      //paski
      for p:=0 to 100 do begin
          Brush.Color:=clOlive;
          if p mod 2 = 0 then FillRect(0,p_start+(p_height*p),(Sender as TPaintBox).Width,p_start+(p_height*(p+1)));
      end;
      //uklad 0
      Brush.Color:=clRed;
      Pen.Color:=clRed;
      MoveTo(round((Sender as TPaintBox).Width/2), round((Sender as TPaintBox).Height/2)-ref_size);
      LineTo(round((Sender as TPaintBox).Width/2), round((Sender as TPaintBox).Height/2));
      LineTo(round((Sender as TPaintBox).Width/2)+ref_size, round((Sender as TPaintBox).Height/2));
      Brush.Style:=bsClear;
      Font.Name:='Calibri';
      Font.Size:=16;
      Font.Color:=clRed;
      TextOut(round((Sender as TPaintBox).Width/2)+(ref_size)+10, round((Sender as TPaintBox).Height/2)-10,'X');
      TextOut(round((Sender as TPaintBox).Width/2), round((Sender as TPaintBox).Height/2)-(ref_size*3),'Y');
      //detale
      Pen.Color:=clBlack;
      Brush.Color:=clBlack;
      for i:=0 to high(pieces) do begin
          //showmessage(pieces[i].name+AnsiString(#13#10)+floattostr(pieces[i].x));
          Brush.Style:=bsSolid;
          rx:=round((pieces[i].x*(Sender as TPaintBox).Width)/magnes.X);
          //showmessage(floattostr(rx));
          ry:=round(((-1)*pieces[i].y*(Sender as TPaintBox).Height)/magnes.Y);
          MoveTo(rx+round((Sender as TPaintBox).Width/2),ry+round((Sender as TPaintBox).Height/2)-piece_size);
          LineTo(rx+round((Sender as TPaintBox).Width/2),ry+round((Sender as TPaintBox).Height/2));
          LineTo(rx+round((Sender as TPaintBox).Width/2)+piece_size,ry+round((Sender as TPaintBox).Height/2));
          Brush.Style:=bsClear;
          Font.Name:='Calibri';
          Font.Size:=12;
          Font.Color:=clBlack;
          TextOut(rx+round((Sender as TPaintBox).Width/2)+5,ry+round((Sender as TPaintBox).Height/2)-5,pieces[i].name);
      end;
  end;
end;

procedure TForm18.FormPaint(Sender: TObject);
begin

end;

initialization
  {$I piecedonpalet.lrs}

end.

