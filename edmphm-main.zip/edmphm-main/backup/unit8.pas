unit Unit8;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls,Unit10,Inifiles;

type

  { TForm8 }

  TForm8 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Label1: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form8: TForm8;

implementation

{$R *.lfm}

{ TForm8 }

procedure TForm8.Button2Click(Sender: TObject);
begin
  //Application.Terminate;
end;

procedure TForm8.FormCreate(Sender: TObject);
var ust:TIniFile;
  lang:string;
begin
   ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
  lang:=ust.ReadString('settings','lang','PL');
  ust.Free;
  Form8.Caption:=DataModule1.GetString(lang,100);
  Button1.Caption:=DataModule1.GetString(lang,102);
  Button2.Caption:=DataModule1.GetString(lang,104);
  Button3.Caption:=DataModule1.GetString(lang,103);

end;

procedure TForm8.Button1Click(Sender: TObject);
begin

end;

end.

