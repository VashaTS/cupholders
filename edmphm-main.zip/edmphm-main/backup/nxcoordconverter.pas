unit NXCoordConverter;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Math;

type
  TVector3 = record
    X, Y, Z: Double;
  end;

  TMatrix3 = array[0..2, 0..2] of Double;

  TCoordFrame = record
    Name: string;
    CleanName: string;
    Pos: TVector3;
    R: TMatrix3;
  end;

function ConvertToRelativeCoords(const InputData: string; const MainFrameName: string): string;

implementation

function Vec3(const X, Y, Z: Double): TVector3;
begin
  Result.X := X;
  Result.Y := Y;
  Result.Z := Z;
end;

function VecSubtract(const A, B: TVector3): TVector3;
begin
  Result.X := A.X - B.X;
  Result.Y := A.Y - B.Y;
  Result.Z := A.Z - B.Z;
end;

function VecCross(const A, B: TVector3): TVector3;
begin
  Result.X := A.Y * B.Z - A.Z * B.Y;
  Result.Y := A.Z * B.X - A.X * B.Z;
  Result.Z := A.X * B.Y - A.Y * B.X;
end;

procedure BuildRotation(const Xd, Yd, Zd: TVector3; var M: TMatrix3);
begin
  M[0,0] := Xd.X; M[1,0] := Xd.Y; M[2,0] := Xd.Z;
  M[0,1] := Yd.X; M[1,1] := Yd.Y; M[2,1] := Yd.Z;
  M[0,2] := Zd.X; M[1,2] := Zd.Y; M[2,2] := Zd.Z;
end;

function MatVecMultiply(const M: TMatrix3; const V: TVector3): TVector3;
begin
  Result.X := M[0,0]*V.X + M[0,1]*V.Y + M[0,2]*V.Z;
  Result.Y := M[1,0]*V.X + M[1,1]*V.Y + M[1,2]*V.Z;
  Result.Z := M[2,0]*V.X + M[2,1]*V.Y + M[2,2]*V.Z;
end;

function MatrixTranspose(const M: TMatrix3): TMatrix3;
var
  i, j: Integer;
begin
  for i := 0 to 2 do
    for j := 0 to 2 do
      Result[i,j] := M[j,i];
end;

function GetZRotation(const R_el, MainRT: TMatrix3): Double;
var
  X_world, X_local: TVector3;
begin
  X_world.X := R_el[0,0];
  X_world.Y := R_el[1,0];
  X_world.Z := R_el[2,0];
  X_local := MatVecMultiply(MainRT, X_world);
  Result := ArcTan2(X_local.Y, X_local.X) * 180.0 / Pi;
end;

function CleanFrameName(const FullName: string): string;
var
  p: Integer;
begin
  p := Pos('_Datum Coordinate System', FullName);
  if p > 0 then
    Result := Copy(FullName, 1, p-1)
  else
    Result := FullName;
end;

function ConvertToRelativeCoords(const InputData: string; const MainFrameName: string): string;
var
  Lines, Parts: TStringList;
  Frames: array of TCoordFrame;
  FrameCount, i: Integer;
  LineStr, NameStr, DataPart: string;
  FirstCommaPos: Integer;
  PosX, PosY, PosZ, XdX, XdY, XdZ, YdX, YdY, YdZ, ZdX, ZdY, ZdZ: Double;
  MainIdx: Integer;
  MainPos: TVector3;
  MainR, MainRT: TMatrix3;
  ResultList: TStringList;
  Delta, RelPos: TVector3;
  Xd, Yd, Zd: TVector3;
  AngleC: Double;
begin
  Result := '';
  if Trim(InputData) = '' then Exit;

  Lines := TStringList.Create;
  try
    Lines.Text := InputData;
    SetLength(Frames, Lines.Count);
    FrameCount := 0;
    MainIdx := -1;

    for i := 0 to Lines.Count - 1 do
    begin
      LineStr := Trim(Lines[i]);
      if (LineStr = '') or (Pos('Name,', LineStr) = 1) then
        Continue;

      // === FIXED PARSING: take everything before the FIRST comma as the name ===
      FirstCommaPos := Pos(',', LineStr);
      if FirstCommaPos = 0 then Continue;

      NameStr := Trim(Copy(LineStr, 1, FirstCommaPos-1));
      DataPart := Copy(LineStr, FirstCommaPos + 1, MaxInt);

      Parts := TStringList.Create;
      try
        Parts.CommaText := DataPart;   // now only the 12 numeric fields
        if Parts.Count < 12 then Continue;

        PosX := StrToFloatDef(Parts[0], 0);
        PosY := StrToFloatDef(Parts[1], 0);
        PosZ := StrToFloatDef(Parts[2], 0);
        XdX  := StrToFloatDef(Parts[3], 0);
        XdY  := StrToFloatDef(Parts[4], 0);
        XdZ  := StrToFloatDef(Parts[5], 0);
        YdX  := StrToFloatDef(Parts[6], 0);
        YdY  := StrToFloatDef(Parts[7], 0);
        YdZ  := StrToFloatDef(Parts[8], 0);
        ZdX  := StrToFloatDef(Parts[9], 0);
        ZdY  := StrToFloatDef(Parts[10], 0);
        ZdZ  := StrToFloatDef(Parts[11], 0);

        Xd := Vec3(XdX, XdY, XdZ);
        Yd := Vec3(YdX, YdY, YdZ);
        Zd := Vec3(ZdX, ZdY, ZdZ);

        if (Abs(Zd.X) < 1E-8) and (Abs(Zd.Y) < 1E-8) and (Abs(Zd.Z) < 1E-8) then
          Zd := VecCross(Xd, Yd);

        Frames[FrameCount].Name := NameStr;
        Frames[FrameCount].CleanName := CleanFrameName(NameStr);
        Frames[FrameCount].Pos := Vec3(PosX, PosY, PosZ);
        BuildRotation(Xd, Yd, Zd, Frames[FrameCount].R);

        if Pos(UpperCase(MainFrameName), UpperCase(NameStr)) > 0 then
          MainIdx := FrameCount;

        Inc(FrameCount);
      finally
        Parts.Free;
      end;
    end;

    SetLength(Frames, FrameCount);

    if MainIdx = -1 then
    begin
      Result := 'ERROR: Main frame "' + MainFrameName + '" not found!';
      Exit;
    end;

    MainPos := Frames[MainIdx].Pos;
    MainR := Frames[MainIdx].R;
    MainRT := MatrixTranspose(MainR);

    ResultList := TStringList.Create;
    try
      //ResultList.Add('# DEBUG: Main frame = "' + Frames[MainIdx].CleanName + '"');
      //ResultList.Add(Format('# DEBUG: Main world pos = %.8f, %.8f, %.8f', [MainPos.X, MainPos.Y, MainPos.Z]));

      for i := 0 to FrameCount - 1 do
      begin
        if i = MainIdx then Continue;

        Delta := VecSubtract(Frames[i].Pos, MainPos);
        RelPos := MatVecMultiply(MainRT, Delta);
        AngleC := GetZRotation(Frames[i].R, MainRT);

        ResultList.Add(Format('%s,%.8f,%.8f,%.8f,%.4f',
          [Frames[i].CleanName, RelPos.X, RelPos.Y, RelPos.Z, AngleC]));
      end;

      Result := ResultList.Text;
    finally
      ResultList.Free;
    end;
  finally
    Lines.Free;
  end;
end;

end.

