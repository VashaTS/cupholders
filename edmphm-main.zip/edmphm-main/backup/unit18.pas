unit Unit18;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm16 }

  TForm16 = class(TForm)
    Button1: TButton;
    ListBox1: TListBox;
    procedure ListBox1Click(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form16: TForm16;

implementation

{$R *.lfm}

{ TForm16 }

procedure TForm16.ListBox1Click(Sender: TObject);
begin
  if ListBox1.ItemIndex<>-1 then Button1.Enabled:=true;
end;

end.

