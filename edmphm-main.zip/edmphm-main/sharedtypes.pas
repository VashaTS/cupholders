unit SharedTypes;

{$mode ObjFPC}{$H+}

interface

type
   TPiece = record
    x:real;
    y:real;
    name:string;
    c:real;
    pos:integer;
  end;


implementation

end.


