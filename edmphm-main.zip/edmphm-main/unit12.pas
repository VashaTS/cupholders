unit Unit12;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls,IniFiles,Unit10;

type

  { TForm11 }

  TForm11 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Label1: TLabel;
    procedure FormCreate(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form11: TForm11;

implementation

{$R *.lfm}

{ TForm11 }

procedure TForm11.FormCreate(Sender: TObject);
var ust:TIniFile;
  lang:string;
begin
  ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
  lang:=ust.ReadString('settings','lang','PL');
  ust.Free;
  Label1.Caption:=DataModule1.getString(lang,99); //Sortować według FP ?
  //Button1.SetFocus;
end;

end.

