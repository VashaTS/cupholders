unit Unit16;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm15 }

  TForm15 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    ComboBox1: TComboBox;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    ListBox1: TListBox;
    ListBox2: TListBox;
    ListBox3: TListBox;
    ListBox4: TListBox;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure ListBox1SelectionChange(Sender: TObject; User: boolean);
    procedure ListBox2SelectionChange(Sender: TObject; User: boolean);
    procedure ListBox3SelectionChange(Sender: TObject; User: boolean);
    procedure ListBox4SelectionChange(Sender: TObject; User: boolean);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form15: TForm15;

implementation

{$R *.lfm}

{ TForm15 }

procedure TForm15.ListBox1SelectionChange(Sender: TObject; User: boolean);
begin
   if ListBox1.ItemIndex<>-1 then begin
       Button1.Visible:=true;
       Button2.Visible:=true;
       Button3.Visible:=true;
   end
   else begin
       Button1.Visible:=false;
       Button2.Visible:=false;
       Button3.Visible:=false;
   end;
end;

procedure TForm15.ListBox2SelectionChange(Sender: TObject; User: boolean);
begin
  if ListBox2.ItemIndex<>-1 then Button4.Visible:=true
  else Button4.Visible:=false;
end;

procedure TForm15.ListBox3SelectionChange(Sender: TObject; User: boolean);
begin
  if ListBox3.ItemIndex<>-1 then Button5.Visible:=true
  else Button5.Visible:=false;
  //update combobox to show coord systems
end;

procedure TForm15.ListBox4SelectionChange(Sender: TObject; User: boolean);
begin
  if ListBox4.ItemIndex<>-1 then Button6.Visible:=true
  else Button6.Visible:=false;
end;

procedure TForm15.Button1Click(Sender: TObject);
begin
  if ListBox1.ItemIndex<>-1 then begin
      ListBox3.Items.Add(ListBox1.Items[ListBox1.ItemIndex]);
      ListBox1.Items.Delete(ListBox1.ItemIndex);
      ListBox1.ItemIndex:=-1;
      Form15.ListBox1SelectionChange(ListBox1,false);
  end;
end;

procedure TForm15.Button2Click(Sender: TObject);
begin
  if ListBox1.ItemIndex<>-1 then begin
      ListBox4.Items.Add(ListBox1.Items[ListBox1.ItemIndex]);
      ListBox1.Items.Delete(ListBox1.ItemIndex);
      ListBox1.ItemIndex:=-1;
      Form15.ListBox1SelectionChange(ListBox1,false);
  end;
end;

procedure TForm15.Button3Click(Sender: TObject);
begin
  if ListBox1.ItemIndex<>-1 then begin
      ListBox2.Items.Add(ListBox1.Items[ListBox1.ItemIndex]);
      ListBox1.Items.Delete(ListBox1.ItemIndex);
      ListBox1.ItemIndex:=-1;
      Form15.ListBox1SelectionChange(ListBox1,false);
  end;
end;

procedure TForm15.Button4Click(Sender: TObject);
begin
  if ListBox2.ItemIndex<>-1 then begin
     ListBox1.Items.Add(ListBox2.Items[listBox2.ItemIndex]);
     ListBox2.Items.Delete(ListBox2.ItemIndex);
     ListBox2.ItemIndex:=-1;
     Form15.ListBox2SelectionChange(ListBox2,false);
  end;
end;

procedure TForm15.Button5Click(Sender: TObject);
begin
  if ListBox3.ItemIndex<>-1 then begin
     ListBox1.Items.Add(ListBox3.Items[ListBox3.ItemIndex]);
     ListBox3.Items.Delete(ListBox3.ItemIndex);
     ListBox3.ItemIndex:=-1;
     Form15.ListBox3SelectionChange(ListBox3,false);
  end;
end;

procedure TForm15.Button6Click(Sender: TObject);
begin
  if ListBox4.ItemIndex<>-1 then begin
     ListBox1.Items.Add(ListBox4.Items[listBox4.ItemIndex]);
     ListBox4.Items.Delete(ListBox4.ItemIndex);
     ListBox4.ItemIndex:=-1;
     Form15.ListBox4SelectionChange(ListBox4,false);
  end;
end;

procedure TForm15.Button7Click(Sender: TObject);
begin
  if ((ListBox2.Items.Count>0) and (ListBox3.Items.Count>0) and (ListBox4.Items.Count>0)) then begin
     Form15.ModalResult:=mrOk;
  end
  else begin
         showmessage('Brak danych');
         Form15.ModalResult:=mrCancel;
  end;
end;

end.

