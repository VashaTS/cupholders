unit ElStat;

{$mode objfpc}{$H+}

interface

uses
  ShareMem, Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs,
  StdCtrls, ExtCtrls;

type
   TArrayOfString = Array of string;
   TElStat = record
     name:string;
     amount:integer;
   end;

  { TForm14 }

  TForm14 = class(TForm)
    Button1: TButton;
    Label1: TLabel;
    Memo1: TMemo;
    Memo2: TMemo;
    PaintBox1: TPaintBox;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form14: TForm14;

  lab:Array of TLabel;
  cha:Array of TShape;
  mats:Array of TElStat;

implementation

{$R *.lfm}

function SplitString(const aSepator, aString:string;aMax:integer=0):TArrayOfString; stdcall; external 'libsaj64.dll';

{ TForm14 }

procedure TForm14.FormCreate(Sender: TObject);
var i,j,leftOffset,topOffset:integer;
  l:TArrayOfString;
  ums:Array of TElStat;
  temp_um,temp_mat:TElStat;

  temp_name,temp_name2:string;
  exists,exists2:boolean;
begin
  leftOffset:=100;
  topOffSet:=10;
  if FileExists('stat_el_certa.csv') then begin
     //setLength(ums,0);
     //setLength(mats,0);
     Memo1.Lines.LoadFromFile('stat_el_certa.csv');
     for i:=1 to Memo1.Lines.Count-1 do begin
        l:=SplitString(';',Memo1.Lines[i]);
        //ums
        temp_name:=l[9]+'x'+l[3];
        if l[10]<>'0' then temp_name:=temp_name+', '+l[10]+'x'+l[4];
        exists:=false;
        for j:=0 to high(ums) do begin
            if ums[j].name=temp_name then begin //add to existing entry
               exists:=true;
               ums[j].amount:=ums[j].amount+1;
               break;
            end;
        end;
        if not exists then begin //new entry
            setLength(ums,length(ums)+1);
            ums[High(ums)].name:=temp_name;
            ums[High(ums)].amount:=1;
        end;
         //mats
        temp_name2:=l[1];
        exists2:=false;
        for j:=0 to high(mats) do begin
            if mats[j].name=temp_name2 then begin //add to existing entry
               exists2:=true;
               mats[j].amount:=mats[j].amount+1; //change to actual amount?
               break;
            end;
        end;
        if not exists2 then begin
           setLength(mats,length(mats)+1);
           mats[High(mats)].name:=temp_name2;
           mats[High(mats)].amount:=1; //change to actual amount?
         end;
     end;

     //sort
     for i:=0 to High(ums)-1 do begin
        for j:=i+1 to High(ums) do begin
           if ums[j].amount > ums[i].amount then begin
              temp_um:=ums[i];
              ums[i]:=ums[j];
              ums[j]:=temp_um;
           end;
        end;
     end;
     //display data
     Memo2.Lines.Clear;
     if length(ums)>0 then begin
        for i:=0 to High(ums) do begin
        Memo2.Lines.Add(ums[i].name + ' - ' + inttostr(ums[i].amount));
        setLength(lab,length(lab)+1);
        setLength(cha,length(cha)+1);
        lab[High(lab)]:=TLabel.Create(Form14);
        cha[High(cha)]:=TShape.Create(Form14);
        lab[High(lab)].Name:='lab_'+inttostr(i);
        lab[High(lab)].Parent:=Form14;
        lab[High(lab)].Left:=10;
        lab[High(lab)].Top:=topOffset+((lab[High(lab)].Height+10)*i);
        lab[High(lab)].Caption:=ums[i].name+' ('+inttostr(ums[i].amount)+')';
        cha[High(cha)].Name:='cha_'+inttostr(i);
        cha[High(cha)].Parent:=Form14;
        cha[High(cha)].Shape:=stRectangle;
        cha[High(cha)].Brush.Color:=clTeal;
        cha[High(cha)].Top:=lab[High(lab)].Top;
        cha[High(cha)].Left:=leftOffset;
        cha[High(cha)].Height:=20;
        cha[High(cha)].Width:=round(((Form14.Width-leftOffset)*ums[i].amount)/ums[0].amount);
     end;

     end;

  end
  else showmessage('found no file containing electrode data!');
end;

procedure TForm14.Button1Click(Sender: TObject);
var i,j,total,angle,todate:integer;
begin
   if length(mats)>0 then begin
      total:=0;
      todate:=0;
      for i:=0 to High(mats) do begin
        total:=total+mats[i].amount;
        end;
        for i:=0 to High(mats) do begin
            Memo2.Lines.Add(mats[i].name+' - '+inttostr(mats[i].amount));
            if mats[i].name='Copper' then begin
            with PaintBox1.Canvas do begin
            Repaint;
            Pen.Style:=psSolid;
            Pen.Color:=clBlack;
            Pen.Width:=2;
            Brush.Color:=clDefault;
            FillRect(0,0,PaintBox1.Width,PaintBox1.Height);
            //Pen.Color:=$000A79DE;
            Brush.Color:=clRed;
            Pen.Color:=clGray;
            MoveTo(round(PaintBox1.Width/2),round(PaintBox1.Height/2));
            for j:=1 to round(PaintBox1.Width/2.2) do begin
            AngleArc(round(PaintBox1.Width/2),round(PaintBox1.Height/2),j,0,359);
            end;
            Pen.Color:=$000A79DE;
            angle:=round(360*mats[i].amount/total);
            //Pie(100,100,110,110,200,200,150,150);
            MoveTo(round(PaintBox1.Width/2),round(PaintBox1.Height/2));
            for j:=1 to round(PaintBox1.Width/2.2) do begin
                AngleArc(round(PaintBox1.Width/2),round(PaintBox1.Height/2),j,todate,angle);
                LineTo(round(PaintBox1.Width/2),round(PaintBox1.Height/2));
            end;
            Label1.Caption:='Copper: '+floattostr(round(10000*mats[i].amount/total)/100)+'%';
            Label1.Visible:=True;
            Refresh;
            //showmessage('Angle: '+inttostr(angle)+', ToDate: '+inttostr(todate));
            todate:=todate+angle;
               //Ellipse(0,0,PaintBox1.Width,PaintBox1.Height);

           end;

            end;
            //PaintBox1.Canvas.

     end;
        Application.ProcessMessages;
       end;
end;

end.

