unit NXSelectWP;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, LResources, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TFormZ }

  TFormZ = class(TForm)
    Button1: TButton;
    Label1: TLabel;
    ListBox1: TListBox;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ListBox1Click(Sender: TObject);
  private

  public

  end;

var
  FormZ: TFormZ;

implementation
{$R *.lfm}
{ TFormZ }

procedure TFormZ.ListBox1Click(Sender: TObject);
begin
  if (Sender as TListBox).ItemIndex<>-1 then begin
    Button1.Enabled:=true;
  end
  else Button1.Enabled:=false;
end;

procedure TFormZ.FormCreate(Sender: TObject);
begin

end;

procedure TFormZ.Button1Click(Sender: TObject);
begin

end;

end.

