@echo off
curl ^"http://narzedziownia.europe.phoenixcontact.com/api/fifo/list^" ^
  -H ^"Accept: application/json, text/plain, */*^" ^
  -H ^"Accept-Language: pl,en;q=0.9,en-GB;q=0.8,en-US;q=0.7^" ^
  -H ^"Proxy-Connection: keep-alive^" ^
  -H ^"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0^" ^
  -H ^"credentials: include^" ^
  -H ^"mode: cors^" --negotiate -u : -o out.txt