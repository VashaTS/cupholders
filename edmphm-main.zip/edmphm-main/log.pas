unit Log;

{$mode objfpc}{$H+}

interface

uses
  ShareMem,Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, ExtCtrls,
  StdCtrls, EditBtn, Grids, ColorBox, ValEdit, DateUtils,inifiles,Unit10;

type
  TArrayOfString = array of String;
  { TForm6 }

  TForm6 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    StringGrid1: TStringGrid;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure DateEdit1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure resi(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form6: TForm6;

implementation

{$R *.lfm}

function SplitString(const aSepator, aString:string;aMax:integer=0):TArrayOfString; stdcall; external 'libsaj64.dll';

function isNumber(s:string):boolean;
var i:integer;
begin
     i:=1;
     while (i<=length(s)) and (s[i] in ['0'..'9','.','E']) do inc(i);
     result:=i>length(s);
end;

procedure readLog;
var i,j:integer;
  sl:TStringList;
  sp,rd:TArrayOfString;
  joint_str,sd,sd2,yy,mm,dd,df,constructed_date:string;
  ust:TIniFile;
  rdd:TDateTime;
begin
 ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
 df:=ust.ReadString('settings','dateFormat','.');
 ust.Free;
 //sd:=Form6.DateEdit1.Text;
 //DateTimeToString(sd,Form6.Edit1.text,Now());
 if df='-' then rdd:=strtodatetime(Form6.Edit1.Text)
 else begin
      rd:=SplitString('-',Form6.Edit1.Text);
      constructed_date:=rd[2]+'.'+rd[1]+'.'+rd[0];
      rdd:=strtodatetime(constructed_date);
 end;
 DateTimeToString(yy,'yyyy',rdd);
 DateTimeToString(mm,'mm',rdd);
 DateTimeToString(dd,'dd',rdd);
 sd:=yy+'-'+mm+'-'+dd;
 sd2:=dd+'.'+mm+'.'+yy;
 if df='-' then sd2:=sd;
 Form6.StringGrid1.RowCount:=1;
 sl:=TStringList.Create;
   sl.LoadFromFile(Application.Location+'\logfile'+inttostr(YearOf(strtodatetime(sd2)))+'.log');
   for i:= 0 to sl.Count-1 do begin
       sp:=SplitString(' ',sl.Strings[i]);
       if sp[0]=sd then begin
         Form6.StringGrid1.RowCount:=Form6.StringGrid1.RowCount+1;
         Form6.StringGrid1.Cells[0,(Form6.StringGrid1.RowCount-1)]:=sp[0];
         Form6.StringGrid1.Cells[1,(Form6.StringGrid1.RowCount-1)]:=sp[1];
         Form6.StringGrid1.Cells[2,(Form6.StringGrid1.RowCount-1)]:=sp[2];
         Form6.StringGrid1.Cells[3,(Form6.StringGrid1.RowCount-1)]:=sp[3];
         Form6.StringGrid1.Cells[4,(Form6.StringGrid1.RowCount-1)]:=sp[4];

         joint_str:=sp[5];
         for j:=6 to length(sp)-1 do joint_str:=joint_str+' '+sp[j];
         Form6.StringGrid1.Cells[5,(Form6.StringGrid1.RowCount-1)]:=joint_str;
       end;
   end;
   sl.Destroy;
   Form6.StringGrid1.Refresh;
end;

{ TForm6 }

procedure TForm6.FormCreate(Sender: TObject);
var ust:TIniFile;
  lang,str,adds:string;
begin
   ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   lang:=ust.ReadString('settings','lang','PL');
   ust.Free;
   Button1.Caption:=DataModule1.getString(lang,115); //dzisiaj
   DateTimeToString(str,'yyyy',Now());
   DateTimeToString(adds,'mm',Now());
   str:=str+'-'+adds+'-';
   DateTimeToString(adds,'dd',Now());
   str:=str+adds;
   Edit2.Text:='0';
   //DateEdit1.Date:=StrToDateTime(str);

   Edit1.text:=str;
  StringGrid1.Cells[0,0]:=DataModule1.getString(lang,116); //data
  StringGrid1.Cells[1,0]:=DataModule1.getString(lang,117); //czas
  StringGrid1.Cells[2,0]:='komputer';
  StringGrid1.Cells[3,0]:='użytkownik';
  StringGrid1.Cells[4,0]:=DataModule1.getString(lang,118); //typ
  StringGrid1.Cells[5,0]:=DataModule1.getString(lang,119); //opis
  StringGrid1.ColWidths[0]:=70;
  StringGrid1.ColWidths[1]:=50;
  StringGrid1.ColWidths[2]:=80;
  StringGrid1.ColWidths[3]:=50;
  StringGrid1.ColWidths[4]:=50;
  StringGrid1.ColWidths[5]:=650;
  readLog;
end;

procedure TForm6.resi(Sender: TObject);
begin
   StringGrid1.Height:=Form6.Height-100;
   StringGrid1.Width:=Form6.Width-39;
   StringGrid1.ColWidths[5]:=650+(Form6.Width-1063);
end;

procedure TForm6.Button3Click(Sender: TObject);
var ad,sd:string;
begin
   Edit2.Text:=inttostr(strtoint(Edit2.Text)+1);
   DateTimeToString(sd,'yyyy',Now()+strtoint(Edit2.Text));
  DateTimeToString(ad,'mm',Now()+strtoint(Edit2.Text));
  sd:=sd+'-'+ad+'-';
  DateTimeToString(ad,'dd',Now()+strtoint(Edit2.Text));
  sd:=sd+ad;
  Edit1.Text:=sd;
  //DateEdit1.Date:=DateEdit1.Date+1;
  readLog;
end;

procedure TForm6.DateEdit1Change(Sender: TObject);
begin
  //causes access violation :(
  //readLog;
end;

procedure TForm6.Button1Click(Sender: TObject);
var sd,ad:string;
begin
  //DateEdit1.Date:=Now;
  DateTimeToString(sd,'yyyy',Now());
  DateTimeToString(ad,'mm',Now());
  sd:=sd+'-'+ad+'-';
  DateTimeToString(ad,'dd',Now());
  sd:=sd+ad;
  Edit1.Text:=sd;
  Edit2.Text:='0';
  readLog;
end;

procedure TForm6.Button2Click(Sender: TObject);
var ad,sd:string;
begin
  Edit2.Text:=inttostr(strtoint(Edit2.Text)-1);
  DateTimeToString(sd,'yyyy',Now()+strtoint(Edit2.Text));
  DateTimeToString(ad,'mm',Now()+strtoint(Edit2.Text));
  sd:=sd+'-'+ad+'-';
  DateTimeToString(ad,'dd',Now()+strtoint(Edit2.Text));
  sd:=sd+ad;
  Edit1.Text:=sd;
  //DateEdit1.Date:=DateEdit1.Date-1;
  readLog;
end;

end.

