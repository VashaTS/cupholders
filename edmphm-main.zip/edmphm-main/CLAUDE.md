# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

**edmpgm** (output binary: `dxf2agiehp.exe`) — a Windows desktop application written in Free Pascal (Lazarus IDE). It generates EDM (Electrical Discharge Machining) programs for multiple machine types from various CAD import formats.

## Building

Open `project1.lpi` in **Lazarus IDE** and use Build (Shift+F9) or Run (F9). There is no command-line build script — the project is built exclusively through the Lazarus IDE GUI. Compiled output goes to `dxf2agiehp.exe`. Intermediate files land in `lib\x86_64-win64\`.

Target: Windows 64-bit (`x86_64-win64`), optimization level 3, no debug info.

Required external DLLs (must be in the same directory as the EXE):
- `libsaj64.dll` — provides `SplitString`, `logToFile`, `isNumeric`, `isSignedFloat`
- `fpcmemdll.dll` — memory management

## Architecture

### State model

The application stores all working data in **parallel `TListBox` components** on Form1. Each index position corresponds to one electrode entry:

| ListBox | Data |
|---------|------|
| ListBox2 | electrode name |
| ListBox3/4/5/6 | X/Y/C/Z position |
| ListBox7 | electrode material |
| ListBox8 | Fp (finish parameter) |
| ListBox9 | eroding direction (Z/X+/X-/Y+/Y-) |
| ListBox11 | side offset |
| ListBox12 | VDI surface quality code |
| ListBox14/15 | A/B angles |

Form2 (`elvalues.pas`) holds electrode parameter details in its own `ListBox1` (semicolon-delimited strings with ~20+ fields per electrode) and `CheckListBox1` (electrode name visibility).

### Key units

- **`main.pas`** — monolithic main form (~7500 lines). Contains all import parsers, export generators, and UI logic. Core data types (`TElectrode`, `TElHyperCAD`, `TNXCoord`, `TFifoBox`, etc.) are declared in the interface section's global `var` block.
- **`elvalues.pas`** (`TForm2`) — electrode parameters editor dialog.
- **`settings.pas`** (`TForm3`) — application settings (reads/writes `dxf2agiehp.ini`).
- **`unit10.pas`** (`TDataModule1`) — multilingual string table (PL/EN/DE), accessed via `DataModule1.getString(lang, num)`.
- **`NXCoordConverter.pas`** — pure logic unit; converts NX datum CSV data (absolute 3D frames) into relative coordinates relative to a named main frame. No UI dependencies.
- **`sharedtypes.pas`** — defines `TPiece` record shared between units.

### Import loaders (all in `main.pas`)

| Procedure | Source format |
|-----------|--------------|
| `load_csv(inp)` | Creo SEB CSV — auto-detects sub-format: `excelcsv`, `pureseb`, or `gtis` |
| `load_ncvisu_csv(inp)` | ncVisu CSV (semicolon-delimited, lines containing `;Unset;`) |
| `load_hypercad(inp)` | HyperCAD XML (parsed as text, not DOM) |
| `load_xmlj(inp)` | Form X400 `.xmlj` spark program (re-import) |
| `load_edf(inp)` | Own save format, keyed `field:value` lines |
| `load_agievision(inp)` | AgieVision `.JOB` file |
| `Button1Click` | Legacy DXF / `.mi` file (CREO 16 electrode position table) |

File type dispatch at startup: `handleparams()` checks `ParamStr(1)` extension and calls the appropriate loader.

### Output formats

Export logic is in `TForm1` event handlers (BitBtn clicks). Output files go to the path configured in `dxf2agiehp.ini` under `settings.pathOutput`.

- **Agie Hyperspark `.JOB`** — enabled via `exportAgieHP=1` in INI
- **Form X400 `.xmlj`** — versions 9.0.0 and 9.3.1, enabled via `exportX400=1`
- **CERTA `.csv` + `.xmlj`** — enabled via `exportCERTA=1`
- **`.edf`** — own save format

### VDI surface quality

VDI codes (e.g. `VDI26`) are used throughout. Key conversion helpers in `main.pas`:
- `vdi_nr_to_ii(s)` / `vdi_ii_to_nr(i)` — VDI string ↔ internal integer index
- `vdi_num_to_agie(s)` — VDI string → Agie `.JOB` surface quality line

### Settings (INI file)

`dxf2agiehp.ini` co-located with the EXE. Read via `TIniFile` throughout the codebase. Key settings: `pathOutput`, `pathDXF`, `pathCSV`, `pathXMLJ`, `xmljVersion`, `lang`, `verboseMode`, `exportAgieHP/X400/CERTA`.

### External libraries (bundled)

`SynCommons.pas`, `SynCrypto.pas`, `SynGdiPlus.pas`, `SynLZ.pas`, `SynPdf.pas`, `SynZip.pas`, `mORMotReport.pas` — Synopse mORMot framework, used for PDF report generation.

## Language

The UI supports Polish (PL), English (EN), and German (DE). Strings are loaded via `DataModule1.getString(Form3.ComboBox1.Items[...], index)`. Active language is stored in INI as `lang=PL`.
