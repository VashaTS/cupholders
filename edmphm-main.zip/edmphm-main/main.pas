unit main;

{$mode objfpc}{$H+}

interface

uses
  ShareMem, Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, LCLTranslator,
  StdCtrls, ExtCtrls, Comctrls, Spin, Menus, Math, elValues, Settings, About, Help,
  Log, inifiles, StrUtils, DateUtils, Windows, LResources, Buttons, NXSelectWP,
  Unit7, ExitConfirm, AgieSaveConfirm, Unit10, ParamHMI, Unit12, Unit13, ElStat, Unit16, OrderSel, PiecedOnPalet, sharedtypes, NXCoordConverter;

type
  TArrayOfString = array of String;
  TAAS = array of TArrayOfSTring;

  TNXCoord = record
    name:string;
    X:real;
    Y:real;
    Z:real;
    C:real;
    Zdir:real;
  end;

  TElectrode = record
    global_nr:integer;
    local_nr:integer;
    name:string;
    undersize:real;
    finType:integer;
    fp:real;
    mat:string;
    elname:string;      //electrode name (exact, for matching with shapes)
    splitCount:integer; //number of shapes this electrode is split into (1 = all pieces in 1 shape)
    shapeIdx:integer;   //which of the split shapes this tool belongs to (1..splitCount)
  end;

  TElHyperCad = record
    name:string;
    material:string;
    roughness_v:real;
    roughness_vv:real;
    number_v:integer;
    number_vv:integer;
    pos_x:string;
    pos_y:string;
    pos_z:string;
    pos_c:string;
    fp:string;
    vdi:string;
  end;

  TShapeHmi = record
    name:string; //electrode+Z
    sp:array of integer;
    st:array of integer;
    elname:string;
    vdi:string;
    edmDepth:real;
    edmDir:string;
    //shepepieces = always all

  end;

  TAcisBody = record
    nr:integer;
    name:string;
    elements:array of TArrayOfString;
  end;
  TFifoBox = record
    id:string;
    fifoNumber:string;
    orderNumber:string;
    kwzNumber:string;
    dotColor:string;
    plannedTime:integer;
    confirmedTime:integer;
    identNumber:string;
    gtisNumber:string;
    bm7Plan:string;
    bm7Target:string;
    linia:string;
    klient:string;
    //bm3plan:string;
    //currentMachine:string;
    //dateDot:string;
    //dateEntry:string;
    //dotForCurrOpOnly:boolean;
    //firstSeen:string;
    //forDeletion:boolean;
    //keepAtMachine:string;
    konstruktor:string;
    //lastSeen:string;
    matname:string;
    //mfPlan:string;
    //nonFifoOrder:integer;
    onMachine:boolean;
    //opDescr:string;
    //parentOrder:string;
    //planTimes:string;
    //priorytet:boolean;
    //problem:string;
    projectSize:string;
    realDateEntry:string;
    technolog:string;
    quantity:integer;
  end;

  TQuality = record
    id:string;
    identNumber:string;
    comment:string;
    dateAdded:string;
  end;

  TComment = record
    orderNumber:string;
    datetime:string;
    author:string;
    comment:string;
  end;

 // TBitBtn = class (Buttons.TBitBtn)
 //   protected
 //     procedure Create(TheOwner: TComponent); override;
 // end;

  { TForm1 }

  TForm1 = class(TForm)
    BitBtn1: TBitBtn;
    BitBtn10: TBitBtn;
    BitBtn11: TBitBtn;
    BitBtn2: TBitBtn;
    BitBtn3: TBitBtn;
    BitBtn4: TBitBtn;
    BitBtn5: TBitBtn;
    BitBtn6: TBitBtn;
    BitBtn7: TBitBtn;
    BitBtn8: TBitBtn;
    BitBtn9: TBitBtn;
    Button1: TButton;
    Button10: TButton;
    Button11: TButton;
    Button12: TButton;
    Button13: TButton;
    Button14: TButton;
    Button15: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    CheckBox1: TCheckBox;
    CheckBox10: TCheckBox;
    CheckBox11: TCheckBox;
    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;
    CheckBox4: TCheckBox;
    CheckBox5: TCheckBox;
    CheckBox6: TCheckBox;
    CheckBox7: TCheckBox;
    CheckBox8: TCheckBox;
    CheckBox9: TCheckBox;
    ComboBox1: TComboBox;
    ComboBox2: TComboBox;
    ComboBox3: TComboBox;
    ComboBox4: TComboBox;
    ComboBox5: TComboBox;
    Edit1: TEdit;
    Edit10: TEdit;
    Edit11: TEdit;
    Edit12: TEdit;
    Edit13: TEdit;
    Edit14: TEdit;
    Edit15: TEdit;
    Edit16: TEdit;
    Edit17: TEdit;
    Edit18: TEdit;
    Edit19: TEdit;
    Edit2: TEdit;
    Edit20: TEdit;
    Edit3: TEdit;
    Edit4: TEdit;
    Edit5: TEdit;
    Edit6: TEdit;
    Edit7: TEdit;
    Edit8: TEdit;
    Edit9: TEdit;
    GroupBox1: TGroupBox;
    Image1: TImage;
    Image2: TImage;
    Image3: TImage;
    ImageList1: TImageList;
    Label1: TLabel;
    Label10: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    Label13: TLabel;
    Label14: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Label18: TLabel;
    Label19: TLabel;
    Label2: TLabel;
    Label20: TLabel;
    Label21: TLabel;
    Label22: TLabel;
    Label23: TLabel;
    Label24: TLabel;
    Label25: TLabel;
    Label26: TLabel;
    Label27: TLabel;
    Label28: TLabel;
    Label29: TLabel;
    Label3: TLabel;
    Label30: TLabel;
    Label31: TLabel;
    Label32: TLabel;
    Label33: TLabel;
    Label34: TLabel;
    Label35: TLabel;
    Label36: TLabel;
    Label37: TLabel;
    Label38: TLabel;
    Label39: TLabel;
    Label4: TLabel;
    Label40: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    LabeledEdit1: TLabeledEdit;
    ListBox1: TListBox;
    ListBox10: TListBox;
    ListBox11: TListBox;
    ListBox12: TListBox;
    ListBox13: TListBox;
    ListBox14: TListBox;
    ListBox15: TListBox;
    ListBox16: TListBox;
    ListBox17: TListBox;
    ListBox2: TListBox;
    ListBox3: TListBox;
    ListBox4: TListBox;
    ListBox5: TListBox;
    ListBox6: TListBox;
    ListBox7: TListBox;
    ListBox8: TListBox;
    ListBox9: TListBox;
    MainMenu1: TMainMenu;
    Memo1: TMemo;
    Memo10: TMemo;
    Memo11: TMemo;
    Memo12: TMemo;
    Memo13: TMemo;
    Memo14: TMemo;
    Memo2: TMemo;
    Memo3: TMemo;
    Memo4: TMemo;
    Memo5: TMemo;
    Memo6: TMemo;
    Memo7: TMemo;
    Memo8: TMemo;
    Memo9: TMemo;
    MenuItem1: TMenuItem;
    MenuItem10: TMenuItem;
    MenuItem11: TMenuItem;
    MenuItem12: TMenuItem;
    MenuItem13: TMenuItem;
    MenuItem14: TMenuItem;
    MenuItem15: TMenuItem;
    MenuItem16: TMenuItem;
    MenuItem17: TMenuItem;
    MenuItem18: TMenuItem;
    MenuItem19: TMenuItem;
    MenuItem2: TMenuItem;
    MenuItem20: TMenuItem;
    MenuItem21: TMenuItem;
    MenuItem22: TMenuItem;
    MenuItem23: TMenuItem;
    MenuItem24: TMenuItem;
    MenuItem25: TMenuItem;
    MenuItem26: TMenuItem;
    MenuItem27: TMenuItem;
    MenuItem28: TMenuItem;
    MenuItem29: TMenuItem;
    MenuItem3: TMenuItem;
    MenuItem30: TMenuItem;
    MenuItem4: TMenuItem;
    MenuItem5: TMenuItem;
    MenuItem6: TMenuItem;
    MenuItem7: TMenuItem;
    MenuItem8: TMenuItem;
    MenuItem9: TMenuItem;
    OpenDialog1: TOpenDialog;
    OpenDialog2: TOpenDialog;
    OpenDialog3: TOpenDialog;
    OpenDialog4: TOpenDialog;
    OpenDialog5: TOpenDialog;
    OpenDialog6: TOpenDialog;
    OpenDialog7: TOpenDialog;
    OpenDialog8: TOpenDialog;
    PageControl1: TPageControl;
    PaintBox1: TPaintBox;
    PopupMenu1: TPopupMenu;
    ProgressBar1: TProgressBar;
    SaveDialog1: TSaveDialog;
    SaveDialog2: TSaveDialog;
    SaveDialog3: TSaveDialog;
    Shape1: TShape;
    Shape2: TShape;
    Shape3: TShape;
    SpinEdit1: TSpinEdit;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    procedure BitBtn10Click(Sender: TObject);
    procedure BitBtn11Click(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
    procedure BitBtn3Click(Sender: TObject);
    procedure BitBtn4Click(Sender: TObject);
    procedure BitBtn5Click(Sender: TObject);
    procedure BitBtn6Click(Sender: TObject);
    procedure BitBtn7Click(Sender: TObject);
    procedure BitBtn8Click(Sender: TObject);
    procedure BitBtn9Click(Sender: TObject);
    procedure Button11Click(Sender: TObject);
    procedure Button13Click(Sender: TObject);
    procedure Button14Click(Sender: TObject);
    procedure Button15Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure chkeckTypedDir(Sender: TObject; var Key: Word; Shift: TShiftState
      );
    procedure comatodot(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure ComboBox3Change(Sender: TObject);
    procedure ComboBox4Change(Sender: TObject);
    procedure Edit3Change(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure FormCloseQuery(Sender: TObject; var CanClose: boolean);
    procedure FormCreate(Sender: TObject);
    procedure FormPaint(Sender: TObject);
    procedure handleparams(Sender: TObject);
    procedure hcch(Sender: TObject);
    procedure hp2(Sender: TObject; const FileNames: array of String);
    procedure Image3Click(Sender: TObject);
    procedure Label36Click(Sender: TObject);
    procedure ListBox11Click(Sender: TObject);
    procedure loadpos(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure MenuItem10Click(Sender: TObject);
    procedure MenuItem11Click(Sender: TObject);
    procedure MenuItem12Click(Sender: TObject);
    procedure MenuItem13Click(Sender: TObject);
    procedure MenuItem14Click(Sender: TObject);
    procedure MenuItem15Click(Sender: TObject);
    procedure MenuItem16Click(Sender: TObject);
    procedure MenuItem17Click(Sender: TObject);
    procedure MenuItem19Click(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem20Click(Sender: TObject);
    procedure MenuItem21Click(Sender: TObject);
    procedure MenuItem22Click(Sender: TObject);
    procedure MenuItem23Click(Sender: TObject);
    procedure MenuItem24Click(Sender: TObject);
    procedure MenuItem25Click(Sender: TObject);
    procedure MenuItem26Click(Sender: TObject);
    procedure MenuItem28Click(Sender: TObject);
    procedure MenuItem29Click(Sender: TObject);
    procedure MenuItem30Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);
    procedure MenuItem7Click(Sender: TObject);
    procedure MenuItem8Click(Sender: TObject);
    procedure MenuItem9Click(Sender: TObject);
    procedure nospaces(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure onlyNum(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure PageControl1Change(Sender: TObject);
    procedure resizemainf(Sender: TObject);
    procedure sds(Sender: TObject);
    procedure setchmathod(Sender: TObject);
    procedure shlogf(Sender: TObject);
    procedure TabSheet2ContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
    procedure validate_piece_x400(Sender: TObject; var Key: Word;
      Shift: TShiftState);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form1: TForm1;
  end_table_line,offset,tableno,errorlevel,gel,vm:integer;
  plsr12sc,sizeset:boolean;
  sw_ver,sw_ver_minor:string;
  allowWpPos:TArrayOfString;
  elHMI: Array of TElectrode;
  bodies:Array of TAcisBody;
  hcel: Array of TElHyperCAD;
  activeOrders:Array of TFifoBox;
  qal: Array of TQuality;
  coms: Array of TComment;
  msg_com:string;
  msg_details:string;
  nxc:Array of TNXCoord;


implementation

{$R *.lfm}

function SplitString(const aSepator, aString:string;aMax:integer=0):TArrayOfString; stdcall; external 'libsaj64.dll';
function logToFile(path, inp: string): boolean; stdcall; external 'libsaj64.dll';

function strtopchar(inp:string):PAnsiChar;
var buf:array[0..1000] of Char;
  i:integer;
begin
 for i:=0 to 1000 do buf[i]:= #0;
 for i:=0 to length(inp) do begin
   buf[i]:=inp[i+1];
   strtopchar:=buf;
 end;
end;

function isNumber(s:string):boolean; //for electrodes, sometimes temporary E-number is given
var i:integer;
begin
     i:=1;
     while (i<=length(s)) and (s[i] in ['0'..'9','.','E']) do inc(i);
     result:=i>length(s);
end;
function isOnlyNumber(s:string):boolean; //amount of items, integer only
var i:integer;
begin
     i:=1;
     while (i<=length(s)) and (s[i] in ['0'..'9']) do inc(i);
     result:=i>length(s);
end;

function calcstrop(s:string):string;
var l:TArrayOfString;
begin
 if AnsiContainsStr(s,'+') then begin
    //def adding, no need to further check, just calc and return
    l:=SplitString('+',s);
    if ((l[0]='') or (l[1]='')) then result:=s //empty str = no change
    else result:=floattostr(strtofloat(l[0])+strtofloat(l[1]));
 end
 else if AnsiContainsStr(s,'-') then begin
  //need to check amoint of minuses, 1 is normal
    l:=SplitString('-',s);
    if length(l)=2 then begin
       if l[0]='' then result:=s //minus in front = no change
       else result:=floattostr(strtofloat(l[0])-strtofloat(l[1])); //positive - negative
    end
    else if length(l)=3 then begin
       result:=floattostr(strtofloat('-'+l[1])-strtofloat(l[2])); //negative-negative
    end
    else result:=s; //ignore if more minuses typed
 end
 else begin //no signs = no change
   result:=s;
 end;
end;

function isNumeric(s:string):boolean; stdcall; external 'libsaj64.dll';
function isNumeric2(s:string):boolean;
var i:integer;
begin
     i:=1;
     while (i<=length(s)) and (s[i] in ['0'..'9','-']) do inc(i);
     result:=i>length(s);
end;

function isSignedFloat(s:string):boolean; stdcall; external 'libsaj64.dll';

function normalize_c(inp:real):real;
begin
    repeat
    if inp>360 then inp:=inp-360;
    if inp<-360 then inp:=inp+360;
    until abs(inp)<360;
    if inp<-315 then result:=inp+360
    else if ((inp<-225) and (inp>-315)) then result:=inp+270
    else if ((inp<-135) and (inp>-225)) then result:=inp+180
    else if ((inp<-45)  and (inp>-135)) then result:=inp+90
    else if ((inp>-45) and (inp<45)) then result:=inp
    else if ((inp>45) and (inp<135)) then result:=inp-90
    else if ((inp>135) and (inp<225)) then result:=inp-180
    else if ((inp>225) and (inp<315)) then result:=inp-270
    else result:=inp-360;
end;

Function roundto(FloatNum: Double; NoOfDecPart: integer): Double;  // turncate
Var ls_FloatNumber: String;
Begin
 ls_FloatNumber := FloatToStr(FloatNum);
    IF Pos('.', ls_FloatNumber) > 0 Then Result := StrToFloat (copy(ls_FloatNumber, 1, Pos('.', ls_FloatNumber) - 1) + '.' + copy (ls_FloatNumber, Pos('.', ls_FloatNumber) + 1, NoOfDecPart))
    Else Result := FloatNum;
End;

function vdi_nr_to_ii(inp:string):integer;
begin
 case inp of
   'VDI42': result:=0;
   'VDI40': result:=1;
   'VDI38': result:=2;
   'VDI36': result:=3;
   'VDI34': result:=4;
   'VDI32': result:=5;
   'VDI30': result:=6;
   'VDI29': result:=7;
   'VDI28': result:=8;
   'VDI27': result:=9;
   'VDI26': result:=10; //default
   'VDI25': result:=11;
   'VDI24': result:=12;
   'VDI23': result:=13;
   'VDI22': result:=14;
   'VDI21': result:=15;
   'VDI20': result:=16;
   'VDI19': result:=17;
   'VDI18': result:=18;
   'VDI17': result:=19;
   'VDI16': result:=20;
   'VDI14': result:=21;
   'VDI12': result:=22;
   'VDI10': result:=23;
   'VDI7': result:=24;
   else result:=10; //in case of bad table input, choose default VDI26
 end;
end;

function vdi_ii_to_nr(inp:integer):string;
begin
 case inp of
   0: result:='VDI42';
   1: result:='VDI40';
   2: result:='VDI38';
   3: result:='VDI36';
   4: result:='VDI34';
   5: result:='VDI32';
   6: result:='VDI30';
   7: result:='VDI29';
   8: result:='VDI28';
   9: result:='VDI27';
   10: result:='VDI26';
   11: result:='VDI25';
   12: result:='VDI24';
   13: result:='VDI23';
   14: result:='VDI22';
   15: result:='VDI21';
   16: result:='VDI20';
   17: result:='VDI19';
   18: result:='VDI18';
   19: result:='VDI17';
   20: result:='VDI16';
   21: result:='VDI14';
   22: result:='VDI12';
   23: result:='VDI10';
   24: result:='VDI7';
 end;
end;


function sh_ii_to_hmi(inp:integer):string;
begin
 case inp of
   0: result:='50'; //3d
   1: result:='51'; //vector
   2: result:='52'; //cyl
   3: result:='54'; //rect
 end;
end;

function elmatii_input(inp:string):integer;
begin
 case inp of
   'Grafit1': result:=0;
   'Graphite1': result:=0;
   'Grafit2': result:=1;
   'Graphite2': result:=1;
   'Copper': result:=2;
   'Kupfer': result:=2;
   else result:=1;
 end;

end;

function elmatii_output(inp:integer):string;
begin
 case inp of
   0: result:='Graphite1';
   1: result:='Graphite2';
   2: result:='Copper';
   else result:='Graphite2';
 end;
end;

function wpmatii_to_hmi(inp:integer):string;
begin
 case inp of
   0: result:='AC';
   1: result:='CW';
   2: result:='AM';
   3: result:='TI';
   4: result:='ANI';
   5: result:='AL';
   6: result:='CU';
   7: result:='ECC';
   else result:='AC';
 end;
end;

function mat_x400(inp:string):string;
begin
 case inp of
   'Grafit1': result:='GF';
   'Graphite1': result:='GF';
   'Graphite2': result:='GM';
   'Copper': result:='CU';
   'Kupfer': result:='CU';
   else result:='GM';
 end;
end;

function mat_x400_code(inp:string):string;
begin
 case inp of
    'Grafit1': result:='1';
    'Graphite1': result:='1';
    'Graphite2': result:='2';
    'Copper': result:='4';
    'Kupfer': result:='4';
    else result:='2';
 end;
end;

function x400code_to_mat(inp:string):string;
begin
 case inp of
    '1': result:='Graphite1';
    '2': result:='Graphite2';
    '4': result:='Copper';
    else result:='Graphite1';
 end;
end;

function ii_to_agie_pmat(inp:integer):string;
begin
 case inp of
   0: result:='0001'; //steel
   1: result:='0002'; //hard metal
   2: result:='0003'; //aluminium
   3: result:='0004'; //titanium
   4: result:='0005'; //copper
   5: result:='0006'; //coper base alloy
   6: result:='0007'; //nickel base alloy
   7: result:='0008'; //cast iron
 end;
end;

function agie_elmat_to_str(inp:string):string;
begin
 case inp of
   '0001': result:='Graphite1';
   '0002': result:='Graphite2';
   '0004': result:='Copper';
 end;
end;

function intar_to_hmiList(inp: array of integer):string;
var i,j:integer;
begin
  // runs of 3+ consecutive numbers as "a-b", everything else separated by "." (HMI normalizes it anyway)
  result:='';
  i:=0;
  while i<=high(inp) do begin
     j:=i;
     while ((j<high(inp)) and (inp[j+1]=inp[j]+1)) do inc(j);
     if result<>'' then result:=result+'.';
     if j-i>=2 then begin
        result:=result+inttostr(inp[i])+'-'+inttostr(inp[j]);
        i:=j+1;
     end
     else begin
        result:=result+inttostr(inp[i]);
        inc(i);
     end;
  end;
end;

function getDateHMI():string;
 var fd:string;
 begin
     DateTimeToString(fd,'yyyy/mm/dd hh:nn:ss',Now);
     getDateHMI:=StringReplace(fd,'-','/',[rfReplaceAll]);
     //getDateHMI:='f';
 end;

procedure langStrings();
begin

end;

procedure setChanged(state:boolean);
begin
 Form1.CheckBox6.Checked:=state;
end;

//procedure logToFile(inp,typ:string);
//var lf:TextFile;
//  fd:string;
//begin
// //showmessage('test1');
//   DateTimeToString(fd,'yyyy-mm-dd hh:nn:ss',Now);
//   //showmessage('test2');
//   AssignFile(lf,Application.Location+'\logfile'+inttostr(YearOf(Now))+'.log');
//   if (fileexists(Application.Location+'\logfile'+inttostr(YearOf(Now))+'.log')=false) then begin
//     rewrite(lf);
//     writeln(lf,fd+' Log started');
//     end
//   else Append(lf);
//   writeln(lf,fd+' '+typ+' '+inp);
//   CloseFile(lf);
//end;

function vdi_num_to_agie(inp:string):string;
begin
 case inp of //write the choosen surface quality
          'VDI42': result:='VDI_42Ra12.6oxxo,1,$,  12.60000';
          'VDI40': result:='VDI_40Ra10.0oxxo,1,$,  10.00000';
          'VDI38': result:='VDI_38Ra7.9oxxo,1,$,  7.900000';
          'VDI36': result:='VDI_36Ra6.3oxxo,1,$,  6.300000';
          'VDI34': result:='VDI_34Ra5.0oxxo,1,$,  5.000000';
          'VDI32': result:='VDI_32Ra4.0oxxo,1,$,  4.000000';
          'VDI30': result:='VDI_30Ra3.17oxxo,1,$,  3.170000';
          'VDI29': result:='VDI_29Ra2.82oxxo,1,$,  2.820000';
          'VDI28': result:='VDI_28Ra2.51oxxo,1,$,  2.510000';
          'VDI27': result:='VDI_27Ra2.24oxxo,1,$,  2.240000';
          'VDI26': result:='VDI_26Ra2.0oxxo,1,$,  2.000000';
          'VDI25': result:='VDI_25Ra1.78oxxo,1,$,  1.780000';
          'VDI24': result:='VDI_24Ra1.59oxxo,1,$,  1.590000';
          'VDI23': result:='VDI_23Ra1.41oxxo,1,$,  1.410000';
          'VDI22': result:='VDI_22Ra1.26oxxo,1,$,  1.260000';
          'VDI21': result:='VDI_21Ra1.12oxxo,1,$,  1.120000';
          'VDI20': result:='VDI_20Ra1.0oxxo,1,$,  1.000000';
          'VDI19': result:='VDI_19Ra0.89oxxo,1,$,  0.890000';
          'VDI18': result:='VDI_18Ra0.79oxxo,1,$,  0.790000';
          'VDI17': result:='VDI_17Ra0.71oxxo,1,$,  0.710000';
          'VDI16': result:='VDI_16Ra0.65oxxo,1,$,  0.650000';
          'VDI14': result:='VDI_14Ra0.5oxxo,1,$,  0.500000';
          'VDI12': result:='VDI_12Ra0.4oxxo,1,$,  0.400000';
          'VDI10': result:='VDI_10Ra0.32oxxo,1,$,  0.320000';
          'VDI7': result:='VDI_7Ra0.22oxxo,1,$,  0.220000';
          else begin
              result:='VDI_26Ra2.0oxxo,1,$,  2.000000'; //to prevent program crashing the machine on bad table input
              logToFile(Application.Location,'ERR wrong VDI number, usinng default (26)');
              end;
     end;

end;

procedure load_ncvisu_csv(inp:string);
var i:integer;
  l:TArrayOfString;
begin
     Form1.ListBox1.Clear;
     Form1.ListBox2.Clear;
     Form1.ListBox3.Clear;
     Form1.ListBox4.Clear;
     Form1.ListBox5.Clear;
     Form1.ListBox6.Clear;
     Form1.ListBox7.Clear;
     Form1.ListBox8.Clear;
     Form1.ListBox9.Clear;
     Form1.ListBox10.Clear;
     Form1.ListBox11.Clear;
     Form1.ListBox12.Clear;
     Form1.ListBox14.Clear;
     Form1.ListBox15.Clear;
     Form2.ListBox1.Clear;
     Form2.ListBox2.Clear;
     Form2.CheckListBox1.Clear;
     if FileExists(inp) then begin
        Form1.CheckBox10.Checked:=true;
        Form1.Memo11.Lines.LoadFromFile(inp);
        for i:=0 to Form1.Memo11.Lines.Count-1 do begin
            l:=SplitString(';',Form1.Memo11.Lines[0]);
            Form1.Edit3.Text:=leftstr(l[1],7);
            if AnsiContainsStr(Form1.Memo11.Lines[i],';Unset;') then begin //electrode pos line
               l:=SplitString(';',Form1.Memo11.Lines[i]);
               Form1.ListBox2.Items.Add(leftstr(l[0],12)); //name
               Form1.ListBox3.Items.Add(l[2]); //X
               Form1.ListBox4.Items.Add(l[3]); //Y
               Form1.ListBox5.Items.Add(l[5]); //C
               Form1.ListBox6.Items.Add(l[4]); //Z
               Form1.ListBox7.Items.Add(l[9]); //mat
               Form1.ListBox8.Items.Add('0');
               Form1.ListBox9.Items.Add('Z');
               Form1.ListBox11.Items.Add('10');
               Form1.ListBox12.Items.Add(l[8]); //vdi
               Form1.ListBox14.Items.Add('0');
               Form1.ListBox15.Items.Add('0');
            end;
        end;
     end;

end;

procedure load_csv(inp:string);
var cf:TextFile;
  j,k:integer;
  line,csvtype,path:string;
  l0,l1,l2:TArrayOfString;
  namr,generated,el_exists,elfrrem:boolean;
  ust:TIniFile;
begin
     AssignFile(cf,inp);
     reset(cf);
     Form1.ListBox1.Clear;
     Form1.ListBox2.Clear;
     Form1.ListBox3.Clear;
     Form1.ListBox4.Clear;
     Form1.ListBox5.Clear;
     Form1.ListBox6.Clear;
     Form1.ListBox7.Clear;
     Form1.ListBox8.Clear;
     Form1.ListBox9.Clear;
     Form1.ListBox10.Clear;
     Form1.ListBox11.Clear;
     Form1.ListBox12.Clear;
     Form1.ListBox14.Clear;
     Form1.ListBox15.Clear;
     Form2.ListBox1.Clear;
     Form2.ListBox2.Clear;
     Form2.CheckListBox1.Clear;
     namr:=False; //next line has workpiece name
     generated:=False; //csv generated by dxf2agieghp
     csvtype:='excelcsv';
     readln(cf,line);
     ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   path:=ust.ReadString('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output');
     if ust.ReadString('settings','autoRemoveELFR','0') = '1' then elfrrem:=true
     else elfrrem:=false;
     if AnsiContainsStr(line,'Beschreibung Werkstueck') then csvtype:='pureseb';
     if AnsiContainsStr(line,'Material Number;') then begin
        csvtype:='gtis';
        l0:=SplitString(';',line);
             l1:=SplitString('-',l0[1]);
             Form1.Edit3.Text:=l1[0];
     end;
     repeat
        readln(cf,line);
        //showmessage(csvtype);
        case csvtype of
           'excelcsv': begin
           l0:=SplitString(';',line);
           if namr then Form1.Edit3.Text:=l0[0];
           if l0[0]='Materialno.' then namr:=True
           else namr:=False;
           if l0[0]='Yes' then begin
             Form1.ListBox2.Items.Add(l0[2]); //name
             Form1.ListBox3.Items.Add(l0[6]); //x
             Form1.ListBox4.Items.Add(l0[7]); //y
             Form1.ListBox5.Items.Add(l0[8]); //c
             Form1.ListBox9.Items.Add(l0[9]); //dir
             Form1.ListBox6.Items.Add(l0[10]); //z
             Form1.ListBox12.Items.Add(l0[11]); //vdi
             Form1.ListBox7.Items.Add(l0[12]); //mat el
             Form1.ListBox8.Items.Add(l0[13]); //fp
             Form1.ListBox11.Items.Add(ust.ReadString('settings','defaultSideOffset','5')); // side offset
             Form1.ListBox14.Items.Add('0');
             Form1.ListBox15.Items.Add('0');
             end;
           end;
           'pureseb': begin
               l0:=SplitString(';',line);
               if namr then Form1.Edit3.Text:=l0[0];
               if ((line='NAME; PIECE_WIDTH; PIECE_LENGTH; PIECE_HEIGHT; MATR; X; Y') or (line='NAME;PIECE_WIDTH;PIECE_LENGTH;PIECE_HEIGHT;MATR;;;;;;;;;;;;;;;;;;;;;;;;')) then namr:=True
               else namr:=False;
               if line='generated;dxf2agiehp' then generated:=True;
               //showmessage(inttostr(length(l0)));
               if ((length(l0)=29) and (length(l0[4])>=1) and (l0[4]<>' ') and isSignedFloat(l0[4])) then begin
                 if AnsiContainsStr(l0[0],'/') then begin
                     l1:=SplitString('/',l0[0]);
                     //Form1.ListBox2.Items.Add(l1[2]);
                     if elfrrem then begin
                   if AnsiContainsStr(l1[2],'EL-FR-') then begin
                      l2:=SplitString('-',l1[2]);
                      Form1.ListBox2.Items.Add(AnsiLeftStr(l2[2],7)); //name
                   end
                   else Form1.ListBox2.Items.Add(l1[2]); //name
                 end
                 else Form1.ListBox2.Items.Add(l1[2]); //name
                 end
                 else if elfrrem then begin
                   if AnsiContainsStr(l0[0],'EL-FR-') then begin
                      l1:=SplitString('-',l0[0]);
                      Form1.ListBox2.Items.Add(AnsiLeftStr(l1[2],7)); //name
                   end
                   else Form1.ListBox2.Items.Add(l0[0]); //name
                 end
                 else Form1.ListBox2.Items.Add(l0[0]); //name
                 Form1.ListBox3.Items.Add(l0[4]); //x
                 Form1.ListBox4.Items.Add(l0[5]); //y
                 Form1.ListBox5.Items.Add(l0[6]); //c
                 if generated then begin //hidden dir as electrode width
                   case l0[1] of
                      '10': Form1.ListBox9.Items.Add('Z');
                      '11': Form1.ListBox9.Items.Add('X+');
                      '12': Form1.ListBox9.Items.Add('X-');
                      '13': Form1.ListBox9.Items.Add('Y+');
                      '14': Form1.ListBox9.Items.Add('Y-');
                      else Form1.ListBox9.Items.Add('Z');
                   end;
                 end
                 else Form1.ListBox9.Items.Add(l0[7]); //dir
                 Form1.ListBox6.Items.Add(l0[8]); //z
                 Form1.ListBox12.Items.Add(l0[9]); //vdi
                 Form1.ListBox7.Items.Add(l0[10]); //mat el
                 Form1.ListBox8.Items.Add(l0[11]); //fp
                 if generated then Form1.ListBox11.Items.Add(l0[2]) //hidden as el depth
                 else Form1.ListBox11.Items.Add(ust.ReadString('settings','defaultSideOffset','5')); // side offset
                 if generated then begin
                   j:=(Form1.ListBox2.Count-1);
                   el_exists:=False; //mark electrode as not exist
                   if Form2.CheckListBox1.Count>0 then begin
                      for k:=0 to (Form2.CheckListBox1.Count-1) do begin //for each already known electrode
                          if Form2.CheckListBox1.Items[k]=trim(Form1.ListBox2.Items[j]) then el_exists:=True; //mark electrode that already exist
                      end;
                   end;
                   if el_exists=False then begin //if electrode is marked not existing
                      Form2.CheckListBox1.Items.Add(trim(Form1.ListBox2.Items[j])); //add to visible list
                      Form2.CheckListBox1.Checked[(Form2.CheckListBox1.Count-1)]:=True;
                      if Form1.CheckBox1.Checked=False then begin
                         if Form1.CheckBox4.Checked=False then Form2.ListBox1.Items.Add(trim(Form1.ListBox2.Items[j])+';'+Form1.ListBox7.Items[j]+';'+Form1.ListBox8.Items[j]+';'+l0[13]+';'+l0[15]+';'+l0[17]+';'+l0[19]+';0;0;'+l0[12]+';'+l0[14]+';'+l0[16]+';'+l0[18]+';0;0;'+trim(Form1.ListBox2.Items[j])+';0;'+Form1.ListBox9.Items[j]+';5;0;'+Form1.ListBox12.Items[j]) //add parameters to invisible list
                         else Form2.ListBox1.Items.Add(trim(Form1.ListBox2.Items[j])+';'+Form1.ListBox7.Items[j]+';'+Form1.ListBox8.Items[j]+';'+l0[13]+';'+l0[15]+';'+l0[17]+';'+l0[19]+';0;0;'+l0[12]+';'+l0[14]+';'+l0[16]+';'+l0[18]+';0;0;'+trim(Form1.ListBox2.Items[j])+';0;'+Form1.ListBox9.Items[j]+';5;0;'+vdi_ii_to_nr(Form1.ComboBox2.ItemIndex)); // replace vdi
                      end
                      else begin
                           if Form1.CheckBox4.Checked=False then Form2.ListBox1.Items.Add(trim(Form1.ListBox2.Items[j])+';'+Form1.ComboBox1.Items[Form1.ComboBox1.ItemIndex]+';'+Form1.ListBox8.Items[j]+';'+l0[13]+';'+l0[15]+';'+l0[17]+';'+l0[19]+';0;0;'+l0[12]+';'+l0[14]+';'+l0[16]+';'+l0[18]+';0;0;'+trim(Form1.ListBox2.Items[j])+';0;'+Form1.ListBox9.Items[j]+';5;0;'+Form1.ListBox12.Items[j])  // replace material if choosen so
                           else Form2.ListBox1.Items.Add(trim(Form1.ListBox2.Items[j])+';'+Form1.ComboBox1.Items[Form1.ComboBox1.ItemIndex]+';'+Form1.ListBox8.Items[j]+';'+l0[13]+';'+l0[15]+';'+l0[17]+';'+l0[19]+';0;0;'+l0[12]+';'+l0[14]+';'+l0[16]+';'+l0[18]+';0;0;'+trim(Form1.ListBox2.Items[j])+';0;'+Form1.ListBox9.Items[j]+';5;0;'+vdi_ii_to_nr(Form1.ComboBox2.ItemIndex));  // replace material if choosen so + replace vdi
                      end;
                   end;
                 end;
                 Form1.ListBox14.Items.Add('0'); //a
                 Form1.ListBox15.Items.Add('0'); //b
               end;
           end;
           'gtis': begin
             l0:=SplitString(';',line);
             if ((length(l0[0])=12) and (length(l0[10])<>0)) then begin
               Form1.ListBox2.Items.Add(l0[0]);
               Form1.ListBox3.Items.Add(l0[2]);
               Form1.ListBox4.Items.Add(l0[3]);
               Form1.ListBox6.Items.Add(l0[4]);
               Form1.ListBox5.Items.Add(l0[5]);
               Form1.ListBox8.Items.Add(l0[7]);
               Form1.ListBox12.Items.Add('VDI'+l0[8]);
               Form1.ListBox7.Items.Add(l0[9]);
               Form1.ListBox9.Items.Add('Z');
               Form1.ListBox11.Items.Add('10');
               Form1.ListBox14.Items.Add('0');
               Form1.ListBox15.Items.Add('0');
             end;
           end;
        end; //case
     until eof(cf);
     if Form1.Edit3.Text='nil' then begin
       if not AnsiContainsStr(inp,'nil') then begin
           l0:=SplitString('_',inp);
           l1:=SplitString('.',l0[1]);
           Form1.Edit3.Text:=l1[0];
       end;

     end;
     Form1.CheckBox7.Checked:=generated;
     if generated then Form2.Label13.Caption:='done';
     ust.Free;
     logToFile(Application.Location,'OK Loaded CSV: '+inp+' ('+inttostr(Form1.ListBox2.Items.Count)+' positions)');
     Form1.Button7.Enabled:=True;
     CloseFile(cf);
     setChanged(true);
     Form1.Label17.Visible:=directoryExists(path+'\'+Form1.Edit3.Text);
end;

procedure load_edf(inp:string);
var rf:TextFile;
  line,path,fil_ver,v15b:string;
  l1,l2:TArrayOfString;
  ust:TIniFile;
  i:integer;
begin
     // load saved state of 2 main forms.
     AssignFile(rf,inp);
     reset(rf);
     Form1.ListBox1.Clear;
     Form1.ListBox2.Clear;
     Form1.ListBox3.Clear;
     Form1.ListBox4.Clear;
     Form1.ListBox5.Clear;
     Form1.ListBox6.Clear;
     Form1.ListBox7.Clear;
     Form1.ListBox8.Clear;
     Form1.ListBox9.Clear;
     Form1.ListBox10.Clear;
     Form1.ListBox11.Clear;
     Form1.ListBox12.Clear;
     Form1.ListBox14.Clear;
     Form1.ListBox15.Clear;
     Form2.ListBox1.Clear;
     Form2.ListBox2.Clear;
     Form2.CheckListBox1.Clear;
     Form1.Edit16.Text:='00'; //backwards compability for files older than v15
     Form1.CheckBox10.Checked:=False; //backwards compability for files older than v21
     repeat
        readln(rf,line);
        if AnsiContainsStr(line,'DXF2AGIEHPv') then begin
           l1:=SplitString('v',line);
           if l1[1]<>sw_ver then begin
              if vm>=2 then ShowMessage('Uwaga! Wczytany plik zostal zapisany w innej wersji programu. Sprawdź poprawnosc danych.'+AnsiString(#13#10)+'Wersja aplikacji: '+sw_ver+AnsiString(#13#10)+'Wersja pliku: '+l1[1]);
              logToFile(Application.Location,'INF Current version: '+sw_ver+', file version: '+l1[1]);
           end;
           fil_ver:=l1[1];
        end
        else begin
          l1:=SplitString(':',line);
          case l1[0] of
             'zme': begin
               if l1[1]='1' then Form1.CheckBox1.Checked:=True
               else Form1.CheckBox1.Checked:=False;
             end;
             'zjp': begin
               if l1[1]='1' then Form1.CheckBox4.Checked:=True
               else Form1.CheckBox4.Checked:=False;
             end;
             'crgr': begin
               if l1[1]='1' then Form1.CheckBox3.Checked:=True
               else Form1.CheckBox3.Checked:=False;
             end;
             'hypercad': begin
               if l1[1]='1' then Form1.CheckBox10.Checked:=True
               else Form1.CheckBox10.Checked:=False;
             end;
             'matel': Form1.ComboBox1.ItemIndex:=strtoint(l1[1]);
             'vdisel': Form1.ComboBox2.ItemIndex:=strtoint(l1[1]);
             'matdet': Form1.ComboBox4.ItemIndex:=strtoint(l1[1]);
             'prname': Form1.Edit3.Text:=l1[1];
             'odlx': Form1.Edit11.Text:=l1[1];
             'odly': Form1.Edit12.Text:=l1[1];
             'odlz': Form1.Edit13.Text:=l1[1];
             'odlc': Form1.Edit14.Text:=l1[1];
             'ilekol': Form1.SpinEdit1.Value:=strtoint(l1[1]);
             'lbpwt': Form1.ListBox1.Items.Add(l1[1]);
             'lbname': Form1.ListBox2.Items.Add(l1[1]);
             'lbx': Form1.ListBox3.Items.Add(l1[1]);
             'lby': Form1.ListBox4.Items.Add(l1[1]);
             'lbc': Form1.ListBox5.Items.Add(l1[1]);
             'lbz': Form1.ListBox6.Items.Add(l1[1]);
             'lbmat': Form1.ListBox7.Items.Add(l1[1]);
             'lbfp': Form1.ListBox8.Items.Add(l1[1]);
             'lbdirb': Form1.ListBox9.Items.Add(l1[1]);
             'lbodsb': Form1.ListBox11.Items.Add(l1[1]);
             'lbvdi': Form1.ListBox12.Items.Add(l1[1]);
             'lba': Form1.ListBox14.Items.Add(l1[1]);
             'lbb': Form1.ListBox15.Items.Add(l1[1]);
             'lbf21': begin
                           if strtoint(fil_ver)>=16 then Form2.ListBox1.Items.Add(l1[1])
                           else begin
                              l2:=SplitString(';',l1[1]);  //compatibility for older versions
                              v15b:=l2[0]+';'+l2[1]+';'+l2[2]+';'+l2[3]+';'+l2[4]+';'+l2[5]+';'+l2[6]+';0;0;'+l2[7]+';'+l2[8]+';'+l2[9]+';'+l2[10]+';0;0;'+l2[11]+';'+l2[12]+';'+l2[13]+';'+l2[14]+';'+l2[15]+';'+l2[16];
                              if length(l2)=18 then v15b:=v15b+';'+l2[17];
                              //ShowMessage(inttostr(length(l2)));
                              Form2.ListBox1.Items.Add(v15b);
                           end;
                      end;
             'lbf22': Form2.ListBox2.Items.Add(l1[1]);
             'zbyhand': begin
                  if l1[1]='0' then begin
                       Form2.Edit16.Enabled:=False;
                       Form2.Edit17.Enabled:=False;
                       Form2.Edit18.Enabled:=False;
                       Form2.Edit19.Enabled:=False;
                       Form2.Edit20.Enabled:=False;
                       Form2.Edit21.Enabled:=False;
                  end
                  else begin
                       Form2.Edit16.Enabled:=True;
                       Form2.Edit17.Enabled:=True;
                       Form2.Edit18.Enabled:=True;
                       Form2.Edit19.Enabled:=True;
                       Form2.Edit20.Enabled:=True;
                       Form2.Edit21.Enabled:=True;
                  end;
             end;
             'eld': Form2.Label13.Caption:=l1[1];
             'clbf2': begin
               Form2.CheckListBox1.Items.Add(l1[1]);
               if l1[2]='1' then Form2.CheckListBox1.Checked[(Form2.CheckListBox1.Count-1)]:=True
               else Form2.CheckListBox1.Checked[(Form2.CheckListBox1.Count-1)]:=False;
             end;
             'date': Form1.Edit15.Text:=l1[1];
             'ai': Form1.Edit16.Text:=l1[1];
             'magpos_x400': Form1.LabeledEdit1.Text:=l1[1]; //added in v17
             'wp_amount': Form1.Edit20.Text:=l1[1]; //added in v23 - can be empty
             'name_cd': Form1.Edit18.Text:=l1[1]; //added in v23 - can be empty
             'order': Form1.Edit19.Text:=l1[1]; //added in v25
             'dodsk': begin
               if l1[1]='1' then Form1.CheckBox8.Checked:=True
               else Form1.CheckBox8.Checked:=False;
             end;
             'generated': begin
               if l1[1]='1' then Form1.CheckBox7.Checked:=True
               else Form1.CheckBox7.Checked:=False;
             end;
          end;
        end;
     until eof(rf);
     CloseFile(rf);
     if strtoint(fil_ver)<19 then begin //populate listboxes 14 and 15 (compat)
         for i:=0 to Form1.ListBox2.Count-1 do begin
           Form1.ListBox14.Items[i]:='0';
           Form1.ListBox15.Items[i]:='0';
         end;
     end;
     Form1.Caption:='EDMPGM ['+inp+']';
     ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
     path:=ust.ReadString('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output');
     ust.Free;
     Form1.Label17.Visible:=directoryExists(path+'\'+Form1.Edit3.Text);
     Form1.CheckBox5.Checked:=True;
     Form1.SaveDialog1.FileName:=inp;
     Form1.Button7.Enabled:=True;
     logToFile(Application.Location,'OK Loaded file '+inp+' succesfully');
     setChanged(false);
end;

function extractValue (inp:string):string; //from xml line with exactly 1 <tag>value</tag>
var l0,l1:TArrayOfString;
begin
   l0:=SplitString('>',inp);
   l1:=SplitString('<',l0[1]);
   extractValue:=l1[0];
end;

function nullAsZero(inp:string):string;
var rv:string;
begin
    if length(inp)=0 then rv:='0'
    else rv:=inp;
    nullAsZero:=rv;
end;

procedure load_hypercad(inp:string);
var i:integer;
  tmpel:TElHyperCAD;
  deleteOld:TModalResult;
begin
   setlength(hcel,0);
   deleteOld:=mrYes;
   if Form1.ListBox2.Items.Count>0 then begin
       deleteOld:=MessageDlg('Usunąć istniejące najazdy?',mtConfirmation,[mbYes,mbNo],0);
   end;
   if deleteOld=mrYes then begin
   Form1.ListBox1.Clear;
   Form1.ListBox2.Clear;
   Form1.ListBox3.Clear;
   Form1.ListBox4.Clear;
   Form1.ListBox5.Clear;
   Form1.ListBox6.Clear;
   Form1.ListBox7.Clear;
   Form1.ListBox8.Clear;
   Form1.ListBox9.Clear;
   Form1.ListBox10.Clear;
   Form1.ListBox11.Clear;
   Form1.ListBox12.Clear;
   Form1.ListBox14.Clear;
   Form1.ListBox15.Clear;
   end;
   Form2.ListBox1.Clear;
   Form2.ListBox2.Clear;
   Form2.CheckListBox1.Clear;
   if FileExists(inp) then begin
     if AnsiContainsStr(inp,'ELElectrodeSummary') then begin
         Form1.CheckBox10.Checked:=true;
         Form1.Memo11.Lines.LoadFromFile(inp);
         for i:=0 to Form1.Memo11.Lines.Count-1 do begin
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<PartNumber>') then Form1.Edit3.Text:=extractValue(Form1.memo11.Lines[i]);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<ElectrodeMaterial>') then tmpEl.material:=extractValue(Form1.Memo11.Lines[i]);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<Name>') then tmpEl.name:=leftstr(extractValue(Form1.Memo11.Lines[i]),12);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<CAngle>') then tmpEl.pos_c:= StringReplace(extractValue(Form1.Memo11.Lines[i]),'°','',[rfReplaceAll]);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<TargetPositionX>') then tmpEl.pos_x:=extractValue(Form1.Memo11.Lines[i]);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<TargetPositionY>') then tmpEl.pos_y:=extractValue(Form1.Memo11.Lines[i]);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<TargetPositionZ>') then tmpEl.pos_z:=extractValue(Form1.Memo11.Lines[i]);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<EdmSurfaceArea>') then tmpEl.fp:=floattostr(strtofloat(extractValue(Form1.Memo11.Lines[i]))/100);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<VDISurfaceTolerance>') then tmpEl.vdi:='VDI'+extractValue(Form1.Memo11.Lines[i]);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<ElectrodeRoughnessV>') then tmpEl.roughness_v:=strtofloat(nullAsZero(extractValue(Form1.Memo11.Lines[i])))*(-1);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<ElectrodeRoughnessVV>') then tmpEl.roughness_vv:=strtofloat(nullAsZero(extractValue(Form1.Memo11.Lines[i])))*(-1);
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<NumberV>') then tmpEl.number_v:=strtoint(extractValue(Form1.Memo11.Lines[i]));
               if AnsiContainsStr(Form1.Memo11.Lines[i],'<NumberVV>') then tmpEl.number_vv:=strtoint(extractValue(Form1.Memo11.Lines[i]));
               if AnsiContainsStr(Form1.Memo11.Lines[i],'</Electrode>') then begin
                 //add line, and save state
                 Form1.ListBox2.Items.Add(tmpel.name);
                 Form1.ListBox3.Items.Add(tmpel.pos_x);
                 Form1.ListBox4.Items.Add(tmpel.pos_y);
                 Form1.ListBox5.Items.Add(tmpel.pos_c);
                 Form1.ListBox6.Items.Add(tmpel.pos_z);
                 Form1.ListBox7.Items.Add(tmpel.material);
                 Form1.ListBox8.Items.Add('0'); //calculated wrong in hypercad -not read from file, zero instead
                 Form1.ListBox9.Items.Add('Z');
                 Form1.ListBox11.Items.Add('10');
                 Form1.ListBox12.Items.Add(tmpel.vdi);
                 Form1.ListBox14.Items.Add('0');
                 Form1.ListBox15.Items.Add('0');
                 setLength(hcel,length(hcel)+1);
                 hcel[high(hcel)]:=tmpel;
               end;
         end;
         if Form1.Edit3.Text='' then Form1.Edit3.Text:=leftstr(extractFileName(inp),7);
         logToFile(Application.Location,'OK Loaded form HyperCAD: '+inp+' ('+inttostr(Form1.ListBox2.Items.Count)+' positions)');
         setChanged(true);

     end
     else begin
       showmessage('Nie ten plik.'+AnsiString(#13#10)+'Otwórz plik "ElectrodeSummary"');
       logToFile(Application.Location,'ERR load_htpercad: wrong file selected');
     end;
   end
   else begin
     showmessage('Plik nie istnieje');
     logToFile(Application.Location,'ERR load_hypercad: file doesnt exist');
   end;
end;

procedure load_xmlj(inp:string);
var fil:TextFile;
lin:string;
t0,t1,t2,t3,px,py,pz,pc,pfd,pax,paz,tn,tft,tus,tmp,tx,ty,tz,tc,shape_tools,shape_points,shape_vdi,shape_depth,shape_name,shape_fp,shape_mat,unam,ufil,uele,uemat,bea_nam,bea_vdi,ufp:TArrayOfString;
date_done,pieces_section,points_section,shapes_section,tools_section:boolean;
curr_point,curr_tool,curr_shape,i,j,k,ces:integer;
sp_x,sp_y,sp_z:real;
begin
 //XML prasing libraries tried:
        // 1. TXMLDocument - doesnt support windows 1250 encoding used by HMI software, confusing way of navigating xml structure
        // 2. MSXML - not supported by lazarus.
        // SO prasing this as a txt file
        AssignFile(fil,inp);
        reset(fil);
        date_done:=False;
        pieces_Section:=False;
        points_section:=False;
        shapes_section:=False;
        tools_section:=False;
        Form1.LabeledEdit1.Text:='';
        SetLength(px,1);
        SetLength(py,1);
        SetLength(pz,1);
        SetLength(pc,1);
        SetLength(pax,1); //angle x, for side eroding
        SetLength(paz,1); //angle z, for side eroding
        //SetLength(pfd,1);
        SetLength(tn,1);
        SetLength(shape_vdi,1);
        SetLength(shape_points,1);
        SetLength(shape_tools,1);
        SetLength(shape_depth,1);
        SetLength(shape_name,1);
        SetLength(shape_fp,1);
        SetLength(shape_mat,1);
        Form1.Edit11.Text:='-0.00';
        Form1.Edit12.Text:='-0.00';
        Form1.Edit13.Text:='-0.00';
        Form1.Edit14.Text:='0';
        repeat
           readln(fil,lin);
           if AnsiContainsStr(lin,'<Job Name=') then begin //program name
              t0:=SplitString('"',lin);
              Form1.Edit3.Text:=t0[1];
           end;
           if AnsiContainsStr(lin,'<CreationDate>') and not date_done then begin //creation date
              t0:=SplitString('>',lin);
              t1:=SplitString(' ',t0[1]);
              Form1.Edit15.Text:=t1[0];
              date_done:=True;
           end;
           if AnsiContainsStr(lin,'<Pieces>') then pieces_section:=True;
           if AnsiContainsStr(lin,'</Pieces>') then pieces_section:=False;
           if AnsiContainsStr(lin,'<MagPos>') and pieces_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              if Form1.LabeledEdit1.Text='' then Form1.LabeledEdit1.Text:=t1[0]
              else Form1.LabeledEdit1.Text:=Form1.LabeledEdit1.Text+','+t1[0];
           end;
           if AnsiContainsStr(lin,'<Points>') then points_section:=True;
           if AnsiContainsStr(lin,'</Points>') then points_section:=False;
           if AnsiContainsStr(lin,'<Point N="') and points_section then begin
              t0:=SplitString('"',lin);
              curr_point:=strtoint(t0[1]);
           end;
           if AnsiContainsStr(lin,'<X>') and points_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(px,length(px)+1);
              px[curr_point]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<Y>') and points_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(py,length(px)+1);
              py[curr_point]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<Z>') and points_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(pz,length(px)+1);
              pz[curr_point]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<Rot>') and points_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(pc,length(px)+1);
              pc[curr_point]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<AngleX>') and points_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(pax,length(pax)+1);
              pax[curr_point]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<AngleZ>') and points_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(paz,length(paz)+1);
              paz[curr_point]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<Tools>') then tools_section:=True;
           if AnsiContainsStr(lin,'</Tools>') then tools_section:=False;
           if AnsiContainsStr(lin,'<Tool N="') and tools_section then begin
              t0:=SplitString('"',lin);
              curr_tool:=strtoint(t0[1]);
           end;
           if AnsiContainsStr(lin,'<Name>') and tools_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('_',t0[1]);
              SetLength(tn,length(tn)+1);
              tn[curr_tool]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<Shapes>') then shapes_section:=True;
           if AnsiContainsStr(lin,'</Shapes>') then shapes_section:=False;
           if AnsiContainsStr(lin,'<Shape N="') and shapes_section then begin
              t0:=SplitString('"',lin);
              curr_shape:=strtoint(t0[1]);
           end;
           if AnsiCOntainsStr(lin,'<EDMDepth>') and shapes_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(shape_depth,length(shape_depth)+1);
              shape_depth[curr_shape]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<PrepSurfaceFinishingCH>') and shapes_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(shape_vdi,length(shape_vdi)+1);
              shape_vdi[curr_shape]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<JobReportToolList>') and shapes_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(shape_tools,length(shape_tools)+1);
              shape_tools[curr_shape]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<JobReportPointList>') and shapes_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(shape_points,length(shape_points)+1);
              shape_points[curr_shape]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<ElectMaterialCode>') and shapes_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(shape_mat,length(shape_mat)+1);
              shape_mat[curr_shape]:=t1[0];
           end;
           if AnsiContainsStr(lin,'<PrepMaxArea>') and shapes_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(shape_fp,length(shape_fp)+1);
              shape_fp[curr_shape]:=t1[0];
           end;

           if AnsiContainsStr(lin,'<Comment>') and shapes_section then begin
              t0:=SplitString('>',lin);
              t1:=SplitString('<',t0[1]);
              SetLength(shape_name,length(shape_name)+1);
              if AnsiContainsStr(t1[0],'-') then begin
                 t2:=SplitString('-',t1[0]);
                 shape_name[curr_shape]:=t2[1];
              end
              else shape_name[curr_shape]:=t1[0];
           end;
        until eof(fil);
        CloseFile(fil);
        Form1.ListBox2.Clear;
        Form1.ListBox3.Clear;
        Form1.ListBox4.Clear;
        Form1.ListBox5.Clear;
        Form1.ListBox6.Clear;
        Form1.ListBox7.Clear;
        Form1.ListBox8.Clear;
        Form1.ListBox9.Clear;
        Form1.ListBox11.Clear;
        Form1.ListBox12.Clear;
        Form1.ListBox14.Clear;
        Form1.ListBox15.Clear;

        for i:=1 to length(px)-1 do begin //add points of electrodes to the table

            Form1.ListBox3.Items.Add(px[i]);
            Form1.ListBox4.Items.Add(py[i]);
            Form1.ListBox5.Items.Add(pc[i]);
            Form1.ListBox11.Items.Add(pz[i]); //startpoint
            if paz[i]='0' then Form1.ListBox9.Items.Add('Z')
            else if paz[i]='90' then begin
                case pax[i] of
                    '0': Form1.ListBox9.Items.Add('X-');
                    '90': Form1.ListBox9.Items.Add('Y-');
                    '180': Form1.ListBox9.Items.Add('X+');
                    '270': Form1.ListBox9.Items.Add('Y+');
                    else Form1.ListBox9.Items.Add('AB');
                end;
            end
            else if paz[i]='-90' then begin //happens when manually changing direction in HMI
                case pax[i] of
                    '0': Form1.ListBox9.Items.Add('X+');
                    '90': Form1.ListBox9.Items.Add('Y+');
                    '180': Form1.ListBox9.Items.Add('X-');
                    '270': Form1.ListBox9.Items.Add('Y-');
                    else Form1.ListBox9.Items.Add('AB');
                end;
            end
            else begin
                Form1.ListBox9.Items.Add('AB');
            end;
            Form1.ListBox14.Items.Add(paz[i]);
            Form1.ListBox15.Items.Add(pax[i]);
            ces:=0;
            for j:=1 to length(shape_depth)-1 do begin
                if AnsiContainsStr(shape_points[j],'.') then begin //2 points per shape
                   t0:=SplitString('.',shape_points[j]);
                   for k:=0 to length(t0)-1 do if i=strtoint(t0[k]) then ces:=j;
                end
                else if AnsiContainsStr(shape_points[j],'-') then begin //multiple points per shape
                   t0:=SplitString('-',shape_points[j]);
                   for k:=strtoint(t0[0]) to strtoint(t0[1]) do if i=k then ces:=j;
                end
                else begin //simple case - 1 point per shape
                    if i=strtoint(shape_points[j]) then ces:=j;
                end;
            end;
            if ces=0 then begin
               logToFile(Application.Location,'ERR Error in .xmlj file - no shape points ('+inp+')');
               if vm>=1 then showmessage('Error in .xmlj file (no shape points found)');
            end
            else begin
                // showmessage(shape_name[ces]);
               Form1.ListBox2.Items.Add(shape_name[ces]);
               Form1.ListBox6.Items.Add(floattostr(strtofloat(shape_depth[ces])*(-1)));
               Form1.ListBox7.Items.Add(x400code_to_mat(shape_mat[ces]));
               Form1.ListBox8.Items.Add(shape_fp[ces]);
               Form1.ListBox12.Items.Add('VDI'+shape_vdi[ces]);

            end;

        end;
        //Showmessage('Points: '+inttostr(curr_point)+', Tools: '+inttostr(curr_tool)+', Shapes: '+inttostr(curr_shape));
        //for i:=1 to length(px)-1 do showmessage(px[i]);
        logToFile(Application.Location,'OK Loaded file '+inp);
end;

procedure load_agievision(inp:string);
begin

end;

procedure getQual();
var fil:TextFile;
tmp,tmpIdent,tmpComm,tmpData:string;
l0,l1,l2:TArrayOfString;
i,j:integer;
begin
   setLength(qal,0);
   if FileExists('qal.txt') then begin
        AssignFile(fil,'qal.txt');
        reset(fil);
        readln(fil,tmp);
        l0:=SplitString('},{',tmp);
        CloseFile(fil);
        for i:=0 to high(l0) do begin
            tmpIdent:='none';
            tmpComm:='none';
            tmpData:='none';
            l1:=SplitString(',"',l0[i]);
            for j:=0 to high(l1) do begin
               if AnsiContainsStr(l1[j],'identNumber"') then begin
                  l2:=SplitString('"',l1[j]);
                  tmpIdent:=l2[2];
               end;
               if AnsiContainsStr(l1[j],'comment"') then begin
                  l2:=SplitString('"',l1[j]);
                  tmpComm:=l2[2];
               end;
               if AnsiContainsStr(l1[j],'dataDodania"') then begin
                  l2:=SplitString('"',l1[j]);
                  tmpData:=l2[2];
               end;
            end;
            setLength(qal,length(qal)+1);
            qal[high(qal)].id:=inttostr(i);
            qal[high(qal)].identNumber:=tmpIdent;
            qal[high(qal)].comment:=tmpComm;
            qal[high(qal)].dateAdded:=tmpData;
        end;

   end;
end;

procedure getComs();
var active,tmpMach:boolean;
tmp,tmpOrder,tmpAuthor,tmpDate,tmpComment:string;
l0,l1,l2:TArrayOfString;
i,j:integer;
fil:TextFile;
begin
    setLength(coms,0);
    if FileExists('com.txt') then begin
        AssignFile(fil,'com.txt');
        reset(fil);
        readln(fil,tmp);
        l0:=SplitString('},{',tmp);
        CloseFile(fil);
        for i:=0 to high(l0) do begin
            tmpOrder:='none';
            tmpComment:='none';
            tmpDate:='none';
            tmpAuthor:='none';
            tmpMach:=false;
            active:=false;
            l1:=SplitString(',"',l0[i]);
            for j:=0 to high(l1) do begin
               if AnsiContainsStr(l1[j],'orderNumber"') then begin
                  l2:=SplitString('"',l1[j]);
                  tmpOrder:=l2[2];
               end;
               if AnsiContainsStr(l1[j],'comment"') then begin
                  l2:=SplitString('"',l1[j]);
                  tmpComment:=l2[2];
               end;
               if AnsiContainsStr(l1[j],'datetime"') then begin
                  l2:=SplitString('"',l1[j]);
                  tmpDate:=l2[2];
               end;
               if AnsiContainsStr(l1[j],'author"') then begin
                  l2:=SplitString('"',l1[j]);
                  tmpAuthor:=l2[2];
               end;
               if AnsiContainsStr(l1[j],'forTS"') then begin
                  l2:=SplitString('"',l1[j]);
                  if ((l2[2]='all') or (l2[2]='TS-36') or (l2[2]='TS-38') or (l2[2]='TS-44') or (l2[2]='TS-58') or (l2[2]='TS-61')) then tmpMach:=true;
               end;
               if AnsiContainsStr(l1[j],'visible"') then begin
                  l2:=SplitString(':',l1[j]);
                  if l2[1]='true' then active:=true;
               end;
            end;
            if active and tmpMach then begin
               setLength(coms,length(coms)+1);
               coms[high(coms)].orderNumber:=tmpOrder;
               coms[high(coms)].comment:=tmpComment;
               coms[high(coms)].datetime:=tmpDate;
               coms[high(coms)].author:=tmpAuthor;
            end;
        end;
        if vm>2 then showmessage('Comments: '+inttostr(length(coms)));
    end;
end;

procedure getActiveOrders();
var tmp,tmpIdent,tmpKWZ,tmpOrder,tmpFifo,tmpDotCol,ds,str,tmpBm7Plan,tmpBm7Target,tmpKlient,tmpLinia,tmpMatname,tmpRDE,tmpTechnolog,tmpKonstruktor,tmpProjectSize,tmpGtisNumber:string;
l0,l1,l2,l3,l4:TArrayOfString;
fil:TextFile;
i,j,k,tmp_pt,tmp_ac,tmp_q:integer;
active,tmpOnMachine:boolean;
begin
     setLength(activeOrders,0);
     DateTimeToString(str,'yyyy',Now());
     ds:=str+'-';
     DateTimeToString(str,'mm',Now());
     ds:=ds+str+'-';
     DateTimeToString(str,'dd',Now());
     ds:=ds+str;
     if FileExists('out.txt') then begin
        AssignFile(fil,'out.txt');
        reset(fil);
        readln(fil,tmp);
        l0:=SplitString('},{',tmp);
        CloseFile(fil);
        for i:=0 to high(l0) do begin
            tmpIdent:='none';
            tmpKWZ:='none';
            tmpOrder:='none';
            tmpFifo:='none';
            l1:=SplitString(',"',l0[i]);
            for j:=0 to high(l1) do begin
                if AnsiContainsStr(l1[j],'fifoNumber"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpFifo:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'identNumber"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpIdent:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'orderNumber"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpOrder:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'kwzNumber"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpKwz:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'projectSize"') then begin
                   l2:=SplitString('"',l1[j]);
                   l3:=SplitString(':',l2[2]);
                   tmpProjectSize:=l3[0];
                   tmpGtisNumber:=l3[1];
                end;
                if AnsiContainsStr(l1[j],'lastSeen"') then begin
                   l2:=SplitString('"',l1[j]);
                   l3:=SplitString('T',l2[2]);
                   if ds=l3[0] then active:=true
                   else active:=false;
                end;
                if AnsiContainsStr(l1[j],'dotColor"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpDotCol:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'matname"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpMatname:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'realDateEntry"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpRDE:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'dotColor"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpDotCol:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'onMachine"') then begin
                   l2:=SplitString(':',l1[j]);
                   if l2[1]='true' then tmpOnMachine:=true
                   else tmpOnMachine:=false;
                end;
                if AnsiContainsStr(l1[j],'technolog"') then begin
                   l2:=SplitString(':',l1[j]);
                   tmpTechnolog:=StringReplace(l2[1],'"','',[rfReplaceAll]);
                end;
                if AnsiContainsStr(l1[j],'konstruktor"') then begin
                   l2:=SplitString(':',l1[j]);
                   tmpKonstruktor:=StringReplace(l2[1],'"','',[rfReplaceAll]);
                end;
                if AnsiContainsStr(l1[j],'bm7targetDT"') then begin
                   l2:=SplitString('"',l1[j]);
                   l3:=SplitString('T',l2[2]);
                   tmpBm7Target:=l3[0];
                end;
                if AnsiContainsStr(l1[j],'bm7planDT"') then begin
                   l2:=SplitString('"',l1[j]);
                   l3:=SplitString('T',l2[2]);
                   tmpBm7Plan:=l3[0];
                end;
                if AnsiContainsStr(l1[j],'linia"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpLinia:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'klient"') then begin
                   l2:=SplitString('"',l1[j]);
                   tmpKlient:=l2[2];
                end;
                if AnsiContainsStr(l1[j],'quantity"') then begin
                   l2:=SplitString('"',l1[j]);
                   l3:=SplitString(':',l2[1]);
                   l4:=SplitString('}',l3[1]);
                   tmp_q:=strtoint(l4[0]);
                end;

                if AnsiContainsStr(l1[j],'planTimes"') then begin
                   l2:=SplitString('"',l1[j]);
                   l3:=SplitString(';',l2[2]);
                   //showmessage(inttostr(length(l3)));
                   for k:=0 to high(l3) do begin
                       if AnsiContainsStr(l3[k],'enie wg') then begin
                          //showmessage(l3[k]);
                          break;

                       end;
                   end;

                   l4:=SplitString(':',l3[k]);
                   if length(l4)>=6 then begin
                      tmp_pt:=strtoint(l4[1]);
                      tmp_ac:=strtoint(l4[5]);
                   end
                   else begin
                       tmp_pt:=0;
                       tmp_ac:=0;
                   end;
                end;
            end;
            if active then begin
               setLength(activeOrders,length(activeOrders)+1);
               activeOrders[high(activeOrders)].id:=inttostr(i);
               activeOrders[high(activeOrders)].identNumber:=tmpIdent;
               activeOrders[high(activeOrders)].kwzNumber:=tmpKwz;
               activeOrders[high(activeOrders)].orderNumber:=tmpOrder;
               activeOrders[high(activeOrders)].fifoNumber:=tmpFifo;
               activeOrders[high(activeOrders)].bm7Plan:=tmpBm7Plan;
               activeOrders[high(activeOrders)].bm7Target:=tmpBm7Target;
               activeOrders[high(activeOrders)].confirmedTime:=tmp_ac;
               activeOrders[high(activeOrders)].plannedTime:=tmp_pt;
               activeOrders[high(activeOrders)].dotColor:=tmpDotCol;
               activeOrders[high(activeOrders)].gtisNumber:='12';
               activeOrders[high(activeOrders)].linia:=tmpLinia;
               activeOrders[high(activeOrders)].klient:=tmpKlient;
               activeOrders[high(activeOrders)].matname:=tmpMatname;
               activeOrders[high(activeOrders)].onMachine:=tmpOnMachine;
               activeOrders[high(activeOrders)].technolog:=tmpTechnolog;
               activeOrders[high(activeOrders)].konstruktor:=tmpKonstruktor;
               activeOrders[high(activeOrders)].realDateEntry:=tmpRDE;
               activeOrders[high(activeOrders)].quantity:=tmp_q;
               activeOrders[high(ActiveOrders)].projectSize:=tmpProjectSize;
               activeOrders[high(ActiveOrders)].gtisNumber:=tmpGtisNumber;
            end;
        end;
        //showmessage('Active orders: '+inttostr(length(activeOrders)));

    end;
end;

function matforagie(inp:string):string;
begin
 case inp of
     'Grafit1': result:='0001'; //SEB
     'Graphite1': result:='0001';
     'Grafit 3neu': result:='0001'; //SEB
     'Grafit2': result:='0002'; //SEB
     'Graphite2': result:='0002';
     'Graphite2/Graphite3': result:='0002'; // CREO default
     'Copper': result:='0004';
     end;
end;

{ TForm1 }



procedure TForm1.shlogf(Sender: TObject);
begin
 logToFile(Application.Location,'INF log shown');
  Form6.ShowModal;
end;

procedure TForm1.TabSheet2ContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin

end;

procedure TForm1.validate_piece_x400(Sender: TObject; var Key: Word;
  Shift: TShiftState);
var pa:TArrayOfString;
  ok,thisMagPosIsOk:boolean;
  i,j:integer;
  ust:TIniFile;
begin
   //ok:=True;
   //if length(LabeledEdit1.Text)>0 then begin
   //   pa:=SplitString(',',LabeledEdit1.Text);
   //   for i:=0 to length(pa)-1 do begin
   //     if ((isNumeric2(pa[i])) and (length(pa[i])>0)) then if pa[i]<>'-' then if ((strtoint(pa[i])<1) or (strtoint(pa[i])>48)) then ok:=False;
   //     if length(pa[i])=0 then ok:=False;
   //     if not isNumeric2(pa[i]) then ok:=False;
   //     if pa[i]='-' then ok:=False;
   //   end;
   //end;
   ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   if ust.ReadBool('mag','strictMode',true) then begin
   pa:=SplitString(',',LabeledEdit1.Text);
   ok:=True;
   for i:=0 to high(pa) do begin
       thisMagPosIsOk:=False;
      for j:=0 to high(allowWpPos) do begin
         if pa[i]=allowWpPos[j] then thisMagPosIsOk:=True
      end;
      if not thisMagPosIsOk then ok:=False;
   end;
   if ok then begin
      LabeledEdit1.Color:=clDefault;
      BitBtn9.Enabled:=true;
   end
   else begin
       LabeledEdit1.Color:=clRed;
       BitBtn9.Enabled:=false;
   end;
   end;
   ust.Free;
end;


procedure TForm1.Button1Click(Sender: TObject); //Legacy: load DXF or mi
var fil:Textfile;
  sl,newsl:TStringList;
  acceptable_list:Array[1..41] of string;
  line,savedline,str,path,fold,lineminus1,lineminus2,lineminus3:string;
  res,fileext:TArrayOfString; //used for SplitString function output
  org_cur_line,new_current_line,norm_line,current_line,start_line,text_per_item,i,j,k,col_id,col_x,col_y,col_c,col_z,col_mat,col_fp,col_dir,col_diro,col_vdi,min_in_col,si,old_count,start_pos,maxtables,maxline:integer;
  start_defined,assign_columns_done,table_done,col_count_found,is_acceptable,alternate_method,nextlineid,plkp20z:boolean;
  ust:TIniFile;
begin
    ProgressBar1.Position:=0;
    offset:=0;
    ListBox1.Clear;
    ListBox2.Clear;
    ListBox3.Clear;
    ListBox4.Clear;
    ListBox5.Clear;
    ListBox6.Clear;
    ListBox7.Clear;
    ListBox8.Clear;
    ListBox9.Clear;
    ListBox11.Clear;
    ListBox12.Clear;
    ListBox13.Clear;
    ListBox14.Clear;
    ListBox15.Clear;
    Form2.CheckListBox1.Clear;
    Form2.ListBox1.Clear;
    if length(OpenDialog1.Filename)>3 then begin  // open file dialog, show error if no file is selected
     maxtables:=0;
     maxline:=0;
     AssignFile(fil,OpenDialog1.FileName); //dxf file choosen by user
    reset(fil);
    repeat //find out number of eroding tables in file
    lineminus3:=lineminus2;  //remember 3 previous lines
    lineminus2:=lineminus1;
    lineminus1:=line;
    readln(fil,line);
    if AnsiContainsStr(line,'Electrodes are used for the following parts') then inc(maxtables);
    if AnsiContainsStr(line,'Elektroden werden fuer folgende Teile verwendet') then inc(maxtables);
    if AnsiContainsStr(line,'Elektroden werden für folgende Teile verwendet') then inc(maxtables);
    if AnsiContainsStr(line,'Elektroden werden fur folgende Teile verwendet') then inc(maxtables);
    if (length(lineminus1)=2) then begin // find out ai number
       if isNumeric(lineminus1) then begin
          //dxf
          if (lineminus2='  1') then begin
             if (line='  7') then begin
                if (lineminus3='     1') then begin
                   if (((strtoint(Edit16.Text)+1)=strtoint(lineminus1)) or (Edit6.Text='00')) then begin
                      //showmessage(lineminus3+AnsiString(#13#10)+lineminus2+AnsiString(#13#10)+lineminus1+AnsiString(#13#10)+line); //debug
                      Edit16.Text:=lineminus1;
                   end;
                end;
             end;
          end;
          //mi
          if (lineminus2='1') then begin
             if (line='0') then begin
                if (lineminus3='0') then begin
                   if (((strtoint(Edit16.Text)+1)=strtoint(lineminus1)) or (Edit6.Text='00')) then begin
                      //showmessage(lineminus3+AnsiString(#13#10)+lineminus2+AnsiString(#13#10)+lineminus1+AnsiString(#13#10)+line); //debug
                      Edit16.Text:=lineminus1;
                   end;
                end;
             end;
          end;
       end;
    end;
    inc(maxline);
    until eof(fil);
    CloseFile(fil);
    Label15.Caption:='/ '+inttostr(maxtables);
    fileext:=SplitString('.',OpenDialog1.FileName);
    if CheckBox2.Checked=True then begin // reverse the dxf
       sl:=TStringList.Create;  //oop bullshit
       newsl:=TStringList.Create;  //oop bullshit
       sl.LoadFromFile(OpenDialog1.FileName); //load dxf into stringlist
       for si:=(sl.Count-1) downto 1 do newsl.Add(sl.Strings[si]); //reverse the stringlist
       sl.Destroy;
       newsl.SaveToFile(Application.Location+'temp.'+fileext[(length(fileext)-1)]); //save reversed stringlist to temp file
       newsl.Destroy;
       AssignFIle(fil,Application.Location+'temp.'+fileext[(length(fileext)-1)]); //use the temp file instead of the original dxf
    end
    else AssignFile(fil,OpenDialog1.FileName); //dxf file choosen by user
    reset(fil);                 //ensure reading from begining of the file
    current_line:=0;            //pre-set all varribles
    start_line:=0;
    start_defined:=False;       //dxf reading stage for "electrodes used for..."
    assign_columns_done:=False;  //dxf reading stage for first row of table
    table_done:=False;            //dxf reading stage for end table
    alternate_method:=False;
    nextlineid:=False;
    plkp20z:=False;           // special case indicator for certain kind of dxf made by 1 person with bad CREO configuration
    col_count_found:=False;  //reset this to allow tables of different column amount in the same dxf
    if LowerCase(fileext[(length(fileext)-1)])='dxf' then text_per_item:=30 // TODO: possibly change this to be readed from dxf file itself, it may vary
    else if LowerCase(fileext[(length(fileext)-1)])='mi' then text_per_item:=34
    else if vm>=1 then ShowMessage('FileType Error!');
    ProgressBar1.Position:=10;
    repeat
      if length(line)=7 then savedline:=line;
      readln(fil,line);  //read 1 line
      inc(current_line);  //increase counter for line number
      if current_line>=end_table_line then begin // discarrd line numbers lower than start position, for second table
         if start_defined=False then res:=SplitString(':',line);
         if length(line)>=1 then begin //to avoid crashing on empty lines
            if start_defined=False then if (((trim(res[0])='Electrodes are used for the following parts') or (trim(res[0])='Elektroden werden fuer folgende Teile verwendet') or (trim(res[0])='Elektroden werden für folgende Teile verwendet') or (trim(res[0])='Elektroden werden f\U+00fcr folgende Teile verwendet') or (trim(res[0])='Elektroden werden fur folgende Teile verwendet')) and (length(res[1])>=6)) then begin //find start of position table

               //if (length(res[1])<=6) then begin
               //   res[1]:=trim(savedline);
               //   nextlineid:=True;
               //end;
               Edit3.Text:=LeftStr(trim(res[1]),7); //save part number (turncate to prevent rare cases of long texi in this line)
               start_line:=current_line; //define starting point of position table
               if plsr12sc=True then start_line:=start_line+6;
               start_defined:=True;
               ProgressBar1.Position:=20;
            end;
            if start_defined=True then begin
               if col_count_found=False then begin //try to find first electrode name, in order to determine no of columns
                  for i:=1 to 15 do if current_line=(start_line+(i*text_per_item)) then begin
                      if trim(line)='Z' then plkp20z:=True;
                      if (((length(trim(line))=7) and (isNumber(trim(line)))) or (AnsiContainsStr(trim(line),'EL-FR'))) then begin
                            col_count_found:=True;
                            org_cur_line:=current_line;
                            SpinEdit1.Value:=(((current_line-start_line) div text_per_item)-1); //save found table width
                            if plkp20z=True then SpinEdit1.Value:=SpinEdit1.Value-1;
                            reset(fil);
                            new_current_line:=0;
                            for j:=1 to (current_line-(text_per_item*SpinEdit1.Value)) do begin //go back to the line of table start
                                inc(new_current_line);
                                readln(fil,line);
                            end;
                            current_line:=new_current_line;
                      end;
                   end;
               end;
               if col_count_found=true then begin
               acceptable_list[1]:='ID no. for electrode';
               acceptable_list[2]:='X';
               acceptable_list[3]:='Y';
               acceptable_list[4]:='Angle of rotation';
               acceptable_list[5]:='Countersink depth';
               acceptable_list[6]:='Electrode material';
               acceptable_list[7]:='Height';
               acceptable_list[8]:='Workpiece surface';
               acceptable_list[9]:='U1';
               acceptable_list[10]:='U2';
               acceptable_list[11]:='Proj. face';
               acceptable_list[12]:='Eroding direction';
               acceptable_list[13]:='ID-NR';
               acceptable_list[14]:='ELEKTR-NUMMER';
               acceptable_list[15]:='Id-Nr Elektrode';
               acceptable_list[16]:='TIEFE';
               acceptable_list[17]:='WINKEL';
               acceptable_list[18]:='Drehwinkel';
               acceptable_list[19]:='Senktiefe';
               acceptable_list[20]:='Elektrodenwerkstoff';
               acceptable_list[21]:='Erodierrichtung';
               acceptable_list[22]:='Oberflaeche Werkstueck';
               acceptable_list[23]:='Proj. Flaeche';
               acceptable_list[24]:='Auslenkmethode';
               acceptable_list[25]:='Z';  //special case for some of plkp20 drawings
               acceptable_list[26]:='Excursion method';
               acceptable_list[27]:='Auslenkmethode';
               acceptable_list[28]:='Oberfläche Werkstück';  //vdi
               acceptable_list[29]:='Proj. Fläche';
               acceptable_list[30]:='Length'; //plgd special case
               acceptable_list[31]:='Width'; //not seen on real drawings, just in case
               acceptable_list[32]:='Positioning path';  //Creo option, not seen in real drawings
               acceptable_list[33]:='Erodierr.';
               acceptable_list[34]:='Id-Nr El.';
               acceptable_list[35]:='Obfl. Werkst.';  //vdi
               acceptable_list[36]:='El.-Werkst.';
               acceptable_list[37]:='Laenge';
               acceptable_list[38]:='Breite';
               acceptable_list[39]:='Hoehe';
               acceptable_list[40]:='Positionierstrecke';
               acceptable_list[41]:='bugfix_nons';

               i:=0;
               if ListBox1.Count<SpinEdit1.Value then repeat
                 inc(i);
               if (current_line=(start_line+(i*text_per_item)+offset)) then begin //every read 10 values, every 30 lines
                  is_acceptable:=False;
                  for j:=1 to length(acceptable_list) do if trim(line)=acceptable_list[j] then is_acceptable:=True;
                  //showmessage(line);
                  if is_acceptable=False then begin  //special case for some of plkk44 drawings
                     for k:=1 to 6 do begin
                         inc(offset);
                         readln(fil,line);
                     end
                  end;

                  //if offset<>0 then SpinEdit1.Value:=((((SpinEdit1.Value*text_per_item)-offset) div text_per_item)-1);
                  is_acceptable:=False;
                  for j:=1 to length(acceptable_list) do begin
                           if trim(line)=acceptable_list[j] then begin
                   is_acceptable:=True;
                  end
                  else begin
                      end;
                  end;
                  if is_acceptable=True then if trim(line)<>'Z' then ListBox1.Items.Add(line); //add those lines to listbox
                  //break;
               end;
               if ((((length(trim(line))=7) and (isNumber(trim(line))))) or (AnsiContainsStr(trim(line),'EL-FR'))) then begin
                  if offset<>0 then begin
                     SpinEdit1.Value:=SpinEdit1.Value-1;
                     ListBox2.Items.Add(trim(line));
                  end;
                  break;

               end;
               until i>SpinEdit1.Value;
               if (assign_columns_done=True and table_done=False) then begin
               //read actual data
               if ((offset=0) and (alternate_method=False)) then begin
                   if ((current_line-start_line) mod text_per_item)=0 then begin //only lines containing data
                      norm_line:=((current_line-start_line) div text_per_item); //normalized line number
                      if ((norm_line-1) mod (SpinEdit1.Value))=col_id then ListBox2.Items.Add(trim(line));  //add items to appropriate listboxes
                      if ((norm_line-1) mod (SpinEdit1.Value))=col_x then ListBox3.Items.Add(trim(line));
                      if ((norm_line-1) mod (SpinEdit1.Value))=col_y then ListBox4.Items.Add(trim(line));
                      if ((norm_line-1) mod (SpinEdit1.Value))=col_c then ListBox5.Items.Add(trim(line));
                      if ((norm_line-1) mod (SpinEdit1.Value))=col_z then ListBox6.Items.Add(trim(line));
                      if ((norm_line-1) mod (SpinEdit1.Value))=col_mat then ListBox7.Items.Add(trim(line));
                      if ((norm_line-1) mod (SpinEdit1.Value))=col_fp then ListBox8.Items.Add(trim(line));
                      if ((norm_line-1) mod (SpinEdit1.Value))=col_dir then ListBox9.Items.Add(trim(line));
                      if ((norm_line-1) mod (SpinEdit1.Value))=col_vdi then ListBox12.Items.Add(trim(line));

                   end;
                   if (((line='ENDBLK')or (line='LIN')) and (current_line>(start_line+200))) then begin  // magic number 200 :( its to be sure to not exceen length of table
                      //showmessage('current_line: '+inttostr(current_line)+', start_line: '+inttostr(start_line)+', line: '+line);  //debug message
                      table_done:=True;  //do not continue after this
                      end_table_line:=(current_line+1); //start line to search for next table
                      ProgressBar1.Position:=40;
                   end;
                   end
                   else begin
                        //TODO the strange dxf files with varrible distances between important lines
                        SpinEdit1.Value:=(((SpinEdit1.Value*text_per_item)-offset) div text_per_item);
                        current_line:=current_line+offset;
                        offset:=0;
                        alternate_method:=True;
                        //WILL NOT FIX - NO SOLUTION - OPEN .DXF AND SAVE AS .MI AND IT WILL WORK
                        // Or generate new table form 3D
                        // or use SEB
                   end;
               end;
               if ListBox1.Count>=SpinEdit1.Value then if assign_columns_done=False then begin //assign columns when all read, if not already done
                  //pre-set varribles to 9999 - means no column present
                  col_id:=9999;
                  col_x:=9999;
                  col_y:=9999;
                  col_z:=9999;
                  col_c:=9999;
                  col_mat:=9999;
                  col_fp:=9999;
                  col_dir:=9999;
                  col_diro:=9999;
                  col_vdi:=9999;
                  for i:=0 to (SpinEdit1.Value-1) do begin //read every item
                      case ListBox1.Items[i] of  //and check for every needed column name
                           'ID no. for electrode': col_id:=i;
                           'X': col_x:=i;
                           'Y': col_y:=i;
                           'Angle of rotation': col_c:=i;
                           'Countersink depth': col_z:=i;
                           'Electrode material': col_mat:=i;
                           'Proj. face': col_fp:=i;
                           'ID-NR': col_id:=i; //german
                           'ELEKTR-NUMMER': col_id:=i; //german alt
                           'Id-Nr Elektrode': col_id:=i; //german alt
                           'Id-Nr El.': col_id:=i;
                           'TIEFE': col_z:=i; //german
                           'WINKEL': col_c:=i; //german
                           'Drehwinkel': col_c:=i; //german alt
                           'Senktiefe': col_z:=i; //german alt
                           'Elektrodenwerkstoff': col_mat:=i; //german
                           'El.-Werkst.': col_mat:=i;
                           'Eroding direction': col_dir:=i;
                           'Proj. Flaeche': col_fp:=i;
                           'Proj. Fläche': col_fp:=i;
                           'Erodierrichtung': col_dir:=i;
                           'Erodierr.': col_dir:=i;
                           'Workpiece surface': col_vdi:=i;
                           'Oberflaeche Werkstueck': col_vdi:=i;
                           'Oberfläche Werkstück': col_vdi:=i;
                           'Obfl. Werkst.': col_vdi:=i;
                      end;
                  end;
                  assign_columns_done:=True; //only do this once per table
                  ProgressBar1.Position:=30;
               end;
               end; // col count found=true
            end; //start defined=true
         end;  //length of line >1
      end; //current line>= end table line
    until eof(fil);
    CloseFile(fil);
    ProgressBar1.Position:=50;
    //evaluation of data
    ProgressBar1.Position:=60;
    //delete additional things (for reverse order)
    if ListBox2.Count>0 then begin
       start_pos:=0;
       i:=0;
       repeat
         //showmessage(inttostr(length(ListBox2.Items[i])));
       if ((length(ListBox2.Items[i])<>7) and (not (AnsiContainsStr(ListBox2.Items[i],'EL-FR')))) then start_pos:=i;  // 28-06-17 bugfix (added 'not')
       //showmessage(inttostr(i));
       inc(i);
       until ((start_pos>0) or (i>=ListBox2.Count));
       if start_pos=0 then start_pos:=ListBox2.Count;
       //showmessage(inttostr(start_pos));
       old_count:=ListBox2.Count-1;
       if (ListBox2.Count)>start_pos then for j:=old_count downto (start_pos) do ListBox2.Items.Delete(j);
       old_count:=ListBox3.Count-1;
       if (ListBox3.Count)>start_pos then for j:=old_count downto (start_pos) do ListBox3.Items.Delete(j);
       old_count:=ListBox4.Count-1;
       if (ListBox4.Count)>start_pos then for j:=old_count downto (start_pos) do ListBox4.Items.Delete(j);
       old_count:=ListBox6.Count-1;
       if (ListBox6.Count)>start_pos then for j:=old_count downto (start_pos) do ListBox6.Items.Delete(j);
    end;
    if ((ListBox7.Count=0) and (col_mat=9999)) then for i:=0 to (ListBox2.Count-1) do ListBox7.Items.Add('Graphite2'); //in case material was not in dxf table
    if ((ListBox8.Count=0) and (col_fp=9999)) then for i:=0 to (ListBox2.Count-1) do ListBox8.Items.Add('0'); // in case fp was not in dxf table
    if ((ListBox5.Count=0) and (col_c=9999)) then for i:=0 to (ListBox2.Count-1) do ListBox5.Items.Add('0');  // in case C was not in dxf table
    if ((ListBox9.Count=0) and (col_dir=9999)) then for i:=0 to (ListBox2.Count-1) do ListBox9.Items.Add('Z'); // in case eroding direction was not in dxf table
    if ((ListBox11.Count=0) and (col_diro=9999)) then for i:=0 to (ListBox2.Count-1) do ListBox11.Items.Add('5'); // in case eroding direction was not in dxf table
    if ((ListBox12.Count=0) and (col_vdi=9999)) then for i:=0 to (ListBox2.COunt-1) do ListBox12.Items.Add('VDI26'); //change this to respect user choice
    if ListBox2.Count>0 then begin
       old_count:=ListBox5.Count-1;
       if (ListBox5.Count)>start_pos then for j:=old_count downto (start_pos) do ListBox5.Items.Delete(j);
       old_count:=ListBox7.Count-1;
       if (ListBox7.Count)>start_pos then for j:=old_count downto (start_pos) do ListBox7.Items.Delete(j);
       old_count:=ListBox8.Count-1;
       if (ListBox8.Count)>start_pos then for j:=old_count downto (start_pos) do ListBox8.Items.Delete(j);
       old_count:=ListBox9.Count-1;
       if (ListBox9.Count)>start_pos then for j:=old_count downto (start_pos) do ListBox9.Items.Delete(j);
       old_count:=ListBox12.Count-1;
       if (ListBox12.Count)>start_pos then for j:=old_count downto (start_pos) do ListBox12.Items.Delete(j);
    end;
    for i:=0 to ListBox2.Count-1 do ListBox14.Items.Add('0');
    for i:=0 to ListBox2.Count-1 do ListBox15.Items.Add('0');
    ProgressBar1.Position:=70;
    setChanged(True);
    logToFile(Application.Location,'INF loaded file '+OpenDialog1.FileName);
    if length(Edit3.Text)<2 then begin
       inc(errorlevel);
       logToFile(Application.Location,'ERR wrong file - no table header found. errorlevel='+inttostr(errorlevel));
    end
    else begin
         if ((ListBox2.Count>0) and (ListBox2.Count=ListBox3.Count)) then begin
         inc(tableno);
         Label14.Caption:=inttostr(tableno);
        end;
    end;
    end //no file selected
    else if ((plsr12sc=True) and (CheckBox2.Checked=True)) then begin
         logToFile(Application.Location,'ERR no file selected');
         ShowMessage('Nie wybrano pliku');
    end;
    if alternate_method=true then logToFile(Application.Location,'ERR error - file uses varrible string distance');
    if ListBox1.Count=0 then begin
       if plsr12sc=False then begin
        plsr12sc:=True;
        end_table_line:=0;
        Button1.Click;
        end
        else if (CheckBox2.Checked=False) then begin
          CheckBox2.Checked:=True;
          end_table_line:=0;
          plsr12sc:=False;
          Button1.Click;
        end;
    end
    else if ((ListBox1.Items[0]<>'ID no. for electrode') and (ListBox1.Items[0]<>'ID-NR') and (ListBox1.Items[0]<>'ELEKTR-NUMMER') and (ListBox1.Items[0]<>'Id-Nr Elektrode') and (ListBox1.Items[0]<>'Id-Nr El.')) then begin //no valid table found
         if CheckBox2.Checked=False then begin
            CheckBox2.Checked:=True; //check button for reversing dxf file
            end_table_line:=0;
            Button1.Click; //run search for table again
         end
         else begin
             logToFile(Application.Location,'ERR EOF, no table');
             ShowMessage('Koniec pliku, nie znaleziono tabeli!');
         end;
    end
    else if ListBox1.Count=0 then begin
       logToFile(Application.Location,'ERR error - no table detected');
     ShowMessage('Nie wykryto tabeli z pozycjami elektrod w pliku '+OpenDialog1.FileName);
     end;
     if errorlevel>3 then begin
      inc(gel); //global error level
      errorlevel:=0;
     end;
     if gel>3 then ShowMessage('Niepoprawny plik DXF! '+inttostr(errorlevel));

    // check if such program already exists.
    ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   path:=ust.ReadString('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output');
   fold:=ust.ReadString('settings','createFolder','1');
   if fold='1' then Label17.Visible:=directoryExists(path+'\'+Edit3.Text);
   ust.Free;
   Button7.Enabled:=True;
end;

procedure TForm1.BitBtn1Click(Sender: TObject);
var i,j,ik,iw:integer;
  sx,sy,ko,kd:real;
begin
 //copies of selected row
  If ListBox2.ItemIndex>=0 then begin
      if Form7.ShowModal = mrOK then begin
         setChanged(true);
          if Form7.RadioButton1.Checked then begin  //pojedyncza kopia
             logTofile(Application.Location,'INF single copy '+ListBox2.Items[ListBox2.ItemIndex]);
             ListBox2.Items.Add(ListBox2.Items[ListBox2.ItemIndex]);
             ListBox3.Items.Add(floattostr(strtofloat(ListBox3.Items[ListBox2.ItemIndex])+strtofloat(Form7.LabeledEdit1.Text)));  //x
             ListBox4.Items.Add(floattostr(strtofloat(ListBox4.Items[ListBox2.ItemIndex])+strtofloat(Form7.LabeledEdit2.Text)));  //y
             ListBox5.Items.Add(floattostr(strtofloat(ListBox5.Items[ListBox2.ItemIndex])+strtofloat(Form7.LabeledEdit4.Text)));  //c
             //ListBox6.Items.Add(floattostr(roundto(strtofloat(ListBox6.Items[ListBox2.ItemIndex])+strtofloat(Form7.LabeledEdit3.Text),4)));  //z
             ListBox6.Items.Add(ListBox6.Items[ListBox2.ItemIndex]);
             ListBox7.Items.Add(ListBox7.Items[ListBox2.ItemIndex]);
             ListBox8.Items.Add(ListBox8.Items[ListBox2.ItemIndex]);
             ListBox9.Items.Add(ListBox9.Items[ListBox2.ItemIndex]);
             ListBox11.Items.Add(ListBox11.Items[ListBox2.ItemIndex]);
             ListBox12.Items.Add(ListBox12.Items[ListBox2.ItemIndex]);
             ListBox14.Items.Add(ListBox14.Items[ListBox2.ItemIndex]);
             ListBox15.Items.Add(ListBox15.Items[ListBox2.ItemIndex]);

          end
          else if Form7.RadioButton2.Checked then begin //liniowy
             ik:=strtoint(Form7.LabeledEdit4.Text);
             if ik<1 then ik:=2;
             if ik>99 then ik:=99;
             logTofile(Application.Location,'INF linear copy '+ListBox2.Items[ListBox2.ItemIndex]+' ('+inttostr(ik)+')');
             for i:=1 to ik do begin
                ListBox2.Items.Add(ListBox2.Items[ListBox2.ItemIndex]);
                ListBox3.Items.Add(floattostr(strtofloat(ListBox3.Items[ListBox2.ItemIndex])+strtofloat(Form7.LabeledEdit1.Text)*i));  //x
                ListBox4.Items.Add(floattostr(strtofloat(ListBox4.Items[ListBox2.ItemIndex])+strtofloat(Form7.LabeledEdit2.Text)*i));  //y
                ListBox5.Items.Add(floattostr(strtofloat(ListBox5.Items[ListBox2.ItemIndex])));  //c
                //ListBox6.Items.Add(floattostr(roundto(strtofloat(ListBox6.Items[ListBox2.ItemIndex])+strtofloat(Form7.LabeledEdit3.Text)*i,4)));  //z
                ListBox6.Items.Add(ListBox6.Items[ListBox2.ItemIndex]);
                ListBox7.Items.Add(ListBox7.Items[ListBox2.ItemIndex]);
                ListBox8.Items.Add(ListBox8.Items[ListBox2.ItemIndex]);
                ListBox9.Items.Add(ListBox9.Items[ListBox2.ItemIndex]);
                ListBox11.Items.Add(ListBox11.Items[ListBox2.ItemIndex]);
                ListBox12.Items.Add(ListBox12.Items[ListBox2.ItemIndex]);
                ListBox14.Items.Add(ListBox14.Items[ListBox2.ItemIndex]);
                ListBox15.Items.Add(ListBox15.Items[ListBox2.ItemIndex]);
             end;
          end
          else if Form7.RadioButton3.Checked then begin  //macierz
             iw:=strtoint(Form7.LabeledEdit3.Text);
             ik:=strtoint(Form7.LabeledEdit4.Text);
             logTofile(Application.Location,'INF matrix copy '+ListBox2.Items[ListBox2.ItemIndex]+' ( '+inttostr(iw)+' x '+inttostr(ik)+' )');
               for i:=1 to iw do begin
                  for j:=1 to ik do begin
                     if not ((i=1) and (j=1)) then begin
                         ListBox2.Items.Add(ListBox2.Items[ListBox2.ItemIndex]);
                         ListBox3.Items.Add(floattostr(strtofloat(ListBox3.Items[ListBox2.ItemIndex])+strtofloat(Form7.LabeledEdit1.Text)*(j-1)));  //x
                         ListBox4.Items.Add(floattostr(strtofloat(ListBox4.Items[ListBox2.ItemIndex])+strtofloat(Form7.LabeledEdit2.Text)*(i-1)));  //y
                         ListBox5.Items.Add(floattostr(strtofloat(ListBox5.Items[ListBox2.ItemIndex])));  //c
                         ListBox6.Items.Add(ListBox6.Items[ListBox2.ItemIndex]);  //z
                         ListBox7.Items.Add(ListBox7.Items[ListBox2.ItemIndex]);
                         ListBox8.Items.Add(ListBox8.Items[ListBox2.ItemIndex]);
                         ListBox9.Items.Add(ListBox9.Items[ListBox2.ItemIndex]);
                         ListBox11.Items.Add(ListBox11.Items[ListBox2.ItemIndex]);
                         ListBox12.Items.Add(ListBox12.Items[ListBox2.ItemIndex]);
                         ListBox14.Items.Add(ListBox14.Items[ListBox2.ItemIndex]);
                         ListBox15.Items.Add(ListBox15.Items[ListBox2.ItemIndex]);
                     end;
                  end;
               end;
          end
          else if Form7.RadioButton4.Checked then begin //kolowy
                 sx:=strtofloat(Form7.LabeledEdit1.Text);
                 sy:=strtofloat(Form7.LabeledEdit2.Text);
                 ko:=strtofloat(Form7.LabeledEdit3.Text);
                 kd:=strtofloat(Form7.LabeledEdit4.Text);
                 ik:=strtoint(Form7.LabeledEdit5.Text);
                 logTofile(Application.Location,'INF circular copy '+ListBox2.Items[ListBox2.ItemIndex]+' ('+inttostr(ik)+')');
                 for i:=1 to ik do begin
                    ListBox2.Items.Add(ListBox2.Items[ListBox2.ItemIndex]);
                    ListBox3.Items.Add(floattostr(RoundTo((strtofloat(ListBox3.Items[ListBox2.ItemIndex])-sx)*cos(DegToRad(ko*i))-(strtofloat(ListBox4.Items[ListBox2.ItemIndex])-sy)*sin(DegToRad(ko*i))+sx,4)));
                    ListBox4.Items.Add(floattostr(RoundTo((strtofloat(ListBox3.Items[ListBox2.ItemIndex])-sx)*sin(DegToRad(ko*i))+(strtofloat(ListBox4.Items[ListBox2.ItemIndex])-sy)*cos(DegToRad(ko*i))+sy,4)));
                    ListBox5.Items.Add(floattostr(strtofloat(ListBox5.Items[ListBox2.ItemIndex])+kd*i));
                    ListBox6.Items.Add(floattostr(strtofloat(ListBox6.Items[ListBox2.ItemIndex])));  //z
                     ListBox7.Items.Add(ListBox7.Items[ListBox2.ItemIndex]);
                     ListBox8.Items.Add(ListBox8.Items[ListBox2.ItemIndex]);
                     ListBox9.Items.Add(ListBox9.Items[ListBox2.ItemIndex]);
                     ListBox11.Items.Add(ListBox11.Items[ListBox2.ItemIndex]);
                     ListBox12.Items.Add(ListBox12.Items[ListBox2.ItemIndex]);
                     ListBox14.Items.Add(ListBox14.Items[ListBox2.ItemIndex]);
                     ListBox15.Items.Add(ListBox15.Items[ListBox2.ItemIndex]);
                 end;

          end;
      end;
  end;
end;

procedure TForm1.BitBtn10Click(Sender: TObject);
 var i,j,ik,iw,k,lb2i:integer;
  sx,sy,ko,kd:real;
begin
     lb2i:=ListBox2.Items.Count;
    If lb2i>0 then begin
      if Form7.ShowModal = mrOK then begin
         setChanged(true);
          if Form7.RadioButton1.Checked then begin  //pojedyncza kopia
             logTofile(Application.Location,'INF single copy group');
             for k:=0 to lb2i-1 do begin
                 ListBox2.Items.Add(ListBox2.Items[k]);
                 ListBox3.Items.Add(floattostr(strtofloat(ListBox3.Items[k])+strtofloat(Form7.LabeledEdit1.Text)));  //x
                 ListBox4.Items.Add(floattostr(strtofloat(ListBox4.Items[k])+strtofloat(Form7.LabeledEdit2.Text)));  //y
                 ListBox5.Items.Add(floattostr(strtofloat(ListBox5.Items[k])+strtofloat(Form7.LabeledEdit4.Text)));  //c
                 //ListBox6.Items.Add(floattostr(roundto(strtofloat(ListBox6.Items[k])+strtofloat(Form7.LabeledEdit3.Text),4)));  //z
                 ListBox6.Items.Add(ListBox6.Items[k]);
                 ListBox7.Items.Add(ListBox7.Items[k]);
                 ListBox8.Items.Add(ListBox8.Items[k]);
                 ListBox9.Items.Add(ListBox9.Items[k]);
                 ListBox11.Items.Add(ListBox11.Items[k]);
                 ListBox12.Items.Add(ListBox12.Items[k]);
                 ListBox14.Items.Add(ListBox14.Items[k]);
                 ListBox15.Items.Add(ListBox15.Items[k]);
             end;
          end
          else if Form7.RadioButton2.Checked then begin //liniowy
             ik:=strtoint(Form7.LabeledEdit4.Text);
             if ik<1 then ik:=2;
             if ik>99 then ik:=99;
             logTofile(Application.Location,'INF linear copy group ('+inttostr(ik)+')');
             for k:=0 to lb2i-1 do begin
                 for i:=1 to ik do begin
                     ListBox2.Items.Add(ListBox2.Items[k]);
                     ListBox3.Items.Add(floattostr(strtofloat(ListBox3.Items[k])+strtofloat(Form7.LabeledEdit1.Text)*i));  //x
                     ListBox4.Items.Add(floattostr(strtofloat(ListBox4.Items[k])+strtofloat(Form7.LabeledEdit2.Text)*i));  //y
                     ListBox5.Items.Add(floattostr(strtofloat(ListBox5.Items[k])));  //c
                     //ListBox6.Items.Add(floattostr(roundto(strtofloat(ListBox6.Items[k])+strtofloat(Form7.LabeledEdit3.Text)*i,4)));  //z
                     ListBox6.Items.Add(ListBox6.Items[k]);
                     ListBox7.Items.Add(ListBox7.Items[k]);
                     ListBox8.Items.Add(ListBox8.Items[k]);
                     ListBox9.Items.Add(ListBox9.Items[k]);
                     ListBox11.Items.Add(ListBox11.Items[k]);
                     ListBox12.Items.Add(ListBox12.Items[k]);
                     ListBox14.Items.Add(ListBox14.Items[k]);
                     ListBox15.Items.Add(ListBox15.Items[k]);
                 end;
             end;
          end
          else if Form7.RadioButton3.Checked then begin  //macierz
             iw:=strtoint(Form7.LabeledEdit3.Text);
             ik:=strtoint(Form7.LabeledEdit4.Text);
             logTofile(Application.Location,'INF matrix copy group ( '+inttostr(iw)+' x '+inttostr(ik)+' )');
             for k:=0 to lb2i-1 do begin
                 for i:=1 to iw do begin
                     for j:=1 to ik do begin
                         if not ((i=1) and (j=1)) then begin
                            ListBox2.Items.Add(ListBox2.Items[k]);
                            ListBox3.Items.Add(floattostr(strtofloat(ListBox3.Items[k])+strtofloat(Form7.LabeledEdit1.Text)*(j-1)));  //x
                            ListBox4.Items.Add(floattostr(strtofloat(ListBox4.Items[k])+strtofloat(Form7.LabeledEdit2.Text)*(i-1)));  //y
                            ListBox5.Items.Add(floattostr(strtofloat(ListBox5.Items[k])));  //c
                            ListBox6.Items.Add(ListBox6.Items[k]);  //z
                            ListBox7.Items.Add(ListBox7.Items[k]);
                            ListBox8.Items.Add(ListBox8.Items[k]);
                            ListBox9.Items.Add(ListBox9.Items[k]);
                            ListBox11.Items.Add(ListBox11.Items[k]);
                            ListBox12.Items.Add(ListBox12.Items[k]);
                            ListBox14.Items.Add(ListBox14.Items[k]);
                            ListBox15.Items.Add(ListBox15.Items[k]);
                         end;
                     end;
                 end;
             end;
          end
          else if Form7.RadioButton4.Checked then begin //kolowy
                 sx:=strtofloat(Form7.LabeledEdit1.Text);
                 sy:=strtofloat(Form7.LabeledEdit2.Text);
                 ko:=strtofloat(Form7.LabeledEdit3.Text);
                 kd:=strtofloat(Form7.LabeledEdit4.Text);
                 ik:=strtoint(Form7.LabeledEdit5.Text);
                 logTofile(Application.Location,'INF circular copy group ('+inttostr(ik)+')');
                 for k:=0 to lb2i-1 do begin
                     for i:=1 to ik do begin
                         ListBox2.Items.Add(ListBox2.Items[k]);
                         ListBox3.Items.Add(floattostr(RoundTo((strtofloat(ListBox3.Items[k])-sx)*cos(DegToRad(ko*i))-(strtofloat(ListBox4.Items[k])-sy)*sin(DegToRad(ko*i))+sx,4)));
                         ListBox4.Items.Add(floattostr(RoundTo((strtofloat(ListBox3.Items[k])-sx)*sin(DegToRad(ko*i))+(strtofloat(ListBox4.Items[k])-sy)*cos(DegToRad(ko*i))+sy,4)));
                         ListBox5.Items.Add(floattostr(strtofloat(ListBox5.Items[k])+kd*i));
                         ListBox6.Items.Add(ListBox6.Items[k]);  //z
                         ListBox7.Items.Add(ListBox7.Items[k]);
                         ListBox8.Items.Add(ListBox8.Items[k]);
                         ListBox9.Items.Add(ListBox9.Items[k]);
                         ListBox11.Items.Add(ListBox11.Items[k]);
                         ListBox12.Items.Add(ListBox12.Items[k]);
                         ListBox14.Items.Add(ListBox14.Items[k]);
                         ListBox15.Items.Add(ListBox15.Items[k]);
                     end;
                 end;
          end;
      end;
  end;
end;

procedure TForm1.BitBtn11Click(Sender: TObject);
var i,j:integer;
begin
   if ListBox6.Items.Count>1 then begin
     logToFile(Application.Location,'INF depth sort');
     for i:=1 to ListBox6.Items.Count-1 do begin
        for j:=0 to i-1 do begin
           if strtofloat(ListBox6.Items[i])<strtofloat(ListBox6.Items[j]) then begin
               ListBox2.Items.Move(i,j);
               ListBox3.Items.Move(i,j);
               ListBox4.Items.Move(i,j);
               ListBox5.Items.Move(i,j);
               ListBox6.Items.Move(i,j);
               ListBox7.Items.Move(i,j);
               ListBox8.Items.Move(i,j);
               ListBox9.Items.Move(i,j);
               ListBox11.Items.Move(i,j);
               ListBox12.Items.Move(i,j);
               ListBox14.Items.Move(i,j);
               ListBox15.Items.Move(i,j);
           end;
        end;
     end;
  end;
end;

procedure TForm1.BitBtn2Click(Sender: TObject);
var di:integer;
begin
   if ListBox2.ItemIndex>=0 then begin
      di:=ListBox2.ItemIndex;
      logToFile(Application.Location,'INF deleted line (id:'+ListBox2.Items[di]+', x:'+ListBox3.Items[di]+', y:'+ListBox4.Items[di]+', z:'+ListBox6.Items[di]+', c:'+ListBox5.Items[di]+')');
      ListBox2.Items.Delete(di);
      ListBox3.Items.Delete(di);
      ListBox4.Items.Delete(di);
      ListBox5.Items.Delete(di);
      ListBox6.Items.Delete(di);
      ListBox7.Items.Delete(di);
      ListBox8.Items.Delete(di);
      ListBox9.Items.Delete(di);
      ListBox11.Items.Delete(di);
      ListBox12.Items.Delete(di);
      ListBox14.Items.Delete(di);
      ListBox15.Items.Delete(di);
      if ((di=0) and (ListBox2.Items.Count>0)) then ListBox2.ItemIndex:=di;
      ListBox2.ItemIndex:=di-1;

      ListBox3.ItemIndex:=ListBox2.ItemIndex;
      ListBox4.ItemIndex:=ListBox2.ItemIndex;
      ListBox5.ItemIndex:=ListBox2.ItemIndex;
      ListBox6.ItemIndex:=ListBox2.ItemIndex;
      ListBox7.ItemIndex:=ListBox2.ItemIndex;
      ListBox8.ItemIndex:=ListBox2.ItemIndex;
      ListBox9.ItemIndex:=ListBox2.ItemIndex;
      ListBox11.ItemIndex:=ListBox2.ItemIndex;
      ListBox12.ItemIndex:=ListBox2.ItemIndex;
      ListBox14.ItemIndex:=ListBox2.ItemIndex;
      ListBox15.ItemIndex:=ListBox2.ItemIndex;

      setChanged(true);
   end;
end;

procedure TForm1.BitBtn3Click(Sender: TObject);
var di:integer;
  logg:string;
begin
 if ListBox2.ItemIndex>=0 then begin
    di:=ListBox2.ItemIndex;
    logg:='changed line (';
    logg:=logg+'id: '+ListBox2.Items[di]+' -> '+Edit1.Text+', ';
    if ListBox3.Items[di] <> Edit2.Text then logg:=logg+'X: '+ListBox3.Items[di]+' -> '+Edit2.Text+', ';
    if ListBox4.Items[di] <> Edit4.Text then logg:=logg+'Y: '+ListBox4.Items[di]+' -> '+Edit4.Text+', ';
    if ListBox5.Items[di] <> Edit5.Text then logg:=logg+'C: '+ListBox5.Items[di]+' -> '+Edit5.Text+', ';
    if ListBox6.Items[di] <> Edit6.Text then logg:=logg+'Z: '+ListBox6.Items[di]+' -> '+Edit6.Text+', ';
    if ListBox7.Items[di] <> elmatii_output(ComboBox5.ItemIndex) then logg:=logg+'mat: '+ListBox7.Items[di]+' -> '+elmatii_output(ComboBox5.ItemIndex)+', ';
    if ListBox8.Items[di] <> Edit8.Text then logg:=logg+'fp: '+ListBox8.Items[di]+' -> '+Edit8.Text+', ';
    if ListBox9.Items[di] <> Edit9.Text then logg:=logg+'dirb: '+ListBox9.Items[di]+' -> '+Edit9.Text+', ';
    if ListBox11.Items[di] <> Edit10.Text then logg:=logg+'odsb: '+ListBox11.Items[di]+' -> '+Edit10.Text+', ';
    logg:=logg+')';
    logToFile(Application.Location,'INF '+logg);
   ListBox2.Items[di]:=Edit1.Text;
   ListBox3.Items[di]:=calcstrop(Edit2.Text);
   Edit2.Text:=ListBox3.Items[di];
   Edit2.Color:=clDefault;
   ListBox4.Items[di]:=calcstrop(Edit4.Text);
   Edit4.Text:=ListBox4.Items[di];
   Edit4.color:=clDefault;
   ListBox5.Items[di]:=Edit5.Text;

   ListBox6.Items[di]:=calcstrop(Edit6.Text);
   Edit6.Text:=ListBox6.Items[di];
   Edit6.color:=clDefault;
   ListBox7.Items[di]:=elmatii_output(ComboBox5.ItemIndex);
   ListBox8.Items[di]:=Edit8.Text;
   ListBox9.Items[di]:=Edit9.Text;
   ListBox11.Items[di]:=Edit10.Text;
   ListBox12.Items[di]:=vdi_ii_to_nr(ComboBox3.ItemIndex);
   ListBox14.Items[di]:=Edit7.Text;
   ListBox15.Items[di]:=Edit17.Text;
   setChanged(true);
 end;
end;

procedure TForm1.BitBtn4Click(Sender: TObject);
begin
 if length(Edit1.Text)>0 then begin
   logToFile(Application.Location,'INF line added manually to the table (el:'+Edit1.Text+', X:'+Edit2.Text+', Y:'+Edit4.Text+', C:'+Edit5.Text+', Z:'+Edit6.Text+', mat: '+elmatii_output(COmboBox5.ItemIndex)+', Fp: '+Edit8.Text+', dir: '+Edit9.Text+', ods: '+Edit10.Text+', vdi: '+vdi_ii_to_nr(ComboBox3.ItemIndex)+')');
    ListBox2.Items.Add(Edit1.Text);
    ListBox3.Items.Add(Edit2.Text);
    ListBox4.Items.Add(Edit4.Text);
    ListBox5.Items.Add(Edit5.Text);
    ListBox6.Items.Add(Edit6.Text);
    ListBox7.Items.Add(elmatii_output(ComboBox5.ItemIndex));
    ListBox8.Items.Add(Edit8.Text);
    ListBox9.Items.Add(Edit9.Text);
    ListBox11.Items.Add(Edit10.Text);
    ListBox12.Items.Add(vdi_ii_to_nr(ComboBox3.ItemIndex));
    ListBox14.Items.Add(Edit7.Text);
    ListBox15.Items.Add(Edit17.Text);
    Form2.Label13.Caption:='ready'; // to prevent sending program without electrode data
    Button7.Enabled:=True;
    setChanged(true);
 end;
end;

procedure TForm1.BitBtn5Click(Sender: TObject);
var i:integer;
  needs_sorting:boolean;
begin
     needs_sorting:=False;
     if ListBox8.Count>1 then begin
         for i:=0 to ListBox8.Count-2 do begin
             if strtofloat(ListBox8.Items[i])<strtofloat(ListBox8.Items[(i+1)]) then needs_sorting:=True;
         end;
     end;
     if needs_sorting then if Form11.Showmodal=mrOK then begin
        BitBtn8.Click; //sort by fp
        logToFile(Application.Location,'INF Clicked OK when asked to sort by fp');
     end
     else logToFile(Application.Location,'INF Clicked Cancel when asked to sort by fp');
     //Check if all Z values are negative
     for i:=0 to ListBox6.Count-1 do begin
        if strtofloat(ListBox6.Items[i])>=0 then begin
        showmessage('Uwaga!'+AnsiString(#13#10)+'Elektroda '+ListBox2.Items[i]+' ma dodatni lub zerowy najazd w osi Z !'+AnsiString(#13#10)+'Czy na pewno tak ma być?');
        logToFile(Application.Location,'INF Catched error of EDM Depth>=0, and informed operator');
        end;
     end;
     Button14Click(Form1); //old wyslij
end;

procedure TForm1.BitBtn6Click(Sender: TObject);
var i,ii,j,k,ci,el_nr,tn,il_zgr,tool_num,tool_curr,passnbr,at,shape_no,shape_times,wp_cnt,n1,n2,split_s,sd,first_el,grp,pos_in_shape,tools_per_shape:integer;
  orb,rfp,rmulti,rmat,rdir,fakedir,fakeshape,nrzlec,xmlpath,ild,tmpLine,mdet,tmpName,suwak1,suwak2,suwak2o,isostep,isopendul,actualFileName:string;
  elv,ell,elv_points:TArrayOfString;
  us:Array[1..4] of string;
  usi:Array[1..4] of integer;
  electr,shTools,shPieces:Array of integer;
  fcsv,fstat:TextFile;
  c180,cus,add_xy,add_z:real;
  ust:TIniFile;
  res,res2,do_this_el,shexists,ell_found:boolean;
  sh:array of TShapeHmi;
begin
 if Form2.Label13.Caption='done' then begin
    //save stats
    AssignFile(fstat,Application.Location+'stat_el_certa.csv');
    append(fstat);
    //writeln(fstat,'test');
    for i:=0 to Form2.ListBox1.Count-1 do begin
        writeln(fstat,Form2.ListBox1.Items[i]);
    end;
    CloseFile(fstat);

    for i:=0 to ListBox9.Items.Count-1 do begin
       if ((ListBox9.Items[i]<>'Z') and (ListBox9.Items[i]<>'AB')) then MessageDlg('Drążenie bokiem','Do drążenia bokiem kierunek powinien być AB, a nie X+, X-, Y-, Y+. Kierunek wprowadzony przez Ciebie może spowodować błędny Z.',mtError,[mbOk],0,mbOk);
    end;
    //
    BitBtn11.Click; // 1. sort by eroding depth
    BitBtn7.Click; //  2. sort by AZ
    BitBtn8.Click; //  3. then sort by Fp
    SaveDialog2.FileName:='erodieren_'+Edit3.Text+'.csv';
    ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
    SaveDialog2.InitialDir:=ust.ReadString('settings','pathCSVexport','C:\Windows');
    xmlpath:=ust.ReadString('settings','pathXMLJ','C:\XMLJ');
    at:=ust.ReadInteger('settings','additionalTime',1800);

    if ust.ReadBool('settings','autoCSVCerta',false) then actualFileName:=SaveDialog2.InitialDir+'\'+SaveDialog2.FileName
    else if SaveDialog2.Execute then actualFileName:=SaveDialog2.FileName
    else actualFileName:='none';
    //showmessage(actualFileName);

    //if not CheckBox10.Checked then begin //ommit csv generation for HyperCAD
    if actualFileName<>'none' then begin //if file selected
       AssignFile(fcsv,actualFileName);
       rewrite(fcsv);
       writeln(fcsv,'Beschreibung Werkstueck');
       writeln(fcsv,'NAME; PIECE_WIDTH; PIECE_LENGTH; PIECE_HEIGHT; MATR; X; Y');
       writeln(fcsv,Edit3.Text+';51.700000000000003;6.2300000000000004;33.0;'+ComboBox4.Items[ComboBox4.ItemIndex]);
       writeln(fcsv,'generated;dxf2agiehp'); //this line doesn't change anything in Certa, exists to indicate C is already calculated to correct value.
       writeln(fcsv,'Beschreibung Elektrode');
       writeln(fcsv,'NAME;DIR_CODE;FD;EL_HEIGHT;X;Y;C;DIR;Z;VDI;EL_MAT;FP;AMOUNT_U1;U1;AMOUNT_U2;U2;AMOUNT_U3;U3;AMOUNT_U4;U4'); // SEB seems to be missing part of this line
       for i:=0 to ListBox2.Count-1 do begin //for every electrode position
           if strtofloat(ListBox6.Items[i])>0 then MessageDlg('Uwaga!','Ekektroda '+ListBox2.Items[i]+' ma Z na plus. Sprawdź układ.',mtWarning,[mbOk],0,mbOk);
           for j:=1 to 4 do us[j]:='0';
           for j:=1 to 4 do usi[j]:=0;
           for j:=0 to Form2.ListBox1.Count-1 do begin //for every electrode
               elv:=SplitString(';',Form2.ListBox1.Items[j]);
               if elv[0]=Form1.ListBox2.Items[i] then begin  //if name matches

                  ci:=1;
                  orb:=elv[19]; //save selected type of bottom shape
                  //showmessage(orb);
                  rfp:=elv[2];  //save selected fp
                  rmulti:=elv[16];
                  rmat:=elv[1];

                  //use magpos as number of electrodes
                  us[1]:=elv[3];
                  us[2]:=elv[4];
                  us[3]:=elv[5];
                  us[4]:=elv[6];
                  usi[1]:=strtoint(elv[9]);
                  usi[2]:=strtoint(elv[10]);
                  usi[3]:=strtoint(elv[11]);
                  usi[4]:=strtoint(elv[12]);

                  //fakeshape:=sh_ii_to_hmi(strtoint(elv[19]));
               end;
            //else ShowMessage(elv[0]+' - '+Form1.ListBox2.Items[i]);
           end;
           //normalize directions
           case ListBox9.Items[i] of
                'X+': rdir:='+X';
                '+X': rdir:='+X';
                'X-': rdir:='-X';
                '-X': rdir:='-X';
                'Y+': rdir:='+Y';
                '+Y': rdir:='+Y';
                'Y-': rdir:='-Y';
                '-Y': rdir:='-Y';
                'AB': rdir:='AB';
                else rdir:='Z';
           end;
           // use electrode width in csv as a way to get direction inside without changing csv format
           case ListBox9.Items[i] of
                'X+': fakedir:='11';
                '+X': fakedir:='11';
                'X-': fakedir:='12';
                '-X': fakedir:='12';
                'Y+': fakedir:='13';
                '+Y': fakedir:='13';
                'Y-': fakedir:='14';
                '-Y': fakedir:='14';
                'AB': fakedir:='15';
                else fakedir:='10';
           end;

           //Save 1 line in CSV
           if CheckBox7.Checked then c180:=strtofloat(ListBox5.Items[i])
           else c180:=roundto(strtofloat(ListBox5.Items[i])+180,4);
           if c180>=360 then c180:=c180-360;
           writeln(fcsv,ListBox2.Items[i]+';'+fakedir+';'+ListBox11.Items[i]+';'+fakeshape+';'+ListBox3.Items[i]+';'+ListBox4.Items[i]+';'+floattostr(c180)+';Z;'+floattostr(round(strtofloat(ListBox6.Items[i])*1000)/1000)+';'+ListBox12.Items[i]+';'+rmat+';' //z rounded to 3 decimal places, because certa does it as well
                        +rfp+';'+inttostr(usi[1])+';'+us[1]+';'+inttostr(usi[2])+';'+us[2]+';'+inttostr(usi[3])+';'+us[3]+';'+inttostr(usi[4])+';'+us[4]+';'+orb+';0.0000;-;;;;;true;false');
           if rmulti='1' then begin  //simulate AgieVision's Mult Electrode option by adding another sparking position
              logToFile(Application.Location,'INF added multielectrode for CERTA / HMI');
              if vm>=3 then showmessage('Adding multielectrode for CERTA'+AnsiString(#13#10)+ListBox2.Items[i]);
              c180:=c180+180;
              if c180>=360 then c180:=c180-360;
              writeln(fcsv,ListBox2.Items[i]+';'+fakedir+';'+ListBox11.Items[i]+';'+fakeshape+';'+ListBox3.Items[i]+';'+ListBox4.Items[i]+';'+floattostr(c180)+';Z;'+floattostr(round(strtofloat(ListBox6.Items[i])*1000)/1000)+';'+ListBox12.Items[i]+';'+rmat+';'
                        +rfp+';'+inttostr(usi[1])+';'+us[1]+';'+inttostr(usi[2])+';'+us[2]+';'+inttostr(usi[3])+';'+us[3]+';'+inttostr(usi[4])+';'+us[4]+';'+orb+';0.0000;-;;;;;true;false');
           end;
       end;
       CloseFile(fcsv);
       logToFile(Application.Location,'OK Saved CSV '+SaveDialog2.FileName+' ('+inttostr(ListBox2.Items.Count)+' positions)');
       if vm>=2 then ShowMessage('Poprawnie zapisano '+SaveDialog2.FileName);
    end
    else begin
        if vm>=1 then ShowMessage('nie zapisano csv!');
        logToFile(Application.Location,'INF cancel click on save .csv dialog');
    end;
    //end; //end csv gen ommition
    //step2: Generate XMLJ, to avoid using "Create or modyfy EDM Data" certa function which is wrong
    nrzlec:='';
    ild:='';
    //if not CheckBox10.Checked then begin
    if (length(Edit19.Text)=10) then nrzlec:=Edit19.Text
    else begin
         repeat
               res:=InputQuery('dxf2agie','Podaj nr zlecenia (wystarczy ostatnie 4 cyfry)',nrzlec);
         until ((nrzlec<>'') or (not res));
    end;
    if length(Edit20.Text)>0 then ild:=Edit20.Text
    else begin
      repeat
        res2:=InputQuery('dxf2agie','Podaj lość detali',ild);
      until ((ild<>'') or (not res2));
    end;
    Memo8.Clear;
    Memo8.Lines.Add('<?xml version="1.0" encoding="windows-1252"?>');
    Memo8.Lines.Add('<Jobs>');
    Memo8.Lines.Add('  <Version>'+Label25.Caption+'</Version>');
    Memo8.Lines.Add('  <Futura>1</Futura>');
    // Edit18.Text+
    Memo8.Lines.Add('  <Job Name="'+Edit3.Text+'-'+'EDM-'+Edit16.Text+'">');
    Memo8.Lines.Add('    <Comment>'+nrzlec+'</Comment>');
    Memo8.Lines.Add('    <Type>1</Type>');
    Memo8.Lines.Add('    <FlushingOnAtStart>1</FlushingOnAtStart>');
    Memo8.Lines.Add('    <TankEmptyingAtEnd>0</TankEmptyingAtEnd>');
    Memo8.Lines.Add('    <FlushingOffAtEnd>1</FlushingOffAtEnd>');
    Memo8.Lines.Add('    <UnloadToolAtEnd>1</UnloadToolAtEnd>');
    Memo8.Lines.Add('    <UnloadPalletAtEnd>1</UnloadPalletAtEnd>');
    Memo8.Lines.Add('    <CreationDate>'+getDateHMI()+'</CreationDate>');
    Memo8.Lines.Add('    <ModificationDate>'+getDateHMI()+'</ModificationDate>');
    Memo8.Lines.Add('    <IsoHeader>');
    Memo8.Lines.Add('      <Line N="1">#{SYS_SECZPLAN_ALT}=383</Line>');
    Memo8.Lines.Add('    </IsoHeader>');
    Memo8.Lines.Add('    <IsoFooter>');
    Memo8.Lines.Add('      <Line N="1">IF #3003 LE 4 THEN G4X'+inttostr(at)+'</Line>');
    Memo8.Lines.Add('      </IsoFooter>');
    Memo8.Lines.Add('    <IsoGeneric></IsoGeneric>');
    Memo8.Lines.Add('    <IsoGenerationDate>'+getDateHMI()+'</IsoGenerationDate>');
    Memo8.Lines.Add('    <CoherenceModificationDate>'+getDateHMI()+'</CoherenceModificationDate>');
    Memo8.Lines.Add('    <PartExpressSeq>-1</PartExpressSeq>');
    Memo8.Lines.Add('    <JobProfile></JobProfile>');
    Memo8.Lines.Add('    <JobWorkshop></JobWorkshop>');
    Memo8.Lines.Add('    <OneTJobType>0</OneTJobType>');
    Memo8.Lines.Add('    <OneTJobCavityType>0</OneTJobCavityType>');
    Memo8.Lines.Add('    <OneTJobEDMType>0</OneTJobEDMType>');
    Memo8.Lines.Add('    <OneTJobModelSource></OneTJobModelSource>');
    Memo8.Lines.Add('    <OneTJobUserSeq></OneTJobUserSeq>');
    Memo8.Lines.Add('    <ErrHisto></ErrHisto>');
    Memo8.Lines.Add('    <Certificat></Certificat>');
    Memo8.Lines.Add('    <WearPartType>0</WearPartType>');
    Memo8.Lines.Add('    <WearPartSetting>2</WearPartSetting>');
    Memo8.Lines.Add('    <PartExpressSeqSub>0</PartExpressSeqSub>');
    Memo8.Lines.Add('    <SimpliedISOGeneration>False</SimpliedISOGeneration>');
    Memo8.Lines.Add('    <WearPartPrioSeq>False</WearPartPrioSeq>');
    Memo8.Lines.Add('    <ToolCompensationActive>0</ToolCompensationActive>');
    Memo8.Lines.Add('    <SmartToolEnabled>False</SmartToolEnabled>');
    Memo8.Lines.Add('    <WearPartActivated>False</WearPartActivated>');
    Memo8.Lines.Add('    <FilterKeys></FilterKeys>');
    Memo8.Lines.Add('    <Pdf></Pdf>');
    Memo8.Lines.Add('    <HideISOInputDlg>False</HideISOInputDlg>');
    if Label25.Caption='9.3.1' then begin
      Memo8.Lines.Add('    <SimplifiedCavityISOGeneration>False</SimplifiedCavityISOGeneration>');
      Memo8.Lines.Add('    <StepSortingWizardConfig></StepSortingWizardConfig>');
      Memo8.Lines.Add('    <StepCurrentSorting>0</StepCurrentSorting>');
      Memo8.Lines.Add('    <StepPalletChangePriority>0</StepPalletChangePriority>');
    end;
    Memo8.Lines.Add('    <Pieces>');
    for i:=0 to strtoint(ild)-1 do begin
        Memo8.Lines.Add('      <Piece N="'+inttostr(i+1)+'">');
        Memo8.Lines.Add('        <Name>'+Edit3.Text+'_'+inttostr(i)+'</Name>');
        Memo8.Lines.Add('        <X>0.000</X>');
        Memo8.Lines.Add('        <Y>0.000</Y>');
        Memo8.Lines.Add('        <Z>0.000</Z>');
        Memo8.Lines.Add('        <Rot>0.000</Rot>');
        Memo8.Lines.Add('        <HBac>0</HBac>');
        Memo8.Lines.Add('        <Palette>0</Palette>');
        Memo8.Lines.Add('        <MagPos></MagPos>');
        Memo8.Lines.Add('        <Mandrin>0</Mandrin>');
        Memo8.Lines.Add('        <CreationDate>'+getDateHMI()+'</CreationDate>');
        Memo8.Lines.Add('        <ModificationDate>'+getDateHMI()+'</ModificationDate>');
        Memo8.Lines.Add('        <PartAxisA>0.000</PartAxisA>');
        Memo8.Lines.Add('        <PartAxisB>0.000</PartAxisB>');
        Memo8.Lines.Add('        <ChipID></ChipID>');
        Memo8.Lines.Add('        <Conop_Pos_X></Conop_Pos_X>');
        Memo8.Lines.Add('        <Conop_Pos_Y></Conop_Pos_Y>');
        Memo8.Lines.Add('        <Conop_Pos_Z></Conop_Pos_Z>');
        Memo8.Lines.Add('        <Conop_Pos_C></Conop_Pos_C>');
        Memo8.Lines.Add('        <Conop_RefCor_X>0</Conop_RefCor_X>');
        Memo8.Lines.Add('        <Conop_RefCor_Y>0</Conop_RefCor_Y>');
        Memo8.Lines.Add('        <Conop_RefCor_Z>0</Conop_RefCor_Z>');
        Memo8.Lines.Add('        <Conop_RefCor_C>0</Conop_RefCor_C>');
        Memo8.Lines.Add('        <Conop_ID>0</Conop_ID>');
        Memo8.Lines.Add('      </Piece>');
    end;
    Memo8.Lines.Add('    </Pieces>');
    Memo8.Lines.Add('    <Points>');
    //el_nr:=0;
        for i:=0 to ListBox2.Count-1 do begin
             //just to check user behavior
            do_this_el:=False;
            for j:=0 to Form2.CheckListBox1.Count-1 do begin
                 if ListBox2.Items[i]=Form2.CheckListBox1.Items[j] then begin
                      if Form2.CheckListBox1.Checked[j] then do_this_el:=True;
                 end;
            end;
            if not do_this_el then begin
                if vm>=0 then MessageDlg('Uwaga!','Przy wysyłaniu do certy nie jest wpierane odznaczanie elektrod. Ta odznaczona elektroda '+ListBox2.Items[i]+' nadal będzie w programie.'+AnsiString(#13#10)+'Jeżeli nie chcesz danej elektrody w programie, należy usunąć ją na wcześniejszym etapie.',mtWarning,[mbOk],0);
                logToFile(Application.Location,'ERR Unchecked electrode for CERTA');
            end;
            do_this_el:=TRUE;
            if do_this_el then begin
              add_xy:=strtofloat(ListBox11.Items[i])*sin(DegToRad(strtofloat(ListBox15.Items[i])));
              add_z:=strtofloat(ListBox11.Items[i])*cos(DegToRad(strtofloat(ListBox15.Items[i])));
                //inc(el_nr);
                Memo8.Lines.Add('      <Point N="'+inttostr(i+1)+'">');
              if ((AnsiContainsStr(ListBox9.Items[i],'X')) or ((ListBox15.Items[i]='90') and ((ListBox14.Items[i]='0') or (ListBox14.Items[i]='180')))) then begin
                  if ((AnsiContainsStr(ListBox9.Items[i],'+')) or (ListBox14.Items[i]='180')) then Memo8.Lines.Add('        <X>'+floattostr(strtofloat(ListBox3.Items[i])-strtofloat(ListBox11.Items[i]))+'</X>');
                  if ((AnsiContainsStr(ListBox9.Items[i],'-')) or (ListBox14.Items[i]='0')) then Memo8.Lines.Add('        <X>'+floattostr(strtofloat(ListBox3.Items[i])+strtofloat(ListBox11.Items[i]))+'</X>');
              end
              else if ((ListBox15.Items[i]<>'0') and ((ListBox14.Items[i]='0') or (ListBox14.Items[i]='180'))) then begin //przew
                  if ((AnsiContainsStr(ListBox9.Items[i],'+')) or (ListBox14.Items[i]='180')) then Memo8.Lines.Add('        <X>'+floattostr(strtofloat(ListBox3.Items[i])-add_xy)+'</X>');
                  if ((AnsiContainsStr(ListBox9.Items[i],'-')) or (ListBox14.Items[i]='0')) then Memo8.Lines.Add('        <X>'+floattostr(strtofloat(ListBox3.Items[i])+add_xy)+'</X>');
              end
              else Memo8.Lines.Add('        <X>'+ListBox3.Items[i]+'</X>');
              if ((AnsiContainsStr(ListBox9.Items[i],'Y')) or ((ListBox15.Items[i]='90') and ((ListBox14.Items[i]='270') or (ListBox14.Items[i]='90')))) then begin
                  if ((AnsiContainsStr(ListBox9.Items[i],'+')) or (ListBox14.Items[i]='270')) then Memo8.Lines.Add('        <Y>'+floattostr(strtofloat(ListBox4.Items[i])-strtofloat(ListBox11.Items[i]))+'</Y>');
                  if ((AnsiContainsStr(ListBox9.Items[i],'-')) or (ListBox14.Items[i]='90')) then Memo8.Lines.Add('        <Y>'+floattostr(strtofloat(ListBox4.Items[i])+strtofloat(ListBox11.Items[i]))+'</Y>');
              end
              else if ((ListBox15.Items[i]<>'0') and ((ListBox14.Items[i]='90') or (ListBox14.Items[i]='270'))) then begin //przew
                  if ((AnsiContainsStr(ListBox9.Items[i],'+')) or (ListBox14.Items[i]='270')) then Memo8.Lines.Add('        <Y>'+floattostr(strtofloat(ListBox4.Items[i])-add_xy)+'</Y>');
                  if ((AnsiContainsStr(ListBox9.Items[i],'-')) or (ListBox14.Items[i]='90')) then Memo8.Lines.Add('        <Y>'+floattostr(strtofloat(ListBox4.Items[i])+add_xy)+'</Y>');
              end
              else Memo8.Lines.Add('        <Y>'+ListBox4.Items[i]+'</Y>');
              cus:=0;
              for k:=0 to Form2.ListBox1.Count-1 do begin
                   elv_points:=SplitString(';',Form2.ListBox1.Items[k]);
                   if elv_points[0]=ListBox2.Items[i] then cus:=strtofloat(elv_points[3])/2; //find out undersize per side of current electrode
              end;

              if ListBox9.Items[i]='Z' then Memo8.Lines.Add('        <Z>'+ListBox11.Items[i]+'</Z>') //startpoint must be equal to FromDistance !!!
              else begin
                   if ListBox15.Items[i]='90' then Memo8.Lines.Add('        <Z>'+floattostr(strtofloat(ListBox6.Items[i])+cus*sin(DegToRad(strtofloat(ListBox15.Items[i]))))+'</Z>') //side eroding - startpoint at Z coord minus undersize pre side!
                   else Memo8.Lines.Add('        <Z>'+floattostr(strtofloat(ListBox6.Items[i])+add_z+cus*sin(DegToRad(strtofloat(ListBox15.Items[i]))))+'</Z>')  //angle przewezka

              end;
              c180:=strtofloat(ListBox5.Items[i]);
              if not CheckBox7.Checked then c180:=c180+180;  //rotate because chip direction is different on x400 magazine, unless opened csv saved for CERTA
              if c180>=360 then c180:=c180-360; //normalize C to 0-360
              //showmessage(floattostr(cus*sin(DegToRad(strtofloat(ListBox15.Items[i])))));
              Memo8.Lines.Add('        <Rot>'+floattostr(roundto(c180,4))+'</Rot>');
              Memo8.Lines.Add('        <FromDistance>'+ListBox11.Items[i]+'</FromDistance>');  //startpoint must be equal to FromDistance in Z eroding!!!
              Memo8.Lines.Add('        <X0>'+ListBox3.Items[i]+'</X0>');
              Memo8.Lines.Add('        <Y0>'+ListBox4.Items[i]+'</Y0>');
              if ListBox9.Items[i]='Z' then Memo8.Lines.Add('        <Z0>0</Z0>') // normal - Z
              else Memo8.Lines.Add('        <Z0>'+floattostr(strtofloat(ListBox6.Items[i])+cus*sin(DegToRad(strtofloat(ListBox15.Items[i]))))+'</Z0>'); //side
              tmpLine:='        <AngleX>';
              if ListBox9.Items[i]='Z' then tmpLine:=tmpLine+'0'
              else begin
                  case ListBox9.Items[i] of
                      'X+': tmpLine:=tmpLine+'180';
                      'Y+': tmpLine:=tmpLine+'270';
                      'X-': tmpLine:=tmpLine+'0';
                      'Y-': tmpLine:=tmpLine+'90';
                      '+X': tmpLine:=tmpLine+'180';
                      '+Y': tmpLine:=tmpLine+'270';
                      '-X': tmpLine:=tmpLine+'0';
                      '-Y': tmpLine:=tmpLine+'90';
                      'AB': tmpLine:=tmpLine+ListBox14.Items[i];
                  end;
              end;
              tmpLine:=tmpLine+'</AngleX>';
              Memo8.Lines.Add(tmpLine);
              Memo8.Lines.Add('        <CavityType>1</CavityType>');
              Memo8.Lines.Add('        <Zf>0</Zf>');
              tmpLine:='        <AngleZ>';
              if ListBox9.Items[i]='Z' then tmpLine:=tmpLine+'0'
              else if ListBox9.Items[i]='AB' then tmpLine:=tmpLine+ListBox15.Items[i] //przewezka
              else tmpLine:=tmpLine+'90'; //always 90 for side eroding, direction regulated in <AngleX>
              tmpLine:=tmpLine+'</AngleZ>';
              Memo8.Lines.Add(tmpLine);
              Memo8.Lines.Add('        <CreationDate>'+getDateHMI()+'</CreationDate>');
              Memo8.Lines.Add('        <ModificationDate>'+getDateHMI()+'</ModificationDate>');
              Memo8.Lines.Add('        <AxisA>0</AxisA>');
              Memo8.Lines.Add('        <AxisB>0</AxisB>');
              Memo8.Lines.Add('        <SpecificCavity>0</SpecificCavity>');
              Memo8.Lines.Add('        <MCType>0</MCType>');
              Memo8.Lines.Add('        <MCD1></MCD1>');
              Memo8.Lines.Add('        <MCN1>0</MCN1>');
              Memo8.Lines.Add('        <MCD2></MCD2>');
              Memo8.Lines.Add('        <MCN2>0</MCN2>');
              Memo8.Lines.Add('        <MCR>0</MCR>');
              Memo8.Lines.Add('        <MCI>0</MCI>');
              Memo8.Lines.Add('        <MCJ>0</MCJ>');
              Memo8.Lines.Add('        <MCIndex>0</MCIndex>');
              Memo8.Lines.Add('        <MCSettingChain>0</MCSettingChain>');
              Memo8.Lines.Add('        <MCSettingAlternate>0</MCSettingAlternate>');
              Memo8.Lines.Add('        <Xf>0</Xf>');
              Memo8.Lines.Add('        <Yf>0</Yf>');
              Memo8.Lines.Add('      </Point>');
             end;
          end;
    Memo8.Lines.Add('    </Points>');
    Memo8.Lines.Add('    <Tools>');
    if Label25.Caption='9.3.1' then begin
              Memo8.Lines.Add('      <Tool N="0">');
              Memo8.Lines.Add('        <FinitionType>5</FinitionType>');
              Memo8.Lines.Add('        <Name>GARBAGE/UNASSIGNED</Name>');
              Memo8.Lines.Add('        <X>0</X>');
              Memo8.Lines.Add('        <Y>0</Y>');
              Memo8.Lines.Add('        <Z>0</Z>');
              Memo8.Lines.Add('        <C>0</C>');
              Memo8.Lines.Add('        <MagPos></MagPos>');
              Memo8.Lines.Add('        <Inertie>1</Inertie>');
              Memo8.Lines.Add('        <UnderSize>0</UnderSize>');
              Memo8.Lines.Add('        <CreationDate>'+getDateHMI()+'</CreationDate>');
              Memo8.Lines.Add('        <ModificationDate>'+getDateHMI()+'</ModificationDate>');
              Memo8.Lines.Add('        <Radius></Radius>');
              Memo8.Lines.Add('        <ChipID></ChipID>');
              Memo8.Lines.Add('        <SizeInMagasin>1</SizeInMagasin>');
              Memo8.Lines.Add('        <Material></Material>');
              Memo8.Lines.Add('        <ToolDecFamily>0</ToolDecFamily>');
              for i:=1 to 5 do begin
                 Memo8.Lines.Add('        <ToolDecCount'+inttostr(i)+'>100</ToolDecCount'+inttostr(i)+'>');
              end;
              Memo8.Lines.Add('        <ToolDecWear>0</ToolDecWear>');
              Memo8.Lines.Add('        <UEDMComp>0</UEDMComp>');
              Memo8.Lines.Add('        <UCavComp>0</UCavComp>');
              Memo8.Lines.Add('        <FrontalOffset>0</FrontalOffset>');
              Memo8.Lines.Add('        <ToolDecWearF>0</ToolDecWearF>');
              Memo8.Lines.Add('      </Tool>');
    end;
    el_nr:=1;
    setLength(elHmi,0);
    wp_cnt:=strtoint(ild);
    for i:=0 to Form2.ListBox1.Items.Count-1 do begin
        if Form2.CheckListBox1.Checked[i] then begin
            ell:=SplitString(';',Form2.ListBox1.Items[i]);
            n1:=strtoint(ell[9]); //amount of electrodes with undersize 1
            if ell[4]='0' then n2:=0 //all the same undersize
            else n2:=strtoint(ell[10]); //amount of electrodes with undersize 2
            // split into separate shapes, so worn electrode doesn't start a new piece:
            // the most shapes, so that pieces and electrodes of each undersize divide evenly into shapes,
            // with at least 2 electrodes per shape
            // numbers not divisible: 1 shape, all electrodes on all pieces
            split_s:=1;
            if ((wp_cnt>1) and (n1>0)) then begin
               for sd:=wp_cnt downto 2 do begin
                   if ((wp_cnt mod sd)=0) and ((n1 mod sd)=0) and ((n2 mod sd)=0) and (((n1+n2) div sd)>=2) then begin
                      split_s:=sd;
                      break;
                   end;
               end;
               if split_s>1 then logToFile(Application.Location,'INF Electrode '+ell[0]+' split into '+inttostr(split_s)+' shapes ('+inttostr(n1)+'+'+inttostr(n2)+' electrodes, '+ild+' pieces)')
               else logToFile(Application.Location,'INF Electrode '+ell[0]+' not split, amount of electrodes ('+inttostr(n1)+'+'+inttostr(n2)+') does not divide into '+ild+' pieces');
            end;
            for grp:=1 to 2 do begin
                if grp=1 then tool_curr:=n1
                else tool_curr:=n2;
                if tool_curr=0 then continue;
                tools_per_shape:=tool_curr div split_s;
                il_zgr:=1;
                if split_s>1 then tn:=tools_per_shape
                else tn:=tool_curr;
                if tn>4 then il_zgr:=2;
                if tn>7 then il_zgr:=3;
                for j:=1 to tool_curr do begin
                     setLength(elHmi,length(elHmi)+1);
                     elHmi[high(elHmi)].global_nr:=el_nr;
                     elHmi[high(elHmi)].local_nr:=j;
                     elHmi[high(elHmi)].name:=RightStr(nrzlec,4)+'-'+ell[0]+'-UM'+RightStr('00'+floattostr(strtofloat(ell[2+grp])*100),3)+'_'+inttostr(j-1);
                     if n2>0 then elHmi[high(elHmi)].finType:=grp //2 undersizes: 1st roughing, 2nd finishing
                     else begin
                         pos_in_shape:=((j-1) mod tn)+1;
                         if pos_in_shape<=il_zgr then elHmi[high(elHmi)].finType:=1
                         else elHmi[high(elHmi)].finType:=2;
                     end;
                     elHmi[high(elHmi)].fp:=strtofloat(ell[2]);
                     elHmi[high(elHmi)].mat:=ell[1];
                     elHmi[high(elHmi)].undersize:=strtofloat(ell[2+grp])/2;
                     elHmi[high(elHmi)].elname:=ell[0];
                     elHmi[high(elHmi)].splitCount:=split_s;
                     elHmi[high(elHmi)].shapeIdx:=((j-1) div tools_per_shape)+1;
                     inc(el_nr);
                end;
            end;
        end;
    end;
    for i:=0 to high(elHmi) do begin
        //if elHmi[i].
        Memo8.Lines.Add('      <Tool N="'+inttostr(elHmi[i].global_nr)+'">');
        Memo8.Lines.Add('        <FinitionType>'+inttostr(elHmi[i].finType)+'</FinitionType>');
        Memo8.Lines.Add('        <Name>'+elHmi[i].name+'</Name>');
        Memo8.Lines.Add('        <X>0</X>');
        Memo8.Lines.Add('        <Y>0</Y>');
        Memo8.Lines.Add('        <Z>0</Z>');
        Memo8.Lines.Add('        <MagPos>0</MagPos>');
        Memo8.Lines.Add('        <Inertie>1</Inertie>');
        Memo8.Lines.Add('        <UnderSize>'+floattostr(elHmi[i].undersize)+'</UnderSize>');
        Memo8.Lines.Add('        <CreationDate>'+getDateHMI()+'</CreationDate>');
        Memo8.Lines.Add('        <ModificationDate>'+getDateHMI()+'</ModificationDate>');
        Memo8.Lines.Add('        <Radius></Radius>');
        Memo8.Lines.Add('        <ChipID></ChipID>');
        Memo8.Lines.Add('        <SizeInMagasin>1</SizeInMagasin>');
        Memo8.Lines.Add('        <Material></Material>');
        Memo8.Lines.Add('        <ToolDecFamily>1</ToolDecFamily>');
        for j:=1 to 5 do begin
            Memo8.Lines.Add('        <ToolDecCount'+inttostr(j)+'>100</ToolDecCount'+inttostr(j)+'>');
        end;
        Memo8.Lines.Add('        <ToolDecWear>0</ToolDecWear>');
        Memo8.Lines.Add('        <UEDMComp>0</UEDMComp>');
        Memo8.Lines.Add('        <UCavComp>0</UCavComp>');
        Memo8.Lines.Add('        <FrontalOffset>0</FrontalOffset>');
        Memo8.Lines.Add('        <ToolDecWearF>0</ToolDecWearF>');
        Memo8.Lines.Add('        <ToolReals>');
        Memo8.Lines.Add('          <ToolReal N="'+inttostr(i+1000)+'">');
        Memo8.Lines.Add('            <Name></Name>');
        Memo8.Lines.Add('            <X>0</X>');
        Memo8.Lines.Add('            <Y>0</Y>');
        Memo8.Lines.Add('            <Z>0</Z>');
        Memo8.Lines.Add('            <C>0</C>');
        Memo8.Lines.Add('            <MagPos></MagPos>');
        Memo8.Lines.Add('            <UnderSize>'+floattostr(elHmi[i].undersize)+'</UnderSize>');
        Memo8.Lines.Add('            <CreationDate>'+getDateHMI()+'</CreationDate>');
        Memo8.Lines.Add('            <ModificationDate>'+getDateHMI+'</ModificationDate>');
        Memo8.Lines.Add('            <Radius></Radius>');
        Memo8.Lines.Add('            <ChipID></ChipID>');
        for j:=1 to 5 do Memo8.Lines.Add('            <ToolDecCount'+inttostr(j)+'>100</ToolDecCount'+inttostr(j)+'>');
        Memo8.Lines.Add('            <initUnderSize>0</initUnderSize>');
        for j:=1 to 5 do Memo8.Lines.Add('            <initToolDecCount'+inttostr(j)+'>-2</initToolDecCount'+inttostr(j)+'>');
        Memo8.Lines.Add('            <Inertie>1</Inertie>');
        Memo8.Lines.Add('            <fragUse>0</fragUse>');
        Memo8.Lines.Add('            <fragSCode>0</fragSCode>');
        Memo8.Lines.Add('            <FrontalOffset>0</FrontalOffset>');
        Memo8.Lines.Add('            <initFrontalOffset>0</initFrontalOffset>');
        Memo8.Lines.Add('            <initTemplateNum>0</initTemplateNum>');
        Memo8.Lines.Add('          </ToolReal>');
        Memo8.Lines.Add('        </ToolReals>');
        Memo8.Lines.Add('      </Tool>');
    end;
    Memo8.Lines.Add('    </Tools>');
    Memo8.Lines.Add('    <Shapes>');
    setLength(sh,0);
    el_nr:=0;
    tool_num:=1;
    for i:=0 to ListBox2.Items.Count-1 do begin
        //showmessage(ListBox2.Items[i]);
        tmpName:=ListBox2.Items[i]+floattostr(round(strtofloat(ListBox6.Items[i])*1000)/1000);
        do_this_el:=True;
        ell_found:=False;
            for j:=0 to Form2.CheckListBox1.Count-1 do begin
                 if ListBox2.Items[i]=Form2.CheckListBox1.Items[j] then begin
                      ell:=SplitString(';',Form2.ListBox1.Items[j]);
                      ell_found:=True;
            //          if Form2.CheckListBox1.Checked[j] then do_this_el:=True;
                 end;
            end;
            if not ell_found then begin
               do_this_el:=False;
               if vm>=1 then showmessage(ListBox2.Items[i]+' Error, no electrode data!');
               logToFile(Application.Location,'ERR '+ListBox2.Items[i]+' no electrode data, position skipped in shapes');
            end;
            if do_this_el then begin
                inc(el_nr);
                shexists:=false;

                for j:=0 to high(sh) do begin
                    if sh[j].name=tmpName then begin
                    shexists:=true;
                    break;
                end;
            end;
                //showmessage(ell[9]+' '+ell[10]);
        tool_curr:=strtoint(ell[9]);
        if ell[4]<>'0' then tool_curr:=tool_curr+strtoint(ell[10]); //2nd undersize electrodes are created only if undersize is set
        setLength(electr,0);
        //showmessage('length(elHmi): '+inttostr(length(elHmi)));
        for k:=0 to high(elHmi) do begin
           if elHmi[k].elname=ListBox2.Items[i] then begin
              setLength(electr,length(electr)+1);
              electr[high(electr)]:=elHmi[k].global_nr;
           end;
        end;
        if shexists then begin
            setLength(sh[j].sp,length(sh[j].sp)+1);
            sh[j].sp[high(sh[j].sp)]:=i+1;
        end
        else begin //new shape

           if length(electr)<>tool_curr then begin
              if vm>=1 then showmessage(ell[0]+' Error, wrong number of electrodes!'+AnsiString(#13#10)+'tool_curr: '+inttostr(tool_curr)+AnsiString(#13#10)+'length(electr): '+inttostr(length(electr)));
              logToFile(Application.Location,'ERR '+ell[0]+' Error, wrong number of electrodes! tool_curr: '+inttostr(tool_curr)+', length(electr): '+inttostr(length(electr)));
           end;
            setLength(sh,length(sh)+1);
            sh[high(sh)].name:=tmpName;
            sh[high(sh)].elname:=ListBox2.Items[i];
            sh[high(sh)].vdi:=ListBox12.Items[i];
            sh[high(sh)].edmDir:=ListBox9.Items[i];
            if ListBox9.Items[i]='Z' then sh[high(sh)].edmDepth:=strtofloat(ListBox6.Items[i])*(-1)
            else sh[high(sh)].edmDepth:=strtofloat(ell[3])/2;
            setLength(sh[high(sh)].sp,1);
            sh[high(sh)].sp[0]:=i+1;
            setLength(sh[high(sh)].st,length(electr));
            for k:=0 to high(sh[high(sh)].st) do sh[high(sh)].st[k]:=electr[k];
        end;

        end;

    end;
    if ust.ReadBool('settings','showPrioSelector',true) then begin
    if Form10.ShowModal=mrOK then begin //use selected values
                 case Form10.TrackBar1.Position of
                     0: suwak1:='1';
                     1: suwak1:='5';
                     2: suwak1:='2';
                     3: suwak1:='4';
                     4: suwak1:='3';
                 end;
                 case Form10.TrackBar2.Position of
                     0: begin
                         suwak2:='2';
                         //suwak2o:='1';
                     end;
                     1: begin
                         suwak2:='1';
                         //suwak2o:='2';
                     end;
                 end;
          end
          else begin //use default values
                 suwak1:='2';
                 suwak2:='1';
          end;
          end
    else begin
        suwak1:='2';
        suwak2:='1';
    end;
    shape_no:=0;
    for i:=0 to high(sh) do begin
        first_el:=-1;
        for k:=0 to High(elHmi) do begin
            if elHmi[k].elname=sh[i].elname then begin
               first_el:=k;
               break;
            end;
        end;
        if first_el=-1 then begin
           if vm>=1 then showmessage(sh[i].elname+' Error, no electrodes for shape!');
           logToFile(Application.Location,'ERR '+sh[i].elname+' no electrodes (unchecked?), shape '+sh[i].name+' skipped');
           continue;
        end;
        j:=first_el;
        shape_times:=elHmi[j].splitCount;
        for ii:=1 to shape_times do begin
        //electrodes and pieces of this shape
        setLength(shTools,0);
        for k:=0 to High(elHmi) do begin
            if ((elHmi[k].elname=sh[i].elname) and ((shape_times=1) or (elHmi[k].shapeIdx=ii))) then begin
               setLength(shTools,length(shTools)+1);
               shTools[high(shTools)]:=elHmi[k].global_nr;
            end;
        end;
        setLength(shPieces,0);
        for k:=1 to wp_cnt do begin
            if ((shape_times=1) or ((((k-1) div (wp_cnt div shape_times))+1)=ii)) then begin
               setLength(shPieces,length(shPieces)+1);
               shPieces[high(shPieces)]:=k;
            end;
        end;
        inc(shape_no);
        Memo8.Lines.Add('      <Shape N="'+inttostr(shape_no)+'">');
        Memo8.Lines.Add('        <CreationDate>'+getDateHMI()+'</CreationDate>');
        Memo8.Lines.Add('        <ModificationDate>'+getDateHMI()+'</ModificationDate>');
        Memo8.Lines.Add('        <Comment>'+sh[i].name+'</Comment>');
        Memo8.Lines.Add('        <ElectMaterialCode>'+mat_x400_code(elHmi[j].mat)+'</ElectMaterialCode>');
        Memo8.Lines.Add('        <PieceMaterialCode>1</PieceMaterialCode>');
        Memo8.Lines.Add('        <PrepElectMaterialSymb>'+mat_x400(elHmi[j].mat)+'</PrepElectMaterialSymb>');
        Memo8.Lines.Add('        <ElectMaterialSymb></ElectMaterialSymb>');
        Memo8.Lines.Add('        <PrepPieceMaterialSymb>AC</PrepPieceMaterialSymb>');
        Memo8.Lines.Add('        <PieceMaterialSymb></PieceMaterialSymb>');
        Memo8.Lines.Add('        <PrepApplicationType>1</PrepApplicationType>');
        Memo8.Lines.Add('        <ApplicationType>1</ApplicationType>');
        Memo8.Lines.Add('        <PrepSurfaceFinishingCH>'+sh[i].vdi[4]+sh[i].vdi[5]+'</PrepSurfaceFinishingCH>');
        Memo8.Lines.Add('        <SurfaceFinishingCH>'+sh[i].vdi[4]+sh[i].vdi[5]+'</SurfaceFinishingCH>');
        Memo8.Lines.Add('        <PrepDepth>'+floattostr(sh[i].edmDepth)+'</PrepDepth>');
        Memo8.Lines.Add('        <EDMDepth>'+floattostr(sh[i].edmDepth)+'</EDMDepth>');
        Memo8.Lines.Add('        <AdjDepth>'+floattostr(sh[i].edmDepth)+'</AdjDepth>');
        if mat_x400(elHmi[j].mat)='CU' then Memo8.Lines.Add('        <ToolLength>'+floattostr(sh[i].edmDepth+5)+'</ToolLength>')
        else Memo8.Lines.Add('        <ToolLength>0</ToolLength>');
        if mat_x400(elHmi[j].mat)='CU' then Memo8.Lines.Add('        <PrepToolLength>'+floattostr(sh[i].edmDepth+5)+'</PrepToolLength>')
        else Memo8.Lines.Add('        <PrepToolLength>0</PrepToolLength>');
        Memo8.Lines.Add('        <PrepGCycle>4</PrepGCycle>');
        Memo8.Lines.Add('        <GCycle>4</GCycle>');
        Memo8.Lines.Add('        <PrepCavityStyle>1</PrepCavityStyle>');
        Memo8.Lines.Add('        <CavityStyle>1</CavityStyle>');
        Memo8.Lines.Add('        <PrepCavityAngle>0</PrepCavityAngle>');
        Memo8.Lines.Add('        <CavityAngle>0</CavityAngle>');
        Memo8.Lines.Add('        <PrepMaxArea>'+floattostr(elHmi[j].fp)+'</PrepMaxArea>');
        Memo8.Lines.Add('        <MaxArea>0</MaxArea>');
        Memo8.Lines.Add('        <PreMilledCavity>0</PreMilledCavity>');
        Memo8.Lines.Add('        <LateralExtraThickness>0</LateralExtraThickness>');
        Memo8.Lines.Add('        <FrontalExtraThickness>0</FrontalExtraThickness>');
        Memo8.Lines.Add('        <PrepPulseType></PrepPulseType>');
        Memo8.Lines.Add('        <PulseType></PulseType>');
        Memo8.Lines.Add('        <PrepQCode></PrepQCode>');
        Memo8.Lines.Add('        <QCode></QCode>');
        if Label25.Caption='9.0.0' then begin
           Memo8.Lines.Add('        <ProtectionPieceAttack>1</ProtectionPieceAttack>');
           Memo8.Lines.Add('        <ProtectionCC>1</ProtectionCC>');
           Memo8.Lines.Add('        <ProtectionSpacc>1</ProtectionSpacc>');
           Memo8.Lines.Add('        <ProtectionOnBadMachining>0</ProtectionOnBadMachining>');
        end;
        Memo8.Lines.Add('        <AttackSensitivelessTime>0</AttackSensitivelessTime>');
        Memo8.Lines.Add('        <PrepFlushingM70>A0B0C0D0</PrepFlushingM70>');
        Memo8.Lines.Add('        <FlushingM70>A0B0C0D0</FlushingM70>');
        Memo8.Lines.Add('        <AspirM71></AspirM71>');
        Memo8.Lines.Add('        <PrepSpinSpeed>0</PrepSpinSpeed>');
        Memo8.Lines.Add('        <SpinSpeed></SpinSpeed>');
        Memo8.Lines.Add('        <PrepSpinCode>5</PrepSpinCode>');
        Memo8.Lines.Add('        <SpinCode>5</SpinCode>');
        Memo8.Lines.Add('        <PrepDownTranslationRadius></PrepDownTranslationRadius>');
        Memo8.Lines.Add('        <DownTranslationRadius></DownTranslationRadius>');
        Memo8.Lines.Add('        <PrepHelicFromRefCavity>0</PrepHelicFromRefCavity>');
        Memo8.Lines.Add('        <HelicFromRefCavity>0</HelicFromRefCavity>');
        Memo8.Lines.Add('        <PrepCycleFinishingType></PrepCycleFinishingType>');
        Memo8.Lines.Add('        <CycleFinishingType></CycleFinishingType>');
        Memo8.Lines.Add('        <PrepCycleAngle>0</PrepCycleAngle>');
        Memo8.Lines.Add('        <CycleAngle>0</CycleAngle>');
        Memo8.Lines.Add('        <PrepAngul>0</PrepAngul>');
        Memo8.Lines.Add('        <Angul>0</Angul>');
        Memo8.Lines.Add('        <PrepCycleCornersNb>4</PrepCycleCornersNb>');
        Memo8.Lines.Add('        <CycleCornersNb>4</CycleCornersNb>');
        Memo8.Lines.Add('        <PrepCycleHelicStep>0</PrepCycleHelicStep>');
        Memo8.Lines.Add('        <CycleHelicStep>0</CycleHelicStep>');
        Memo8.Lines.Add('        <TechnoName></TechnoName>');
        //showmessage(intar_to_hmiList(sh[i].st));
        Memo8.Lines.Add('        <JobReportToolList>'+intar_to_hmiList(shTools)+'</JobReportToolList>');
        Memo8.Lines.Add('        <JobReportPieceList>'+intar_to_hmiList(shPieces)+'</JobReportPieceList>');

        Memo8.Lines.Add('        <JobReportPointList>'+intar_to_hmiList(sh[i].sp)+'</JobReportPointList>');
        if length(shTools)=1 then Memo8.Lines.Add('        <MachiningPassNbr>1</MachiningPassNbr>')
        else Memo8.Lines.Add('        <MachiningPassNbr>2</MachiningPassNbr>');
        Memo8.Lines.Add('        <CalculatedArea>0</CalculatedArea>');
        Memo8.Lines.Add('        <PrepInvPolarity>0</PrepInvPolarity>');
        Memo8.Lines.Add('        <InvPolarity>0</InvPolarity>');
        Memo8.Lines.Add('        <PrepAdditionalRadius></PrepAdditionalRadius>');
        Memo8.Lines.Add('        <AdditionalRadius></AdditionalRadius>');
        Memo8.Lines.Add('        <PrepTrajWithoutCAxis>0</PrepTrajWithoutCAxis>');
        Memo8.Lines.Add('        <TrajWithoutCAxis>0</TrajWithoutCAxis>');
        Memo8.Lines.Add('        <PrepToolRadius>0</PrepToolRadius>');
        Memo8.Lines.Add('        <ToolRadius>0</ToolRadius>');
        Memo8.Lines.Add('        <TrajMode></TrajMode>');
        Memo8.Lines.Add('        <PrepTrajMode></PrepTrajMode>');
        Memo8.Lines.Add('        <PrepContouringRemovalType>0</PrepContouringRemovalType>');
        Memo8.Lines.Add('        <ContouringRemovalType>0</ContouringRemovalType>');
        Memo8.Lines.Add('        <TruncateAngle></TruncateAngle>');
        Memo8.Lines.Add('        <PrepTruncateAngle></PrepTruncateAngle>');
        Memo8.Lines.Add('        <MegaSizeOptimization>0</MegaSizeOptimization>');
        Memo8.Lines.Add('        <EDMGenerationUpToDate>0</EDMGenerationUpToDate>');
        Memo8.Lines.Add('        <PrepAdditionalDistanceX></PrepAdditionalDistanceX>');
        Memo8.Lines.Add('        <AdditionalDistanceX></AdditionalDistanceX>');
        Memo8.Lines.Add('        <PrepAdditionalDistanceY></PrepAdditionalDistanceY>');
        Memo8.Lines.Add('        <AdditionalDistanceY></AdditionalDistanceY>');
        Memo8.Lines.Add('        <PrepApproachPath></PrepApproachPath>');
        Memo8.Lines.Add('        <ApproachPath></ApproachPath>');
        Memo8.Lines.Add('        <PrepDielectricType>0</PrepDielectricType>');
        Memo8.Lines.Add('        <DielectricType>0</DielectricType>');
        Memo8.Lines.Add('        <AdjCycleHelicStep>0</AdjCycleHelicStep>');
        Memo8.Lines.Add('        <NotEmergingHole>0</NotEmergingHole>');
        Memo8.Lines.Add('        <AmorcState>0</AmorcState>');
        Memo8.Lines.Add('        <AmorcTime>0</AmorcTime>');
        Memo8.Lines.Add('        <MultiCyclesCavity>0</MultiCyclesCavity>');
        Memo8.Lines.Add('        <PrepDownTranslationType></PrepDownTranslationType>');
        Memo8.Lines.Add('        <DownTranslationType></DownTranslationType>');
        Memo8.Lines.Add('        <PrepLateralShape>0</PrepLateralShape>');
        Memo8.Lines.Add('        <LateralShape>0</LateralShape>');
        Memo8.Lines.Add('        <PrepLateralShapeHeight></PrepLateralShapeHeight>');
        Memo8.Lines.Add('        <LateralShapeHeight></LateralShapeHeight>');
        Memo8.Lines.Add('        <Circumference>0</Circumference>');
        Memo8.Lines.Add('        <OptimizedSettingRadius>0</OptimizedSettingRadius>');
        Memo8.Lines.Add('        <PrepMultiShape>0</PrepMultiShape>');
        Memo8.Lines.Add('        <MultiShape>0</MultiShape>');
        Memo8.Lines.Add('        <PrepContourXStartPoint>0</PrepContourXStartPoint>');
        Memo8.Lines.Add('        <ContourXStartPoint>0</ContourXStartPoint>');
        Memo8.Lines.Add('        <PrepContourYStartPoint>0</PrepContourYStartPoint>');
        Memo8.Lines.Add('        <ContourYStartPoint>0</ContourYStartPoint>');
        Memo8.Lines.Add('        <PrepContourZStartPoint>0</PrepContourZStartPoint>');
        Memo8.Lines.Add('        <ContourZStartPoint>0</ContourZStartPoint>');
        Memo8.Lines.Add('        <PrepContourCStartPoint>0</PrepContourCStartPoint>');
        Memo8.Lines.Add('        <ContourCStartPoint>0</ContourCStartPoint>');
        Memo8.Lines.Add('        <PrepContourXStopPoint>0</PrepContourXStopPoint>');
        Memo8.Lines.Add('        <ContourXStopPoint>0</ContourXStopPoint>');
        Memo8.Lines.Add('        <PrepContourYStopPoint>0</PrepContourYStopPoint>');
        Memo8.Lines.Add('        <ContourYStopPoint>0</ContourYStopPoint>');
        Memo8.Lines.Add('        <PrepContourZStopPoint>0</PrepContourZStopPoint>');
        Memo8.Lines.Add('        <ContourZStopPoint>0</ContourZStopPoint>');
        Memo8.Lines.Add('        <PrepContourCStopPoint>0</PrepContourCStopPoint>');
        Memo8.Lines.Add('        <ContourCStopPoint>0</ContourCStopPoint>');
        Memo8.Lines.Add('        <PrepContourRightOrLeft>0</PrepContourRightOrLeft>');
        Memo8.Lines.Add('        <ContourRightOrLeft>0</ContourRightOrLeft>');
        Memo8.Lines.Add('        <PrepFlushingPressure>1</PrepFlushingPressure>');
        Memo8.Lines.Add('        <FlushingPressure>1</FlushingPressure>');
        Memo8.Lines.Add('        <PrepHelicUndersizeAdjust>0</PrepHelicUndersizeAdjust>');
        Memo8.Lines.Add('        <HelicUndersizeAdjust>0</HelicUndersizeAdjust>');
        Memo8.Lines.Add('        <PrepHelicThreadAngle></PrepHelicThreadAngle>');
        Memo8.Lines.Add('        <HelicThreadAngle></HelicThreadAngle>');
        Memo8.Lines.Add('        <GeometryType>0</GeometryType>');
        Memo8.Lines.Add('        <GeometrySideA></GeometrySideA>');
        Memo8.Lines.Add('        <GeometrySideB></GeometrySideB>');
        Memo8.Lines.Add('        <GeometryDiameter></GeometryDiameter>');
        Memo8.Lines.Add('        <PrepLEDCavityNb>1</PrepLEDCavityNb>');
        Memo8.Lines.Add('        <LEDCavityNb>1</LEDCavityNb>');
        suwak2o:='2';
             //drugi suwak
                // w lewo - 2
                // w prawo - 1
        Memo8.Lines.Add('        <PrepCHSpeedPriority>'+suwak2+'</PrepCHSpeedPriority>');
        Memo8.Lines.Add('        <CHSpeedPriority>1</CHSpeedPriority>');
             //pierwszy suwak     |-----|
                //srodek - 2       ..^..
                //1 w lewo - 5     .^...
                //2 w lewo - 1     ^....
                //1 w prawo        ...^.
                //2 w prawo        ....^
        Memo8.Lines.Add('        <PrepWearSpeedPriority>'+suwak1+'</PrepWearSpeedPriority>');
        Memo8.Lines.Add('        <WearSpeedPriority>'+suwak1+'</WearSpeedPriority>');
        Memo8.Lines.Add('        <PulsBackWithoutVoltage>0</PulsBackWithoutVoltage>');
        Memo8.Lines.Add('        <PrepWhiteLayerPriority>0</PrepWhiteLayerPriority>');
        Memo8.Lines.Add('        <WhiteLayerPriority>0</WhiteLayerPriority>');
        Memo8.Lines.Add('        <CHText></CHText>');
        Memo8.Lines.Add('        <WearPartType>0</WearPartType>');
        Memo8.Lines.Add('        <WearPartSetting>2</WearPartSetting>');
        mdet:=wpmatii_to_hmi(ComboBox4.ItemIndex);
        for k:=1 to 5 do begin  //stupid repeating 5 times the same thing - required
                Memo8.Lines.Add('        <PrepPartMatPass'+inttostr(k)+'>'+mdet+'</PrepPartMatPass'+inttostr(k)+'>');
                Memo8.Lines.Add('        <PartMatPass'+inttostr(k)+'>'+mdet+'</PartMatPass'+inttostr(k)+'>');
                Memo8.Lines.Add('        <PrepToolMatPass'+inttostr(k)+'>'+mat_x400(elHmi[j].mat)+'</PrepToolMatPass'+inttostr(k)+'>');
                Memo8.Lines.Add('        <ToolMatPass'+inttostr(k)+'>'+mat_x400(elHmi[j].mat)+'</ToolMatPass'+inttostr(k)+'>');
        end;
        for k:=1 to 5 do begin
                //pierwszy suwak

                Memo8.Lines.Add('        <PrepCHSpeedPriority'+inttostr(k)+'>1</PrepCHSpeedPriority'+inttostr(k)+'>');
                Memo8.Lines.Add('        <CHSpeedPriority'+inttostr(k)+'>'+suwak2+'</CHSpeedPriority'+inttostr(k)+'>');
                Memo8.Lines.Add('        <PrepLastSettingPriority'+inttostr(k)+'>'+suwak1+'</PrepLastSettingPriority'+inttostr(k)+'>');
                Memo8.Lines.Add('        <LastSettingPriority'+inttostr(k)+'>'+suwak1+'</LastSettingPriority'+inttostr(k)+'>');
        end;
        for k:=1 to 5 do Memo8.Lines.Add('        <LSB'+inttostr(k)+'></LSB'+inttostr(k)+'>');
        for k:=1 to 5 do Memo8.Lines.Add('        <FSB'+inttostr(k)+'></FSB'+inttostr(k)+'>');
        Memo8.Lines.Add('        <PrepLimitStartPower>0</PrepLimitStartPower>');
        Memo8.Lines.Add('        <LimitStartPower>0</LimitStartPower>');
        for k:=1 to 5 do Memo8.Lines.Add('        <PrepLSB'+inttostr(k)+'></PrepLSB'+inttostr(k)+'>');
        for k:=1 to 5 do Memo8.Lines.Add('        <PrepFSB'+inttostr(k)+'></PrepFSB'+inttostr(k)+'>');
        for k:=1 to 5 do begin
                Memo8.Lines.Add('        <PrepAutoMachPass'+inttostr(k)+'>1</PrepAutoMachPass'+inttostr(k)+'>');
                Memo8.Lines.Add('        <AutoMachPass'+inttostr(k)+'>1</AutoMachPass'+inttostr(k)+'>');
        end;
        Memo8.Lines.Add('        <MachPassFromTecformStep2>0</MachPassFromTecformStep2>');
        Memo8.Lines.Add('        <specificpassModified>0</specificpassModified>');
        for k:=1 to 5 do Memo8.Lines.Add('        <TechnoNamePass'+inttostr(k)+'></TechnoNamePass'+inttostr(k)+'>');
        Memo8.Lines.Add('        <PreporbExeMode>0</PreporbExeMode>');
        Memo8.Lines.Add('        <orbExeMode>0</orbExeMode>');
        Memo8.Lines.Add('        <PrepHeaderLimitStartPower>0</PrepHeaderLimitStartPower>');
        Memo8.Lines.Add('        <HeaderLimitStartPower>0</HeaderLimitStartPower>');
        Memo8.Lines.Add('        <PrepHeaderPriority>'+suwak2o+'</PrepHeaderPriority>');
        Memo8.Lines.Add('        <HeaderPriority>'+suwak2o+'</HeaderPriority>');
        Memo8.Lines.Add('        <PrepHeaderAuto>1</PrepHeaderAuto>');
        Memo8.Lines.Add('        <HeaderAuto>1</HeaderAuto>');
        Memo8.Lines.Add('        <PrepHLS></PrepHLS>');
        Memo8.Lines.Add('        <HLS></HLS>');
        Memo8.Lines.Add('        <PrepPreMilledAuto>1</PrepPreMilledAuto>');
        Memo8.Lines.Add('        <PreMilledAuto>1</PreMilledAuto>');
        Memo8.Lines.Add('        <PrepPreMilledHeaderSecurity></PrepPreMilledHeaderSecurity>');
        Memo8.Lines.Add('        <PreMilledHeaderSecurity></PreMilledHeaderSecurity>');
        Memo8.Lines.Add('        <PrepPreMilledHeaderPriority>'+suwak2o+'</PrepPreMilledHeaderPriority>');
        Memo8.Lines.Add('        <PreMilledHeaderPriority>'+suwak2o+'</PreMilledHeaderPriority>');
        Memo8.Lines.Add('        <PreMilledRadius>0</PreMilledRadius>');
        Memo8.Lines.Add('        <PrepTexturing>0</PrepTexturing>');
        Memo8.Lines.Add('        <Texturing></Texturing>');
        Memo8.Lines.Add('        <PrepNoMachiningInTime>0</PrepNoMachiningInTime>');
        Memo8.Lines.Add('        <NoMachiningInTime>0</NoMachiningInTime>');
        Memo8.Lines.Add('        <PrioritiesForDescJob></PrioritiesForDescJob>');
        Memo8.Lines.Add('        <PrepTomeo>0</PrepTomeo>');
        Memo8.Lines.Add('        <Tomeo>0</Tomeo>');
        Memo8.Lines.Add('        <PrepEstimatedWearLength>0</PrepEstimatedWearLength>');
        Memo8.Lines.Add('        <EstimatedWearLength>0</EstimatedWearLength>');
        Memo8.Lines.Add('        <SurfaceEvolution><SurfaceEvolution></SurfaceEvolution></SurfaceEvolution>');
        Memo8.Lines.Add('        <PrepSetRetOrigin></PrepSetRetOrigin>');
        Memo8.Lines.Add('        <SetRetOrigin></SetRetOrigin>');
        Memo8.Lines.Add('        <ShapePieces>');
        for k:=0 to high(shPieces) do begin
            Memo8.Lines.Add('          <ShapePiece PN="'+inttostr(shPieces[k])+'">');
            Memo8.Lines.Add('            <CreationDate>'+getDateHMI()+'</CreationDate>');
            Memo8.Lines.Add('            <ModificationDate>'+getDateHMI()+'</ModificationDate>');
            Memo8.Lines.Add('          </ShapePiece>');
        end;
        Memo8.Lines.Add('        </ShapePieces>');
        Memo8.Lines.Add('        <ShapePoints>');
        for k:=0 to high(sh[i].sp) do begin
            Memo8.Lines.Add('          <ShapePoint PN="'+inttostr(sh[i].sp[k])+'">');
            Memo8.Lines.Add('            <CreationDate>'+getDateHMI()+'</CreationDate>');
            Memo8.Lines.Add('            <ModificationDate>'+getDateHMI()+'</ModificationDate>');
            Memo8.Lines.Add('          </ShapePoint>');
        end;
        Memo8.Lines.Add('        </ShapePoints>');
        Memo8.Lines.Add('        <ShapeTools>');
        for k:=0 to high(shTools) do begin
            Memo8.Lines.Add('          <ShapeTool TN="'+inttostr(shTools[k])+'">');
            Memo8.Lines.Add('            <CreationDate>'+getDateHMI()+'</CreationDate>');
            Memo8.Lines.Add('            <ModificationDate>'+getDateHMI()+'</ModificationDate>');
            Memo8.Lines.Add('          </ShapeTool>');
        end;
        Memo8.Lines.Add('        </ShapeTools>');
        Memo8.Lines.Add('        <SettingTables>');
        //showmessage(elHmi[j].name);
        for k:=0 to Form2.CheckListBox1.Items.Count-1 do begin
            if elHmi[j].elname=Form2.CheckListBox1.Items[k] then ell:=SplitString(';',Form2.ListBox1.Items[k]);
        end;
        //showmessage(ell[3]+AnsiString(#13#10)+ell[4]);
        if length(shTools)=1 then passnbr:=1
        else passnbr:=2;
        for k:=1 to passnbr do begin
            Memo8.Lines.Add('          <SettingTable FT="'+inttostr(k)+'">');
            Memo8.Lines.Add('            <CreationDate>'+getDateHMI()+'</CreationDate>');
            Memo8.Lines.Add('            <ModificationDate>'+getDateHMI()+'</ModificationDate>');
            Memo8.Lines.Add('            <CodeS>'+inttostr(shape_no)+inttostr(k)+'</CodeS>');
            if ((k=2) and (ell[4]<>'0') and (ell[10]<>'0')) then Memo8.Lines.Add('            <PrepUnderSize>'+floattostr(strtofloat(ell[4])/2)+'</PrepUnderSize>')
            else Memo8.Lines.Add('            <PrepUnderSize>'+floattostr(strtofloat(ell[3])/2)+'</PrepUnderSize>');
            Memo8.Lines.Add('            <UnderSize>0</UnderSize>');
            Memo8.Lines.Add('            <HCorrection></HCorrection>');
            Memo8.Lines.Add('            <WCorrection></WCorrection>');
            Memo8.Lines.Add('            <EStart>0</EStart>');
            Memo8.Lines.Add('            <EEnd>0</EEnd>');
            if k=passnbr then begin
               isostep:=ust.ReadString('settings','isogab_i2','4');
               isopendul:=ust.ReadString('settings','isogap_b2','4');
            end
            else begin
               isostep:=ust.ReadString('settings','isogap_i1','3');
               isopendul:=ust.ReadString('settings','isogap_b1','');
            end;
            Memo8.Lines.Add('            <ISOGAPStrategy>'+isostep+'</ISOGAPStrategy>');
            Memo8.Lines.Add('            <PrepISOGAPStrategy>'+isostep+'</PrepISOGAPStrategy>');
            Memo8.Lines.Add('            <ISOGAPStep>'+isostep+'</ISOGAPStep>');
            Memo8.Lines.Add('            <PrepISOGAPStep>'+isostep+'</PrepISOGAPStep>');
            Memo8.Lines.Add('            <ISOGAPPendul>'+isopendul+'</ISOGAPPendul>');
            Memo8.Lines.Add('            <PrepISOGAPPendul>'+isopendul+'</PrepISOGAPPendul>');
            Memo8.Lines.Add('            <WearPartType>0</WearPartType>');
            Memo8.Lines.Add('            <WearPartSetting>2</WearPartSetting>');
            Memo8.Lines.Add('          </SettingTable>');
        end;
        Memo8.Lines.Add('        </SettingTables>');
        Memo8.Lines.Add('        <FuturaSettings>');
        Memo8.Lines.Add('          <FuturaMemo>AE6A0D</FuturaMemo>');
        Memo8.Lines.Add('          <CreationDate>'+getDateHMI()+'</CreationDate>');
        Memo8.Lines.Add('          <ModificationDate>'+getDateHMI+'</ModificationDate>');
        Memo8.Lines.Add('          <FuturaMemoRef>2D640A</FuturaMemoRef>');
        Memo8.Lines.Add('          <Estimation></Estimation>');
        Memo8.Lines.Add('        </FuturaSettings>');
        if Label25.Caption='9.3.1' then begin
                 Memo8.Lines.Add('        <ExtendShape>');
                 Memo8.Lines.Add('            <CreationDate>'+getDateHMI+'</CreationDate>');
                 Memo8.Lines.Add('            <ModificationDate>'+getDateHMI+'</ModificationDate>');
                 Memo8.Lines.Add('            <SteppedToolNum>1</SteppedToolNum>');
                 Memo8.Lines.Add('            <execSteppedToolNum>1</execSteppedToolNum>');
                 Memo8.Lines.Add('            <PrepSteppedToolXml><slices><slice n="1"><type>1</type><height>'+floattostr(sh[i].edmDepth)+'</height><shapetype>0</shapetype><surface>'+floattostr(elHmi[j].fp)+'</surface><pattern>1</pattern></slice></slices></PrepSteppedToolXml>');
                 Memo8.Lines.Add('            <SteppedToolXml><slices><slice n="1"><type>1</type><height>'+floattostr(sh[i].edmDepth)+'</height><shapetype>0</shapetype><surface>'+floattostr(elHmi[j].fp)+'</surface><pattern>1</pattern></slice></slices></SteppedToolXml>');
                 for k:=2 to 5 do begin
                    Memo8.Lines.Add('            <PrepHeaderPriority'+inttostr(k)+'>2</PrepHeaderPriority'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <HeaderPriority'+inttostr(k)+'>2</HeaderPriority'+inttostr(k)+'>');
                 end;
                 for k:=2 to 5 do begin
                    Memo8.Lines.Add('            <PrepHLS'+inttostr(k)+'></PrepHLS'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <HLS'+inttostr(k)+'></HLS'+inttostr(k)+'>');
                 end;
                 for k:=2 to 5 do begin
                    Memo8.Lines.Add('            <PrepHeaderAuto'+inttostr(k)+'>1</PrepHeaderAuto'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <HeaderAuto'+inttostr(k)+'>1</HeaderAuto'+inttostr(k)+'>');
                 end;
                 for k:=2 to 5 do begin
                    Memo8.Lines.Add('            <PrepKeepSurfaceEvol'+inttostr(k)+'>0</PrepKeepSurfaceEvol'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <KeepSurfaceEvol'+inttostr(k)+'>0</KeepSurfaceEvol'+inttostr(k)+'>');
                 end;
                 for k:=1 to 5 do begin
                    Memo8.Lines.Add('            <PrepApplicationTypePass'+inttostr(k)+'>1</PrepApplicationTypePass'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <ApplicationTypePass'+inttostr(k)+'>1</ApplicationTypePass'+inttostr(k)+'>');
                 end;
                 for k:=1 to 5 do begin
                    Memo8.Lines.Add('            <PrepAutoSettingsAmount'+inttostr(k)+'>1</PrepAutoSettingsAmount'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <AutoSettingsAmount'+inttostr(k)+'>1</AutoSettingsAmount'+inttostr(k)+'>');
                 end;
                 for k:=1 to 5 do begin
                    Memo8.Lines.Add('            <PrepAutoFinalCurrent'+inttostr(k)+'>1</PrepAutoFinalCurrent'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <AutoFinalCurrent'+inttostr(k)+'>1</AutoFinalCurrent'+inttostr(k)+'>');
                 end;
                 for k:=1 to 5 do begin
                    Memo8.Lines.Add('            <PrepAutoFinalVDI'+inttostr(k)+'>1</PrepAutoFinalVDI'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <AutoFinalVDI'+inttostr(k)+'>1</AutoFinalVDI'+inttostr(k)+'>');
                 end;
                 for k:=1 to 5 do begin
                    Memo8.Lines.Add('            <PrepSettingsAmount'+inttostr(k)+'>40|5</PrepSettingsAmount'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <SettingsAmount'+inttostr(k)+'>40|5</SettingsAmount'+inttostr(k)+'>');
                 end;
                 for k:=1 to 5 do begin
                    Memo8.Lines.Add('            <PrepFinalCurrent'+inttostr(k)+'></PrepFinalCurrent'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <FinalCurrent'+inttostr(k)+'></FinalCurrent'+inttostr(k)+'>');
                 end;
                 for k:=1 to 5 do begin
                    Memo8.Lines.Add('            <PrepFinalVDI'+inttostr(k)+'></PrepFinalVDI'+inttostr(k)+'>');
                    Memo8.Lines.Add('            <FinalVDI'+inttostr(k)+'></FinalVDI'+inttostr(k)+'>');
                 end;
          Memo8.Lines.Add('            <OpenCavity>1</OpenCavity>');
          Memo8.Lines.Add('            <PrepOpenCavity>1</PrepOpenCavity>');
          Memo8.Lines.Add('        </ExtendShape>');
        end;
        Memo8.Lines.Add('      </Shape>');
        end;
    end;
    Memo8.Lines.Add('    </Shapes>');
    Memo8.Lines.Add('    <Related_Files></Related_Files>');
    Memo8.Lines.Add('    <Machining_Reports></Machining_Reports>');
    Memo8.Lines.Add('  </Job>');
    Memo8.Lines.Add('</Jobs>');
    Memo8.Lines.SaveToFile(xmlpath+'/'+Edit3.Text+'-'+'EDM-'+Edit16.Text+'.xmlj');
    //Memo8.Lines.SaveToFile(xmlpath+'/'+Edit3.Text+'-'+Edit18.Text+'EDM-'+Edit16.Text+'.xmlj');

    if vm>=1 then showmessage('Zapisano plik '+xmlpath+'\'+Edit3.Text+'-'+'EDM-'+Edit16.Text+'.xmlj');
    Button15.Enabled:=True;
    ust.Free;
 end
 else begin
        if vm>=1 then ShowMessage('Uzupełnij dane elektrod!');
        logToFile(Application.Location,'INF Tried to save .csv without filling electrode data');
 end;
end;

procedure SortF2();
var i,j:integer;
    sorted_ord,tmplist:TArrayOfString;
  exists:boolean;
begin
 if Form2.CheckListBox1.Items.Count>1 then begin
         //find sort orded in f1
         setLength(sorted_ord,0);
         for i:=0 to Form1.ListBox2.Items.Count-1 do begin
             exists:=false;
             for j:=0 to high(sorted_ord) do begin
                if sorted_ord[j]=Form1.ListBox2.Items[i] then exists:=true;
             end;
             if not exists then begin
                setLength(sorted_ord,length(sorted_ord)+1);
                sorted_ord[high(sorted_ord)]:=Form1.ListBox2.Items[i];
             end;
         end;
         //sort f2 lists
         setlength(tmplist,Form2.CheckListBox1.Items.Count);
         for i:=0 to Form2.CheckListBox1.Items.Count-1 do begin
              tmplist[i]:=Form2.CheckListBox1.Items[i];
         end;
     end;
end;

procedure TForm1.BitBtn7Click(Sender: TObject);
var i,j:integer;
begin
  if ListBox2.Items.Count>1 then begin
     logToFile(Application.Location,'INF AZ sort');
     for i:=1 to ListBox2.Items.Count-1 do begin
        for j:=0 to i-1 do begin
           if ListBox2.Items[i]<ListBox2.Items[j] then begin
               ListBox2.Items.Move(i,j);
               ListBox3.Items.Move(i,j);
               ListBox4.Items.Move(i,j);
               ListBox5.Items.Move(i,j);
               ListBox6.Items.Move(i,j);
               ListBox7.Items.Move(i,j);
               ListBox8.Items.Move(i,j);
               ListBox9.Items.Move(i,j);
               ListBox11.Items.Move(i,j);
               ListBox12.Items.Move(i,j);
               ListBox14.Items.Move(i,j);
               ListBox15.Items.Move(i,j);
           end;
        end;
     end;
  end;
end;

procedure TForm1.BitBtn8Click(Sender: TObject);
var i,j:integer;
begin
  if ListBox8.Items.Count>1 then begin
     logToFile(Application.Location,'INF fp sort');
     for i:=1 to ListBox8.Items.Count-1 do begin
        for j:=0 to i-1 do begin
           if strtofloat(ListBox8.Items[i])>strtofloat(ListBox8.Items[j]) then begin
               ListBox2.Items.Move(i,j);
               ListBox3.Items.Move(i,j);
               ListBox4.Items.Move(i,j);
               ListBox5.Items.Move(i,j);
               ListBox6.Items.Move(i,j);
               ListBox7.Items.Move(i,j);
               ListBox8.Items.Move(i,j);
               ListBox9.Items.Move(i,j);
               ListBox11.Items.Move(i,j);
               ListBox12.Items.Move(i,j);
               ListBox14.Items.Move(i,j);
               ListBox15.Items.Move(i,j);
           end;
        end;
     end;

  end;
end;

procedure TForm1.BitBtn9Click(Sender: TObject);
var xj,cmdfil:TextFile;
  fd,gcyc:string;
  pieces,pval,rval,elv,relv,relv2,tl,sh,genmes,elv_points,lin,elfc:TArrayOfString;
  i,j,k,l,countpp,el_n,aoe,global_aoe,gaoe2,elind,shape_nr,passnbr,ff_sn,rii,max_shapes,ums,cmdp,cmde,cea,aea,r_i,countel,el_pr,el_pr_1:integer;
  pinf:Array[0..10] of string;
  einf:Array[0..200] of string;
  einf2:Array[0..200] of string;
  shape_names:Array[0..200] of string;
  shape_points:Array[0..200] of string;
  distinct_um:Array[0..10] of string;
  chip_id:Array of string;
  chip_nam:Array of string;
  curz,magpos,mdet,new_sn,isogapstep,qcode,suwak1,suwak2,suwak2o,line,xmljVersion,currentEDMDepth,tmpLine:string;
  do_this_el,found_sn,feum,new_um,removeLines:boolean;
  oldx,oldy,oldc,newx,newy,newc,wpc,wpx,wpy,nwpx,nwpy,c180,cus:real;
  ust,cf_sett:TInifile;
begin

 global_aoe:=0;
  if Form2.Label13.Caption='done' then begin
     SaveDialog3.FileName:=Edit3.Text;
     ust:=TInifile.Create(ChangeFileExt(Application.ExeName,'.ini'));
     xmljVersion:=ust.ReadString('settings','xmljVersion','9.0.0');
     SaveDialog3.InitialDir:=ust.ReadString('settings','pathXMLJ','V:\XML');
     removeLines:=ust.ReadBool('settings','AutoDelLinesCmd',false);


     Memo1.Lines.Clear;
      if SaveDialog3.Execute then begin //location of xmlj file selected
          if vm>=2 then Showmessage('Start of file');

          ProgressBar1.Max:=60;
          ProgressBar1.Min:=0;
          ProgressBar1.Position:=0;
          DateTimeToString(fd,'yyyy/mm/dd hh:nn:ss',Now); //date used for evert creation and modification date in xmlj file
          //AssignFile(xj,SaveDialog3.FileName);
          //showmessage('Pass2');
          Memo5.Clear;
          //rewrite(xj);
          Memo5.Lines.Add('<?xml version="1.0" encoding="windows-1252"?>');
          Memo5.Lines.Add('<Jobs>');
          Memo5.Lines.Add('  <Version>'+xmljVersion+'</Version>');
          Memo5.Lines.Add('  <Futura>1</Futura>');
          Memo5.Lines.Add('  <Job Name="'+Edit3.Text+'">');
          Memo5.Lines.Add('    <Comment>'+Edit3.Text+'ai'+Edit16.Text+' - '+Edit15.Text+'</Comment>');
          Memo5.Lines.Add('    <Type>1</Type>');
          Memo5.Lines.Add('    <FlushingOnAtStart>1</FlushingOnAtStart>');
          Memo5.Lines.Add('    <TankEmptyingAtEnd>1</TankEmptyingAtEnd>');
          Memo5.Lines.Add('    <FlushingOffAtEnd>1</FlushingOffAtEnd>');
          Memo5.Lines.Add('    <UnloadToolAtEnd>1</UnloadToolAtEnd>');
          Memo5.Lines.Add('    <UnloadPalletAtEnd>1</UnloadPalletAtEnd>');
          Memo5.Lines.Add('    <CreationDate>'+fd+'</CreationDate>');
          Memo5.Lines.Add('    <ModificationDate>'+fd+'</ModificationDate>');
          Memo5.Lines.Add('      <IsoHeader>');
          Memo5.Lines.Add('        <Line N="1">#{SYS_SECZPLAN_ALT}=350</Line>');
          Memo5.Lines.Add('      </IsoHeader>');
          Memo5.Lines.Add('      <IsoFooter>');
          cf_sett:=TIniFile.Create('C:\certafix\config.ini');
          Memo5.Lines.Add('         <Line N="1">IF #3003 LE 4 THEN G4X'+inttostr(cf_sett.ReadInteger('Settings','additionalTime',30)*60)+'</Line>');
          cf_sett.Free;
          Memo5.Lines.Add('      </IsoFooter>');
          Memo5.Lines.Add('      <IsoGeneric/>');
          Memo5.Lines.Add('    <IsoGenerationDate>'+fd+'</IsoGenerationDate>');
          Memo5.Lines.Add('    <CoherenceModificationDate>'+fd+'</CoherenceModificationDate>');
          Memo5.Lines.Add('    <PartExpressSeq>-1</PartExpressSeq>');
          Memo5.Lines.Add('    <JobProfile></JobProfile>');
          Memo5.Lines.Add('    <JobWorkshop></JobWorkshop>');
          Memo5.Lines.Add('    <OneTJobType>0</OneTJobType>');
          Memo5.Lines.Add('    <OneTJobCavityType>0</OneTJobCavityType>');
          Memo5.Lines.Add('    <OneTJobEDMType>0</OneTJobEDMType>');
          Memo5.Lines.Add('    <OneTJobModelSource></OneTJobModelSource>');
          Memo5.Lines.Add('    <OneTJobUserSeq></OneTJobUserSeq>');
          Memo5.Lines.Add('    <ErrHisto></ErrHisto>');
          Memo5.Lines.Add('    <Certificat></Certificat>');
          Memo5.Lines.Add('    <WearPartType>0</WearPartType>');
          Memo5.Lines.Add('    <WearPartSetting>2</WearPartSetting>');
          Memo5.Lines.Add('    <PartExpressSeqSub>0</PartExpressSeqSub>');
          Memo5.Lines.Add('    <SimpliedISOGeneration>False</SimpliedISOGeneration>');
          Memo5.Lines.Add('    <WearPartPrioSeq>False</WearPartPrioSeq>');
          Memo5.Lines.Add('    <ToolCompensationActive>0</ToolCompensationActive>');
          Memo5.Lines.Add('    <SmartToolEnabled>False</SmartToolEnabled>');
          Memo5.Lines.Add('    <WearPartActivated>False</WearPartActivated>');
          Memo5.Lines.Add('    <FilterKeys></FilterKeys>');
          Memo5.Lines.Add('    <Pdf></Pdf>');
          Memo5.Lines.Add('    <HideISOInputDlg>False</HideISOInputDlg>');
          if xmljVersion='9.3.1' then begin
             Memo5.Lines.Add('    <SimplifiedCavityISOGeneration>False</SimplifiedCavityISOGeneration>');
             Memo5.Lines.Add('    <StepSortingWizardConfig></StepSortingWizardConfig>');
             Memo5.Lines.Add('    <StepCurrentSorting>1</StepCurrentSorting>');
             Memo5.Lines.Add('    <StepPalletChangePriority>0</StepPalletChangePriority>');
          end;
          if vm>=2 then showmessage('Start pieces');
          Memo5.Lines.Add('    <Pieces>');
          pieces:=SplitString(',',LabeledEdit1.Text);
          ProgressBar1.Position:=5;
          if OpenDialog3.Execute then begin //load from file
             logToFile(Application.Location,'INF Loaded measure file: '+OpenDialog3.FileName);
             if ExtractFileExt(OpenDialog3.FileName)='.mes' then begin
                Memo1.Lines.LoadFromFile(OpenDialog3.FileName); //TODO: file needs to be changed to account for multi electrodes
             end
             else begin
                 AssignFile(cmdfil,OpenDialog3.FileName);
                 reset(cmdfil);
                 cmdp:=0;
                 cmde:=0;
                 aea:=0;
                 r_i:=0;
                 repeat
                    readln(cmdfil,line);
                    lin:=SplitString(',',line);
                    if AnsiContainsStr(line,'T') then begin
                         inc(cmde);
                         for i:=0 to Form2.ListBox1.Count-1 do begin
                            genmes:=SplitString(';',Form2.ListBox1.Items[i]);
                            for j:=3 to 8 do if genmes[j]<>'0' then cea:=j-2;
                            //showmessage('i :'+inttostr(i)+AnsiString(#13#10)+'r_i: '+inttostr(r_i)+AnsiString(#13#10)+'cmde: '+inttostr(cmde)+AnsiString(#13#10)+'aea: '+inttostr(aea)+AnsiString(#13#10)+'cea: '+inttostr(cea));
                            if ((cmde<=(aea+cea)) and (cmde>aea) and (i=r_i)) then begin
                               Memo1.Lines.Add(Form2.CheckListBox1.Items[i]+';R'+inttostr(cmde-aea)+',U,,0,,,,,,,'+copy(lin[1],2,10)+','+copy(lin[2],2,10)+','+copy(lin[3],2,10)+',0.000,0.000,'+copy(lin[4],2,10)+',0,0,0,,0.000,,,,,,');
                            end;
                            if ((cmde=(aea+cea)) and (i=Form2.ListBox1.Count-1)) then begin
                               aea:=aea+cea;
                               inc(r_i);
                            end;
                         end;
                    end
                    else if AnsiContainsStr(line,'M') then begin
                         Memo1.Lines.Add(Edit3.Text+':'+inttostr(cmdp)+',W,,,,,,,,,'+copy(lin[1],2,10)+','+copy(lin[2],2,10)+','+copy(lin[3],2,10)+',0.000,0.000,'+copy(lin[4],2,10)+',,,,,,,,,');
                         inc(cmdp);
                    end;
                 until eof(cmdfil);
                 CloseFile(cmdfil);
             end;
          end
          else begin //generate from itself, with zero values
               for i:=0 to length(pieces)-1 do Memo1.Lines.Add(Edit3.Text+':'+inttostr(i)+',W,,,,,,,,,0.000,0.000,0.000,0.000,0.000,0.000,,,,,,,,,');
               for i:=0 to Form2.ListBox1.Count-1 do begin
                   genmes:=SplitString(';',Form2.ListBox1.Items[i]);
                   if genmes[3]<>'0' then Memo1.Lines.Add(Form2.CheckListBox1.Items[i]+';R1,U,,0,,,,,,,0.000,0.000,0.000,0.000,0.000,0.000,0,0,0,,0.000,,,,,,');
                   if genmes[4]<>'0' then Memo1.Lines.Add(Form2.CheckListBox1.Items[i]+';R2,U,,0,,,,,,,0.000,0.000,0.000,0.000,0.000,0.000,0,0,0,,0.000,,,,,,');
                   if genmes[5]<>'0' then Memo1.Lines.Add(Form2.CheckListBox1.Items[i]+';R3,U,,0,,,,,,,0.000,0.000,0.000,0.000,0.000,0.000,0,0,0,,0.000,,,,,,');
                   if genmes[6]<>'0' then Memo1.Lines.Add(Form2.CheckListBox1.Items[i]+';R4,U,,0,,,,,,,0.000,0.000,0.000,0.000,0.000,0.000,0,0,0,,0.000,,,,,,');
                   if genmes[7]<>'0' then Memo1.Lines.Add(Form2.CheckListBox1.Items[i]+';R5,U,,0,,,,,,,0.000,0.000,0.000,0.000,0.000,0.000,0,0,0,,0.000,,,,,,');
                   if genmes[8]<>'0' then Memo1.Lines.Add(Form2.CheckListBox1.Items[i]+';R6,U,,0,,,,,,,0.000,0.000,0.000,0.000,0.000,0.000,0,0,0,,0.000,,,,,,');
               end;
          end;
          //showmessage('Pass3');
          //check if any workpiece data in mes file
          countpp:=0;
          countel:=0;
          for i:=0 to Memo1.Lines.Count-1 do begin
              pval:=SplitString(',',Memo1.Lines[i]);
              if pval[1]='W' then begin
                 inc(countpp);
                 pinf[(countpp-1)]:=pval[10]+';'+pval[11]+';'+pval[12]+';'+pval[15];
              end;
              if pval[1]='U' then begin
                 inc(countel);
              end;
          end;

          el_pr:=0;
          for i:=0 to Form2.ListBox1.Items.Count-1 do begin
              elfc:=SplitString(';',Form2.ListBox1.Items[i]);
              if elfc[14]<>'0' then el_pr:=el_pr+6
              else if elfc[13]<>'0' then el_pr:=el_pr+5
              else if elfc[12]<>'0' then el_pr:=el_pr+4
              else if elfc[11]<>'0' then el_pr:=el_pr+3
              else if elfc[10]<>'0' then el_pr:=el_pr+2
              else if elfc[9]<>'0' then el_pr:=el_pr+1
              else showmessage('Brak danych elektrody '+elfc[0]+' !');
          end;

          if countpp=0 then begin // mes file opened, but no workpiece data, generate it with zeros:
              for i:=0 to length(pieces)-1 do Memo1.Lines.Add(Edit3.Text+':'+inttostr(i)+',W,,,,,,,,,0.000,0.000,0.000,0.000,0.000,0.000,,,,,,,,,');
              for i:=0 to Memo1.Lines.Count-1 do begin
              pval:=SplitString(',',Memo1.Lines[i]);
              if pval[1]='W' then begin
                 inc(countpp);
                 pinf[(countpp-1)]:=pval[10]+';'+pval[11]+';'+pval[12]+';'+pval[15];
              end;
          end;
          end;

          //Pass4 - remove manual lines if the option is selected
          if removeLines then begin
              if length(pieces)<>countpp then begin //pieces
                 if (length(pieces)*2)=countpp then begin
                    countpp:=0;
                    Memo6.Clear;
                     for i:=0 to Memo1.Lines.Count-1 do begin
                         pval:=SplitString(',',Memo1.Lines[i]);
                         if pval[1]='W' then begin
                            inc(countpp);
                            if (countpp mod 2)=0 then Memo6.Lines.Add(Memo1.Lines[i]);
                         end
                         else Memo6.Lines.Add(Memo1.Lines[i]); //leave electrodes as is for now
                     end;
                     Memo1.Clear;
                     for i:=1 to Memo6.Lines.Count-1 do Memo1.Lines.Add(Memo6.Lines[i]);
                 end;
              end;
              //TODO: Ckeck every el
              //if el_pr<>countel then begin //sum
              //    for i:=0 to From2.ListBox1.Items.Count-1 do begin
              //        //for every electrode delete 1 line
              //        elfc:=SplitString(';',Form2.ListBox1.Items[i]);
              //
              //    end;
              end;
          end;

          ProgressBar1.Position:=10;
          if length(pieces)<>countpp then ShowMessage('Niezgodność danych z CMM - detale ('+inttostr(length(pieces))+' ≠ '+inttostr(countpp)+')');
          if el_pr<>countel then ShowMessage('Niezgodność danych z CMM - elektrody ()');
          for i:=0 to length(pieces)-1 do begin
              rval:=SplitString(';',pinf[i]);
              Memo5.Lines.Add('      <Piece N="'+inttostr(i+1)+'">');
              Memo5.Lines.Add('        <Name>'+Edit3.Text+':'+inttostr(i)+'</Name>');
              wpx:=strtofloat(rval[0]);
              wpy:=strtofloat(rval[1]);
              wpc:=strtofloat(rval[3]);
              if ExtractFileExt(OpenDialog3.FileName)='.mes' then begin
                 nwpx:=roundto((wpx*cos(degtorad(-(wpc*(-1)))))-(wpy*sin(degtorad(-(wpc*(-1))))),4); //calculate back to measured values
                 nwpy:=roundto((wpx*sin(degtorad(-(wpc*(-1)))))+(wpy*cos(degtorad(-(wpc*(-1))))),4);
              end
              else begin
                 nwpx:=wpx;
                 nwpy:=wpy;
              end;
              Memo5.Lines.Add('        <X>'+floattostr(nwpx)+'</X>');
              Memo5.Lines.Add('        <Y>'+floattostr(nwpy)+'</Y>');
              Memo5.Lines.Add('        <Z>'+floattostr(strtofloat(rval[2])-strtofloat(Edit13.Text))+'</Z>');
              Memo5.Lines.Add('        <Rot>'+rval[3]+'</Rot>');
              if floor(strtofloat(rval[2]))=0 then Memo5.Lines.Add('        <HBac>0</HBac>') //to avoid sparking without dielectric.
              else Memo5.Lines.Add('        <HBac>'+inttostr(floor(strtofloat(rval[2]))+70)+'</HBac>'); //dielectric height
              Memo5.Lines.Add('        <Palette>0</Palette>');
              Memo5.Lines.Add('        <MagPos>'+pieces[i]+'</MagPos>');
              Memo5.Lines.Add('        <Mandrin>1</Mandrin>'); //chuck number, always 1
              Memo5.Lines.Add('        <CreationDate>'+fd+'</CreationDate>');
              Memo5.Lines.Add('        <ModificationDate>'+fd+'</ModificationDate>');
              Memo5.Lines.Add('        <PartAxisA>0</PartAxisA>');
              Memo5.Lines.Add('        <PartAxisB>0</PartAxisB>');
              Memo5.Lines.Add('        <ChipID></ChipID>');
              Memo5.Lines.Add('        <Conop_Pos_X></Conop_Pos_X>');
              Memo5.Lines.Add('        <Conop_Pos_Y></Conop_Pos_Y>');
              Memo5.Lines.Add('        <Conop_Pos_Z></Conop_Pos_Z>');
              Memo5.Lines.Add('        <Conop_Pos_C></Conop_Pos_C>');
              Memo5.Lines.Add('        <Conop_RefCor_X>0</Conop_RefCor_X>');
              Memo5.Lines.Add('        <Conop_RefCor_Y>0</Conop_RefCor_Y>');
              Memo5.Lines.Add('        <Conop_RefCor_Z>0</Conop_RefCor_Z>');
              Memo5.Lines.Add('        <Conop_RefCor_C>0</Conop_RefCor_C>');
              Memo5.Lines.Add('        <Conop_ID>0</Conop_ID>');
              Memo5.Lines.Add('      </Piece>');
          end;
          Memo5.Lines.Add('    </Pieces>');
          ProgressBar1.Position:=20;
          if vm>=2 then showmessage('Start Points');
          Memo5.Lines.Add('    <Points>');

          shape_nr:=0;
          for i:=0 to ListBox2.Count-1 do begin
             do_this_el:=False;
             for j:=0 to Form2.CheckListBox1.Count-1 do begin
                 if ListBox2.Items[i]=Form2.CheckListBox1.Items[j] then begin
                      if Form2.CheckListBox1.Checked[j] then do_this_el:=True;
                 end;
             end;
             if do_this_el then begin
                inc(shape_nr);
              Memo5.Lines.Add('      <Point N="'+inttostr(shape_nr)+'">');
              if AnsiContainsStr(ListBox9.Items[i],'X') then begin
                  if AnsiContainsStr(ListBox9.Items[i],'+') then Memo5.Lines.Add('        <X>'+floattostr(strtofloat(ListBox3.Items[i])-strtofloat(ListBox11.Items[i]))+'</X>');
                  if AnsiContainsStr(ListBox9.Items[i],'-') then Memo5.Lines.Add('        <X>'+floattostr(strtofloat(ListBox3.Items[i])+strtofloat(ListBox11.Items[i]))+'</X>');
              end
              else Memo5.Lines.Add('        <X>'+ListBox3.Items[i]+'</X>');
              if AnsiContainsStr(ListBox9.Items[i],'Y') then begin
                  if AnsiContainsStr(ListBox9.Items[i],'+') then Memo5.Lines.Add('        <Y>'+floattostr(strtofloat(ListBox4.Items[i])-strtofloat(ListBox11.Items[i]))+'</Y>');
                  if AnsiContainsStr(ListBox9.Items[i],'-') then Memo5.Lines.Add('        <Y>'+floattostr(strtofloat(ListBox4.Items[i])+strtofloat(ListBox11.Items[i]))+'</Y>');
              end
              else Memo5.Lines.Add('        <Y>'+ListBox4.Items[i]+'</Y>');

              for j:=0 to Form2.ListBox1.Count-1 do begin
                   elv_points:=SplitString(';',Form2.ListBox1.Items[j]);
                   if elv_points[0]=ListBox2.Items[i] then cus:=strtofloat(elv_points[3])/2; //find out indersize per side of current electrode
              end;

              if ListBox9.Items[i]='Z' then Memo5.Lines.Add('        <Z>'+ListBox11.Items[i]+'</Z>') //startpoint must be equal to FromDistance !!!
              else Memo5.Lines.Add('        <Z>'+floattostr(strtofloat(ListBox6.Items[i])+cus)+'</Z>'); //side eroding - startpoint at Z coord minus undersize pre side!
              c180:=strtofloat(ListBox5.Items[i]);
              if not CheckBox7.Checked then c180:=c180+180;  //rotate because chip direction is different on x400 magazine, unless opened csv saved for CERTA
              if c180>=360 then c180:=c180-360; //normalize C to 0-360
              Memo5.Lines.Add('        <Rot>'+floattostr(roundto(c180,4))+'</Rot>');
              Memo5.Lines.Add('        <FromDistance>'+ListBox11.Items[i]+'</FromDistance>');  //startpoint must be equal to FromDistance in Z eroding!!!
              Memo5.Lines.Add('        <X0>'+ListBox3.Items[i]+'</X0>');
              Memo5.Lines.Add('        <Y0>'+ListBox4.Items[i]+'</Y0>');
              if ListBox9.Items[i]='Z' then Memo5.Lines.Add('        <Z0>0</Z0>') // normal - Z
              else Memo5.Lines.Add('        <Z0>'+floattostr(strtofloat(ListBox6.Items[i])+cus)+'</Z0>'); //side
              tmpLine:='        <AngleX>';
              if ListBox9.Items[i]='Z' then tmpLine:=tmpLine+'0'
              else begin
                  case ListBox9.Items[i] of
                      'X+': tmpLine:=tmpLine+'180';
                      'Y+': tmpLine:=tmpLine+'270';
                      'X-': tmpLine:=tmpLine+'0';
                      'Y-': tmpLine:=tmpLine+'90';
                      '+X': tmpLine:=tmpLine+'180';
                      '+Y': tmpLine:=tmpLine+'270';
                      '-X': tmpLine:=tmpLine+'0';
                      '-Y': tmpLine:=tmpLine+'90';
                  end;
              end;
              tmpLine:=tmpLine+'</AngleX>';
              Memo5.Lines.Add(tmpLine);
              Memo5.Lines.Add('        <CavityType>1</CavityType>');
              Memo5.Lines.Add('        <Zf>0</Zf>');
              tmpLine:='        <AngleZ>';
              if ListBox9.Items[i]='Z' then tmpLine:=tmpLine+'0'
              else tmpLine:=tmpLine+'90'; //always 90 for side eroding, direction regulated in <AngleX>
              tmpLine:=tmpLine+'</AngleZ>';
              Memo5.Lines.Add(tmpLine);
              Memo5.Lines.Add('        <CreationDate>'+fd+'</CreationDate>');
              Memo5.Lines.Add('        <ModificationDate>'+fd+'</ModificationDate>');
              Memo5.Lines.Add('        <AxisA>0</AxisA>');
              Memo5.Lines.Add('        <AxisB>0</AxisB>');
              Memo5.Lines.Add('        <SpecificCavity>0</SpecificCavity>');
              Memo5.Lines.Add('        <MCType>0</MCType>');
              Memo5.Lines.Add('        <MCD1></MCD1>');
              Memo5.Lines.Add('        <MCN1>0</MCN1>');
              Memo5.Lines.Add('        <MCD2></MCD2>');
              Memo5.Lines.Add('        <MCN2>0</MCN2>');
              Memo5.Lines.Add('        <MCR>0</MCR>');
              Memo5.Lines.Add('        <MCI>0</MCI>');
              Memo5.Lines.Add('        <MCJ>0</MCJ>');
              Memo5.Lines.Add('        <MCIndex>0</MCIndex>');
              Memo5.Lines.Add('        <MCSettingChain>0</MCSettingChain>');
              Memo5.Lines.Add('        <MCSettingAlternate>0</MCSettingAlternate>');
              Memo5.Lines.Add('        <Xf>0</Xf>');
              Memo5.Lines.Add('        <Yf>0</Yf>');
              Memo5.Lines.Add('      </Point>');
             end;
          end;
          Memo5.Lines.Add('    </Points>');
          ProgressBar1.Position:=30;
          if vm>=2 then showmessage('Start Tools');
          Memo5.Lines.Add('    <Tools>');
          if xmljVersion='9.3.1' then begin
              Memo5.Lines.Add('      <Tool N="0">');
              Memo5.Lines.Add('        <FinitionType>5</FinitionType>');
              Memo5.Lines.Add('        <Name>GARBAGE/UNASSIGNED</Name>');
              Memo5.Lines.Add('        <X>0</X>');
              Memo5.Lines.Add('        <Y>0</Y>');
              Memo5.Lines.Add('        <Z>0</Z>');
              Memo5.Lines.Add('        <C>0</C>');
              Memo5.Lines.Add('        <MagPos></MagPos>');
              Memo5.Lines.Add('        <Inertie>1</Inertie>');
              Memo5.Lines.Add('        <UnderSize>0</UnderSize>');
              Memo5.Lines.Add('        <CreationDate>'+fd+'</CreationDate>');
              Memo5.Lines.Add('        <ModificationDate>'+fd+'</ModificationDate>');
              Memo5.Lines.Add('        <Radius></Radius>');
              Memo5.Lines.Add('        <ChipID></ChipID>');
              Memo5.Lines.Add('        <SizeInMagasin>1</SizeInMagasin>');
              Memo5.Lines.Add('        <Material></Material>');
              Memo5.Lines.Add('        <ToolDecFamily>0</ToolDecFamily>');
              for i:=1 to 5 do begin
                 Memo5.Lines.Add('        <ToolDecCount'+inttostr(i)+'>100</ToolDecCount'+inttostr(i)+'>');
              end;
              Memo5.Lines.Add('        <ToolDecWear>0</ToolDecWear>');
              Memo5.Lines.Add('        <UEDMComp>0</UEDMComp>');
              Memo5.Lines.Add('        <UCavComp>0</UCavComp>');
              Memo5.Lines.Add('        <FrontalOffset>0</FrontalOffset>');
              Memo5.Lines.Add('        <ToolDecWearF>0</ToolDecWearF>');
              Memo5.Lines.Add('      </Tool>');
          end;
          el_n:=1;
          gaoe2:=0;
          for i:=0 to Form2.ListBox1.Count-1 do begin //for every electrode
             if Form2.CheckListBox1.Checked[i] then begin
              elv:=SplitString(';',Form2.ListBox1.Items[i]);
              if elv[8]<>'0' then aoe:=6
              else if elv[7]<>'0' then aoe:=5
              else if elv[6]<>'0' then aoe:=4
              else if elv[5]<>'0' then aoe:=3
              else if elv[4]<>'0' then aoe:=2
              else aoe:=1;
              einf2[i]:='';
              for j:=1 to aoe do begin //for each electrode on current family
                  if length(einf2[i])>0 then einf2[i]:=einf2[i]+',';
                  einf2[i]:=einf2[i]+inttostr(gaoe2+j); //create easily accesible data table
              end;
              gaoe2:=gaoe2+aoe; // gloal amount of electrodes.
              if aoe=1 then einf[i]:=inttostr(global_aoe+1)
             else if aoe=2 then einf[i]:=inttostr(global_aoe+1)+'.'+inttostr(global_aoe+2)
             else einf[i]:=inttostr(global_aoe+1)+'-'+inttostr(global_aoe+aoe);
             global_aoe:=global_aoe+aoe; //global amount of electrodes
             ums:=0;
             feum:=False;
             for j:=1 to 10 do distinct_um[j]:='_';
             for j:=1 to aoe do begin //see how many different understze types there are
                 new_um:=True;
                 for k:=1 to 10 do begin
                     if distinct_um[k]=elv[(2+j)] then new_um:=False;
                 end;
                 //showmessage('j: '+inttostr(j)+', first_empty_um: '+inttostr(first_empty_um));
                 if new_um then begin
                     distinct_um[(ums+1)]:=elv[(2+j)];
                     inc(ums);
                 end;
             end;
             j:=1;
             for j:=1 to aoe do begin
                  Memo5.Lines.Add('      <Tool N="'+inttostr(el_n)+'">');
                  tmpLine:='        <FinitionType>'; // current machining pass number

                  if ums=1 then begin
                     if j=1 then tmpLine:=tmpLine+'1' //first electrode always roughing
                     else if ((j=2) and (aoe>=5)) then  tmpLine:=tmpLine+'2' //el. no. 2 roughing when total number of electrodes is 5 or greater.
                     else tmpLine:=tmpLine+'2'; //el no 3 and later always finishing
                  end
                  else begin
                       if elv[(2+j)]=distinct_um[1] then tmpLine:=tmpLine+'1' //in this case, respect number of roughing/finishing electrodes made by milling
                       else tmpLine:=tmpLine+'2';
                  end;

                  tmpLine:=tmpLine+'</FinitionType>';
                  Memo5.Lines.Add(tmpLine);
                  Memo5.Lines.Add('        <Name>'+elv[0]+'_R'+inttostr(j)+'</Name>');
                  k:=0;
                  for k:=0 to Memo1.Lines.Count-1 do begin
                     relv:=SplitString(',',Memo1.Lines[k]);
                     if relv[1]='U' then begin
                        relv2:=SplitString(';',relv[0]);
                        if relv2[0]=elv[0] then begin
                           if relv2[1]='R'+inttostr(j) then begin  //get offsets of current electrode
                              oldx:=strtofloat(relv[10]);
                              oldy:=strtofloat(relv[11]);
                              curz:=relv[12];
                              oldc:=strtofloat(relv[15]);
                           end;
                        end;
                     end;
                  end;
                  newc:=roundto(normalize_c(oldc),4);
                  if oldx=0 then oldx:=0.0001; // to avoid error causing wrong calculation
                  if oldy=0 then oldy:=0.0001;
                  if not CheckBox9.Checked then begin //use offsets as sent, already calculated to rotated coordinate system
                      newx:=oldx;
                      newy:=-oldy; //result of chip being on the opposite side of electrode
                  end
                  else begin //calculate new X and Y in rotated coordinate system.
                      newx:=roundto((oldx*cos(degtorad(-newc)))-(oldy*sin(degtorad(-newc))),4);
                      newy:=-roundto((oldx*sin(degtorad(-newc)))+(oldy*cos(degtorad(-newc))),4);
                  end;
                  if ((elv[16]='1') and ((j mod 2)=0)) then begin //if multielectrode and 2,4 or 6
                      newx:=newx*(-1);
                      newy:=newy*(-1);
                      newc:=newc+180;
                      if newc>=360 then newc:=newc-360;
                  end;
                  Memo5.Lines.Add('        <X>'+floattostr(newx)+'</X>');
                  Memo5.Lines.Add('        <Y>'+floattostr(newy)+'</Y>');
                  Memo5.Lines.Add('        <Z>'+curz+'</Z>');
                  Memo5.Lines.Add('        <C>'+floattostr(newc)+'</C>');

                  magpos:='';
                  for k:=length(elv[(8+j)]) to 3 do magpos:=magpos+'0'; //fill magpos with appropriate number of zeros at the begining
                  magpos:=magpos+elv[(8+j)];
                  Memo5.Lines.Add('        <MagPos>20'+magpos+'</MagPos>');
                  Memo5.Lines.Add('        <Inertie>1</Inertie>'); //can be 1, 2 or 3
                  Memo5.Lines.Add('        <UnderSize>'+floattostr(strtofloat(elv[(2+j)])/2)+'</UnderSize>');  //undersize per side
                  Memo5.Lines.Add('        <CreationDate>'+fd+'</CreationDate>');
                  Memo5.Lines.Add('        <ModificationDate>'+fd+'</ModificationDate>');
                  Memo5.Lines.Add('        <Radius></Radius>');
                  Memo5.Lines.Add('        <ChipID></ChipID>');
                  Memo5.Lines.Add('        <SizeInMagasin>1</SizeInMagasin>');
                  Memo5.Lines.Add('        <Material>'+mat_x400(elv[1])+'</Material>');
                  Memo5.Lines.Add('        <ToolDecFamily>'+inttostr(el_n)+'</ToolDecFamily>');
                  for k:=1 to 5 do Memo5.Lines.Add('        <ToolDecCount'+inttostr(k)+'>100</ToolDecCount'+inttostr(k)+'>');
                  Memo5.Lines.Add('        <ToolDecWear>0</ToolDecWear>');
                  Memo5.Lines.Add('        <UEDMComp>0</UEDMComp>');
                  Memo5.Lines.Add('        <UCavComp>0</UCavComp>');
                  Memo5.Lines.Add('        <FrontalOffset>0</FrontalOffset>');
                  Memo5.Lines.Add('        <ToolDecWearF>0</ToolDecWearF>');
                  Memo5.Lines.Add('        <ToolReals>');
                  Memo5.Lines.Add('          <ToolReal N="'+inttostr(el_n+999)+'">');
                  Memo5.Lines.Add('            <Name></Name>');
                  Memo5.Lines.Add('            <X>0</X>');
                  Memo5.Lines.Add('            <Y>0</Y>');
                  Memo5.Lines.Add('            <Z>0</Z>');
                  Memo5.Lines.Add('            <C>0</C>');
                  Memo5.Lines.Add('            <MagPos></MagPos>');
                  Memo5.Lines.Add('            <UnderSize>0</UnderSize>');
                  Memo5.Lines.Add('            <CreationDate>'+fd+'</CreationDate>');
                  Memo5.Lines.Add('            <ModificationDate>'+fd+'</ModificationDate>');
                  Memo5.Lines.Add('            <Radius></Radius>');
                  Memo5.Lines.Add('            <ChipID></ChipID>');
                  for k:=1 to 5 do Memo5.Lines.Add('            <ToolDecCount'+inttostr(k)+'>100</ToolDecCount'+inttostr(k)+'>');
                  Memo5.Lines.Add('            <initUnderSize>0</initUnderSize>');
                  for k:=1 to 5 do Memo5.Lines.Add('            <initToolDecCount'+inttostr(k)+'>-2</initToolDecCount'+inttostr(k)+'>');
                  Memo5.Lines.Add('            <Inertie>1</Inertie>');
                  Memo5.Lines.Add('            <fragUse>0</fragUse>');
                  Memo5.Lines.Add('            <fragSCode>0</fragSCode>');
                  Memo5.Lines.Add('            <FrontalOffset>0</FrontalOffset>');
                  Memo5.Lines.Add('            <initFrontalOffset>0</initFrontalOffset>');
                  Memo5.Lines.Add('            <initTemplateNum>0</initTemplateNum>');
                  Memo5.Lines.Add('          </ToolReal>');
                  Memo5.Lines.Add('        </ToolReals>');
                  Memo5.Lines.Add('      </Tool>');
                  inc(el_n);
              end;
             end;
             //end;
          end;
          //add scanner here
          if CheckBox8.Checked then begin
             Memo5.Lines.Add('      <Tool N="'+inttostr(el_n)+'">');
             Memo5.Lines.Add('        <FinitionType>6</FinitionType>'); //finition type 6 means scanner
             Memo5.Lines.Add('        <Name>SKANER</Name>');
             Memo5.Lines.Add('        <X>0</X>');
             Memo5.Lines.Add('        <Y>0</Y>');
             Memo5.Lines.Add('        <Z>120</Z>'); //length of scanner declared in documentation
             Memo5.Lines.Add('        <C>0</C>');
             Memo5.Lines.Add('        <MagPos></MagPos>'); //for manual loading
             Memo5.Lines.Add('        <Inertie>1</Inertie>');
             Memo5.Lines.Add('        <UnderSize>0</UnderSize>');
             Memo5.Lines.Add('        <CreationDate>'+fd+'</CreationDate>');
             Memo5.Lines.Add('        <ModificationDate>'+fd+'</ModificationDate>');
             Memo5.Lines.Add('        <Radius></Radius>');
             Memo5.Lines.Add('        <ChipID></ChipID>');
             Memo5.Lines.Add('        <SizeInMagasin>1</SizeInMagasin>');
             Memo5.Lines.Add('        <Material></Material>');
             Memo5.Lines.Add('        <ToolDecFamily></ToolDecFamily>');
             for j:=1 to 5 do Memo5.Lines.Add('        <ToolDecCount'+inttostr(j)+'>100</ToolDecCount'+inttostr(j)+'>');
             Memo5.Lines.Add('        <ToolDecWear>0</ToolDecWear>');
             Memo5.Lines.Add('        <UEDMComp>0</UEDMComp>');
             Memo5.Lines.Add('        <UCavComp>0</UCavComp>');
             Memo5.Lines.Add('        <FrontalOffset>0</FrontalOffset>');
             Memo5.Lines.Add('        <ToolDecWearF>0</ToolDecWearF>');
             Memo5.Lines.Add('        <ToolReals>');
             Memo5.Lines.Add('          <ToolReal N="'+inttostr(el_n+999)+'">');
             Memo5.Lines.Add('            <Name></Name>');
             Memo5.Lines.Add('            <X>0</X>');
             Memo5.Lines.Add('            <Y>0</Y>');
             Memo5.Lines.Add('            <Z>0</Z>');
             Memo5.Lines.Add('            <C>0</C>');
             Memo5.Lines.Add('            <MagPos></MagPos>');
             Memo5.Lines.Add('            <UnderSize>0</UnderSize>');
             Memo5.Lines.Add('            <CreationDate>'+fd+'</CreationDate>');
             Memo5.Lines.Add('            <ModificationDate>'+fd+'</ModificationDate>');
             Memo5.Lines.Add('            <Radius></Radius>');
             Memo5.Lines.Add('            <ChipID></ChipID>');
             for j:=1 to 5 do Memo5.Lines.Add('            <ToolDecCount'+inttostr(j)+'>100</ToolDecCount'+inttostr(j)+'>');
             Memo5.Lines.Add('            <initUnderSize>0</initUnderSize>');
             for j:=1 to 5 do Memo5.Lines.Add('            <initToolDecCount'+inttostr(j)+'>-2</initToolDecCount'+inttostr(j)+'>');
             Memo5.Lines.Add('            <Inertie>1</Inertie>');
             Memo5.Lines.Add('            <fragUse>0</fragUse>');
             Memo5.Lines.Add('            <fragSCode>0</fragSCode>');
             Memo5.Lines.Add('            <FrontalOffset>0</FrontalOffset>');
             Memo5.Lines.Add('            <initFrontalOffset>0</initFrontalOffset>');
             Memo5.Lines.Add('            <initTemplateNum>0</initTemplateNum>');
             Memo5.Lines.Add('          </ToolReal>');
             Memo5.Lines.Add('        </ToolReals>');
             Memo5.Lines.Add('      </Tool>');
          end;

          Memo5.Lines.Add('    </Tools>');
          ProgressBar1.Position:=40;
          if vm>=2 then showmessage('Start Shapes');
          Memo5.Lines.Add('    <Shapes>');
          shape_nr:=0;
          max_shapes:=200;
          //new idea - group similar points into one shape
          for i:=0 to max_shapes do begin  //maximum 200 shapes
              shape_names[i]:='-';  //mark all as empty
              shape_points[i]:='-';
          end;

          for i:=0 to ListBox2.Count-1 do begin //for every point on the list
              new_sn:=ListBox2.Items[i]+ListBox6.Items[i]; //create potential new name
              for j:=max_shapes downto 0 do begin
                  if shape_names[j]='-' then ff_sn:=j;  //search for first empty shape
              end;
              found_sn:=False;
              for j:=0 to max_shapes do begin
                  if found_sn=False then begin
                     if shape_names[j]=new_sn then begin  //if name matches to existing one
                        found_sn:=True;
                        shape_points[j]:=shape_points[j]+','+inttostr(i+1); //add current point to existing shape
                     end;
                  end;
              end;
              if found_sn=False then begin
                 shape_names[ff_sn]:=new_sn; //create new shape
                 shape_points[ff_sn]:=inttostr(i+1); //add current point as only point to this shape
              end;
          end;

          if Form10.ShowModal=mrOK then begin //use selected values
                 case Form10.TrackBar1.Position of
                     0: suwak1:='1';
                     1: suwak1:='5';
                     2: suwak1:='2';
                     3: suwak1:='4';
                     4: suwak1:='3';
                 end;
                 case Form10.TrackBar2.Position of
                     0: begin
                         suwak2:='2';
                         //suwak2o:='1';
                     end;
                     1: begin
                         suwak2:='1';
                         //suwak2o:='2';
                     end;
                 end;
          end
          else begin //use default values
                 suwak1:='2';
                 suwak2:='1';
          end;

          for l:=0 to max_shapes do if shape_names[l]<>'-' then begin //for every shape, if it has set name
          sh:=SplitString(',',shape_points[l]);
          rii:=strtoint(sh[0])-1;
             do_this_el:=False;
             for j:=0 to Form2.CheckListBox1.Count-1 do begin
                if (Form2.CheckListBox1.Items[j]=ListBox2.Items[rii]) then begin
                   elv:=SplitString(';',Form2.ListBox1.Items[j]);
                   if elv[0]=ListBox2.Items[rii] then elind:=j; //match current electrode to listbox
                   if Form2.CheckListBox1.Checked[j] then do_this_el:=True;
                end;
             end;
             if do_this_el then begin //if current electrode is checked in the list
                inc(shape_nr);
             Memo5.Lines.Add('      <Shape N="'+inttostr(shape_nr)+'">');
             Memo5.Lines.Add('        <CreationDate>'+fd+'</CreationDate>');
             Memo5.Lines.Add('        <ModificationDate>'+fd+'</ModificationDate>');
             Memo5.Lines.Add('        <Comment>'+shape_names[l]+'</Comment>');  //electrode name + EDM depth
             Memo5.Lines.Add('        <ElectMaterialCode>'+mat_x400_code(elv[1])+'</ElectMaterialCode>');
             Memo5.Lines.Add('        <PieceMaterialCode>1</PieceMaterialCode>'); //steel
             Memo5.Lines.Add('        <PrepElectMaterialSymb>'+mat_x400(elv[1])+'</PrepElectMaterialSymb>');
             Memo5.Lines.Add('        <ElectMaterialSymb>'+mat_x400(elv[1])+'</ElectMaterialSymb>');
             Memo5.Lines.Add('        <PrepPieceMaterialSymb>'+wpmatii_to_hmi(ComboBox4.ItemIndex)+'</PrepPieceMaterialSymb>');
             Memo5.Lines.Add('        <PieceMaterialSymb>'+wpmatii_to_hmi(ComboBox4.ItemIndex)+'</PieceMaterialSymb>');
             Memo5.Lines.Add('        <PrepApplicationType>1</PrepApplicationType>');
             Memo5.Lines.Add('        <ApplicationType>1</ApplicationType>');
             Memo5.Lines.Add('        <PrepSurfaceFinishingCH>'+elv[20][4]+elv[20][5]+'</PrepSurfaceFinishingCH>'); //vdi, number only
             Memo5.Lines.Add('        <SurfaceFinishingCH>'+elv[20][4]+elv[20][5]+'</SurfaceFinishingCH>');
             if ListBox9.Items[rii]='Z' then begin //normal down erosion
                currentEDMDepth:=floattostr(strtofloat(ListBox6.Items[rii])*(-1));
             end
             else begin //side erosion, Depth = undersize per side
                currentEDMDepth:=floattostr(strtofloat(elv[3])/2)
             end;
             Memo5.Lines.Add('        <PrepDepth>'+currentEDMDepth+'</PrepDepth>');
             Memo5.Lines.Add('        <EDMDepth>'+currentEDMDepth+'</EDMDepth>');
             Memo5.Lines.Add('        <AdjDepth>'+currentEDMDepth+'</AdjDepth>');
             Memo5.Lines.Add('        <ToolLength>'+floattostr(1+strtofloat(ListBox6.Items[rii])*(-1))+'</ToolLength>');
             Memo5.Lines.Add('        <PrepToolLength>'+floattostr(1+strtofloat(ListBox6.Items[rii])*(-1))+'</PrepToolLength>');
             //elv[19] - 0= Equimode 3D, 1=Vector (napis), 2=Cylinder, 3=Prostokąt
             if elv[19]='0' then gcyc:='4' //isogap
             else if elv[19]='1' then gcyc:='1' //down
             else if elv[19]='2' then gcyc:='2' //down/orb
             else if elv[19]='3' then gcyc:='2' //also changed in parameters in setting table
             else gcyc:='4';  //isogap is default
             Memo5.Lines.Add('        <PrepGCycle>'+gcyc+'</PrepGCycle>');
             Memo5.Lines.Add('        <GCycle>'+gcyc+'</GCycle>');
             Memo5.Lines.Add('        <PrepCavityStyle>1</PrepCavityStyle>');
             Memo5.Lines.Add('        <CavityStyle>1</CavityStyle>');
             Memo5.Lines.Add('        <PrepCavityAngle>0</PrepCavityAngle>');
             Memo5.Lines.Add('        <CavityAngle>0</CavityAngle>');
             Memo5.Lines.Add('        <PrepMaxArea>'+ListBox8.Items[rii]+'</PrepMaxArea>');
             Memo5.Lines.Add('        <MaxArea>'+ListBox8.Items[rii]+'</MaxArea>');
             Memo5.Lines.Add('        <PreMilledCavity>0</PreMilledCavity>');
             Memo5.Lines.Add('        <LateralExtraThickness>0</LateralExtraThickness>');
             Memo5.Lines.Add('        <FrontalExtraThickness>0</FrontalExtraThickness>');
             Memo5.Lines.Add('        <PrepPulseType></PrepPulseType>');
             Memo5.Lines.Add('        <PulseType></PulseType>');
             if elv[19]='3' then qcode:='2' //all sides square
             else if elv[19]='2' then qcode:='1' //all sides circle
             else qcode:='';
             Memo5.Lines.Add('        <PrepQCode>'+qcode+'</PrepQCode>');
             Memo5.Lines.Add('        <QCode>'+qcode+'</QCode>');
             if xmljVersion='9.0.0' then begin
                 Memo5.Lines.Add('        <ProtectionPieceAttack>1</ProtectionPieceAttack>');
                 Memo5.Lines.Add('        <ProtectionCC>1</ProtectionCC>');
                 Memo5.Lines.Add('        <ProtectionSpacc>1</ProtectionSpacc>');
                 Memo5.Lines.Add('        <ProtectionOnBadMachining>0</ProtectionOnBadMachining>');
             end;
             Memo5.Lines.Add('        <AttackSensitivelessTime>0</AttackSensitivelessTime>');
             Memo5.Lines.Add('        <PrepFlushingM70>A0B0C0D0</PrepFlushingM70>');
             Memo5.Lines.Add('        <FlushingM70>A0B0C0D0</FlushingM70>');
             Memo5.Lines.Add('        <AspirM71></AspirM71>');
             Memo5.Lines.Add('        <PrepSpinSpeed>0</PrepSpinSpeed>');
             Memo5.Lines.Add('        <SpinSpeed></SpinSpeed>');
             Memo5.Lines.Add('        <PrepSpinCode>5</PrepSpinCode>');
             Memo5.Lines.Add('        <SpinCode>5</SpinCode>');
             Memo5.Lines.Add('        <PrepDownTranslationRadius></PrepDownTranslationRadius>');
             Memo5.Lines.Add('        <DownTranslationRadius></DownTranslationRadius>');
             Memo5.Lines.Add('        <PrepHelicFromRefCavity>0</PrepHelicFromRefCavity>');
             Memo5.Lines.Add('        <HelicFromRefCavity>0</HelicFromRefCavity>');
             Memo5.Lines.Add('        <PrepCycleFinishingType></PrepCycleFinishingType>');
             Memo5.Lines.Add('        <CycleFinishingType></CycleFinishingType>');
             Memo5.Lines.Add('        <PrepCycleAngle>0</PrepCycleAngle>');
             Memo5.Lines.Add('        <CycleAngle>0</CycleAngle>');
             Memo5.Lines.Add('        <PrepAngul>0</PrepAngul>');
             Memo5.Lines.Add('        <Angul>0</Angul>');
             Memo5.Lines.Add('        <PrepCycleCornersNb>4</PrepCycleCornersNb>');
             Memo5.Lines.Add('        <CycleCornersNb>4</CycleCornersNb>');
             Memo5.Lines.Add('        <PrepCycleHelicStep>0</PrepCycleHelicStep>');
             Memo5.Lines.Add('        <CycleHelicStep>0</CycleHelicStep>');
             Memo5.Lines.Add('        <TechnoName></TechnoName>');
             if elv[8]<>'0' then aoe:=6
              else if elv[7]<>'0' then aoe:=5
              else if elv[6]<>'0' then aoe:=4
              else if elv[5]<>'0' then aoe:=3
              else if elv[4]<>'0' then aoe:=2
              else aoe:=1;
             //write(xj,'        <JobReportToolList>');
             //write(xj,einf[elind]); //all electrodes in this family
             Memo5.Lines.Add('        <JobReportToolList>'+einf[elind]+'</JobReportToolList>');
             Memo5.Lines.Add('        <JobReportPieceList>'+StringReplace(LabeledEdit1.Text,',','.',[rfReplaceAll])+'</JobReportPieceList>'); //all pieces
             Memo5.Lines.Add('        <JobReportPointList>'+StringReplace(shape_points[l],',','.',[rfReplaceAll])+'</JobReportPointList>'); //points with the same electrode and Z coord.
             //new - either 1 or 2 passes, amount of roughing electrodes depending on total number of electrodes.
             tmpLine:='        <MachiningPassNbr>';
             if aoe=1 then tmpLine:=tmpLine+'1'
             else tmpLine:=tmpLine+'2';  //almost always 2 is used
             tmpLine:=tmpLine+'</MachiningPassNbr>';
             Memo5.Lines.Add(tmpLine);
             Memo5.Lines.Add('        <CalculatedArea>0</CalculatedArea>');
             Memo5.Lines.Add('        <PrepInvPolarity>0</PrepInvPolarity>');
             Memo5.Lines.Add('        <InvPolarity>0</InvPolarity>');
             Memo5.Lines.Add('        <PrepAdditionalRadius></PrepAdditionalRadius>');
             Memo5.Lines.Add('        <AdditionalRadius></AdditionalRadius>');
             Memo5.Lines.Add('        <PrepTrajWithoutCAxis>0</PrepTrajWithoutCAxis>');
             Memo5.Lines.Add('        <TrajWithoutCAxis>0</TrajWithoutCAxis>');
             Memo5.Lines.Add('        <PrepToolRadius>0</PrepToolRadius>');
             Memo5.Lines.Add('        <ToolRadius>0</ToolRadius>');
             Memo5.Lines.Add('        <TrajMode></TrajMode>');
             Memo5.Lines.Add('        <PrepTrajMode></PrepTrajMode>');
             Memo5.Lines.Add('        <PrepContouringRemovalType>0</PrepContouringRemovalType>');
             Memo5.Lines.Add('        <ContouringRemovalType>0</ContouringRemovalType>');
             Memo5.Lines.Add('        <TruncateAngle></TruncateAngle>');
             Memo5.Lines.Add('        <PrepTruncateAngle></PrepTruncateAngle>');
             Memo5.Lines.Add('        <MegaSizeOptimization>0</MegaSizeOptimization>');
             Memo5.Lines.Add('        <EDMGenerationUpToDate>0</EDMGenerationUpToDate>');
             Memo5.Lines.Add('        <PrepAdditionalDistanceX></PrepAdditionalDistanceX>');
             Memo5.Lines.Add('        <AdditionalDistanceX></AdditionalDistanceX>');
             Memo5.Lines.Add('        <PrepAdditionalDistanceY></PrepAdditionalDistanceY>');
             Memo5.Lines.Add('        <AdditionalDistanceY></AdditionalDistanceY>');
             Memo5.Lines.Add('        <PrepApproachPath></PrepApproachPath>');
             Memo5.Lines.Add('        <ApproachPath></ApproachPath>');
             Memo5.Lines.Add('        <PrepDielectricType>0</PrepDielectricType>');
             Memo5.Lines.Add('        <DielectricType>0</DielectricType>');
             Memo5.Lines.Add('        <AdjCycleHelicStep>0</AdjCycleHelicStep>');
             Memo5.Lines.Add('        <NotEmergingHole>0</NotEmergingHole>');
             Memo5.Lines.Add('        <AmorcState>0</AmorcState>');
             Memo5.Lines.Add('        <AmorcTime>0</AmorcTime>');
             Memo5.Lines.Add('        <MultiCyclesCavity>0</MultiCyclesCavity>');
             Memo5.Lines.Add('        <PrepDownTranslationType></PrepDownTranslationType>');
             Memo5.Lines.Add('        <DownTranslationType></DownTranslationType>');
             Memo5.Lines.Add('        <PrepLateralShape>0</PrepLateralShape>');
             Memo5.Lines.Add('        <LateralShape>0</LateralShape>');
             Memo5.Lines.Add('        <PrepLateralShapeHeight></PrepLateralShapeHeight>');
             Memo5.Lines.Add('        <LateralShapeHeight></LateralShapeHeight>');
             Memo5.Lines.Add('        <Circumference>0</Circumference>');
             Memo5.Lines.Add('        <OptimizedSettingRadius>0</OptimizedSettingRadius>');
             Memo5.Lines.Add('        <PrepMultiShape>0</PrepMultiShape>');
             Memo5.Lines.Add('        <MultiShape>0</MultiShape>');
             Memo5.Lines.Add('        <PrepContourXStartPoint>0</PrepContourXStartPoint>');
             Memo5.Lines.Add('        <ContourXStartPoint>0</ContourXStartPoint>');
             Memo5.Lines.Add('        <PrepContourYStartPoint>0</PrepContourYStartPoint>');
             Memo5.Lines.Add('        <ContourYStartPoint>0</ContourYStartPoint>');
             Memo5.Lines.Add('        <PrepContourZStartPoint>0</PrepContourZStartPoint>');
             Memo5.Lines.Add('        <ContourZStartPoint>0</ContourZStartPoint>');
             Memo5.Lines.Add('        <PrepContourCStartPoint>0</PrepContourCStartPoint>');
             Memo5.Lines.Add('        <ContourCStartPoint>0</ContourCStartPoint>');
             Memo5.Lines.Add('        <PrepContourXStopPoint>0</PrepContourXStopPoint>');
             Memo5.Lines.Add('        <ContourXStopPoint>0</ContourXStopPoint>');
             Memo5.Lines.Add('        <PrepContourYStopPoint>0</PrepContourYStopPoint>');
             Memo5.Lines.Add('        <ContourYStopPoint>0</ContourYStopPoint>');
             Memo5.Lines.Add('        <PrepContourZStopPoint>0</PrepContourZStopPoint>');
             Memo5.Lines.Add('        <ContourZStopPoint>0</ContourZStopPoint>');
             Memo5.Lines.Add('        <PrepContourCStopPoint>0</PrepContourCStopPoint>');
             Memo5.Lines.Add('        <ContourCStopPoint>0</ContourCStopPoint>');
             Memo5.Lines.Add('        <PrepContourRightOrLeft>0</PrepContourRightOrLeft>');
             Memo5.Lines.Add('        <ContourRightOrLeft>0</ContourRightOrLeft>');
             Memo5.Lines.Add('        <PrepFlushingPressure>1</PrepFlushingPressure>');
             Memo5.Lines.Add('        <FlushingPressure>1</FlushingPressure>');
             Memo5.Lines.Add('        <PrepHelicUndersizeAdjust>0</PrepHelicUndersizeAdjust>');
             Memo5.Lines.Add('        <HelicUndersizeAdjust>0</HelicUndersizeAdjust>');
             Memo5.Lines.Add('        <PrepHelicThreadAngle></PrepHelicThreadAngle>');
             Memo5.Lines.Add('        <HelicThreadAngle></HelicThreadAngle>');
             Memo5.Lines.Add('        <GeometryType>0</GeometryType>');
             Memo5.Lines.Add('        <GeometrySideA></GeometrySideA>');
             Memo5.Lines.Add('        <GeometrySideB></GeometrySideB>');
             Memo5.Lines.Add('        <GeometryDiameter></GeometryDiameter>');
             Memo5.Lines.Add('        <PrepLEDCavityNb>1</PrepLEDCavityNb>');
             Memo5.Lines.Add('        <LEDCavityNb></LEDCavityNb>');

             suwak2o:='2';
             //drugi suwak
                // w lewo - 2
                // w prawo - 1
             Memo5.Lines.Add('        <PrepCHSpeedPriority>'+suwak2+'</PrepCHSpeedPriority>');
             Memo5.Lines.Add('        <CHSpeedPriority>'+suwak2+'</CHSpeedPriority>');
             //pierwszy suwak     |-----|
                //srodek - 2       ..^..
                //1 w lewo - 5     .^...
                //2 w lewo - 1     ^....
                //1 w prawo        ...^.
                //2 w prawo        ....^
             Memo5.Lines.Add('        <PrepWearSpeedPriority>'+suwak1+'</PrepWearSpeedPriority>');
             Memo5.Lines.Add('        <WearSpeedPriority>'+suwak1+'</WearSpeedPriority>');
             Memo5.Lines.Add('        <PulsBackWithoutVoltage>0</PulsBackWithoutVoltage>');
             Memo5.Lines.Add('        <PrepWhiteLayerPriority>0</PrepWhiteLayerPriority>');
             Memo5.Lines.Add('        <WhiteLayerPriority>0</WhiteLayerPriority>');
             Memo5.Lines.Add('        <CHText></CHText>');
             Memo5.Lines.Add('        <WearPartType>0</WearPartType>');
             Memo5.Lines.Add('        <WearPartSetting>2</WearPartSetting>');
             mdet:=wpmatii_to_hmi(ComboBox4.ItemIndex);
             for j:=1 to 5 do begin  //stupid repeating 5 times the same thing - required
                Memo5.Lines.Add('        <PrepPartMatPass'+inttostr(j)+'>'+mdet+'</PrepPartMatPass'+inttostr(j)+'>');
                Memo5.Lines.Add('        <PartMatPass'+inttostr(j)+'>'+mdet+'</PartMatPass'+inttostr(j)+'>');
                Memo5.Lines.Add('        <PrepToolMatPass'+inttostr(j)+'>'+mat_x400(elv[1])+'</PrepToolMatPass'+inttostr(j)+'>');
                Memo5.Lines.Add('        <ToolMatPass'+inttostr(j)+'>'+mat_x400(elv[1])+'</ToolMatPass'+inttostr(j)+'>');
             end;
             for j:=1 to 5 do begin
                //pierwszy suwak

                Memo5.Lines.Add('        <PrepCHSpeedPriority'+inttostr(j)+'>'+suwak1+'</PrepCHSpeedPriority'+inttostr(j)+'>');
                Memo5.Lines.Add('        <CHSpeedPriority'+inttostr(j)+'>'+suwak1+'</CHSpeedPriority'+inttostr(j)+'>');
                Memo5.Lines.Add('        <PrepLastSettingPriority'+inttostr(j)+'>'+suwak1+'</PrepLastSettingPriority'+inttostr(j)+'>');
                Memo5.Lines.Add('        <LastSettingPriority'+inttostr(j)+'>'+suwak1+'</LastSettingPriority'+inttostr(j)+'>');
             end;
             for j:=1 to 5 do Memo5.Lines.Add('        <LSB'+inttostr(j)+'></LSB'+inttostr(j)+'>');
             for j:=1 to 5 do Memo5.Lines.Add('        <FSB'+inttostr(j)+'></FSB'+inttostr(j)+'>');
             Memo5.Lines.Add('        <PrepLimitStartPower>0</PrepLimitStartPower>');
             Memo5.Lines.Add('        <LimitStartPower>0</LimitStartPower>');
             for j:=1 to 5 do Memo5.Lines.Add('        <PrepLSB'+inttostr(j)+'></PrepLSB'+inttostr(j)+'>');
             for j:=1 to 5 do Memo5.Lines.Add('        <PrepFSB'+inttostr(j)+'></PrepFSB'+inttostr(j)+'>');
             for j:=1 to 5 do begin
                Memo5.Lines.Add('        <PrepAutoMachPass'+inttostr(j)+'>1</PrepAutoMachPass'+inttostr(j)+'>');
                Memo5.Lines.Add('        <AutoMachPass'+inttostr(j)+'>1</AutoMachPass'+inttostr(j)+'>');
             end;
             Memo5.Lines.Add('        <MachPassFromTecformStep2>0</MachPassFromTecformStep2>');
             Memo5.Lines.Add('        <specificpassModified>0</specificpassModified>');
             for j:=1 to 5 do Memo5.Lines.Add('        <TechnoNamePass'+inttostr(j)+'></TechnoNamePass'+inttostr(j)+'>');
             Memo5.Lines.Add('        <PreporbExeMode>0</PreporbExeMode>');
             Memo5.Lines.Add('        <orbExeMode>0</orbExeMode>');
             Memo5.Lines.Add('        <PrepHeaderLimitStartPower>0</PrepHeaderLimitStartPower>');
             Memo5.Lines.Add('        <HeaderLimitStartPower>0</HeaderLimitStartPower>');

             Memo5.Lines.Add('        <PrepHeaderPriority>'+suwak2o+'</PrepHeaderPriority>');
             Memo5.Lines.Add('        <HeaderPriority>'+suwak2o+'</HeaderPriority>');
             Memo5.Lines.Add('        <PrepHeaderAuto>1</PrepHeaderAuto>');
             Memo5.Lines.Add('        <HeaderAuto>1</HeaderAuto>');
             Memo5.Lines.Add('        <PrepHLS></PrepHLS>');
             Memo5.Lines.Add('        <HLS></HLS>');
             Memo5.Lines.Add('        <PrepPreMilledAuto>1</PrepPreMilledAuto>');
             Memo5.Lines.Add('        <PreMilledAuto>1</PreMilledAuto>');
             Memo5.Lines.Add('        <PrepPreMilledHeaderSecurity></PrepPreMilledHeaderSecurity>');
             Memo5.Lines.Add('        <PreMilledHeaderSecurity></PreMilledHeaderSecurity>');
             Memo5.Lines.Add('        <PrepPreMilledHeaderPriority>'+suwak2o+'</PrepPreMilledHeaderPriority>');
             Memo5.Lines.Add('        <PreMilledHeaderPriority>'+suwak2o+'</PreMilledHeaderPriority>');
             Memo5.Lines.Add('        <PreMilledRadius>0</PreMilledRadius>');
             Memo5.Lines.Add('        <PrepTexturing>0</PrepTexturing>');
             Memo5.Lines.Add('        <Texturing></Texturing>');
             Memo5.Lines.Add('        <PrepNoMachiningInTime>0</PrepNoMachiningInTime>');
             Memo5.Lines.Add('        <NoMachiningInTime>0</NoMachiningInTime>');
             Memo5.Lines.Add('        <PrioritiesForDescJob></PrioritiesForDescJob>');
             Memo5.Lines.Add('        <PrepTomeo>0</PrepTomeo>');
             Memo5.Lines.Add('        <Tomeo>0</Tomeo>');
             Memo5.Lines.Add('        <PrepEstimatedWearLength>0</PrepEstimatedWearLength>');
             Memo5.Lines.Add('        <EstimatedWearLength>0</EstimatedWearLength>');
             Memo5.Lines.Add('        <SurfaceEvolution><SurfaceEvolution></SurfaceEvolution></SurfaceEvolution>');
             Memo5.Lines.Add('        <PrepSetRetOrigin></PrepSetRetOrigin>');
             Memo5.Lines.Add('        <SetRetOrigin></SetRetOrigin>');
             Memo5.Lines.Add('        <ShapePieces>');
             for j:=0 to length(pieces)-1 do begin
                Memo5.Lines.Add('          <ShapePiece PN="'+inttostr(j+1)+'">');
                Memo5.Lines.Add('            <CreationDate>'+fd+'</CreationDate>');
                Memo5.Lines.Add('            <ModificationDate>'+fd+'</ModificationDate>');
                Memo5.Lines.Add('          </ShapePiece>');
             end;
             Memo5.Lines.Add('        </ShapePieces>');
             Memo5.Lines.Add('        <ShapePoints>');
             for j:=0 to length(sh)-1 do begin
                 Memo5.Lines.Add('          <ShapePoint PN="'+sh[j]+'">');
                 Memo5.Lines.Add('            <CreationDate>'+fd+'</CreationDate>');
                 Memo5.Lines.Add('            <ModificationDate>'+fd+'</ModificationDate>');
                 Memo5.Lines.Add('          </ShapePoint>');
             end;
             Memo5.Lines.Add('        </ShapePoints>');
             Memo5.Lines.Add('        <ShapeTools>');
             for j:=0 to Form2.CheckListBox1.Count-1 do begin
                 if elv[0]=Form2.CheckListBox1.Items[j] then tl:=SplitString(',',einf2[j]);
             end;
             for j:=0 to length(tl)-1 do begin
                Memo5.Lines.Add('          <ShapeTool TN="'+tl[j]+'">');
                Memo5.Lines.Add('            <CreationDate>'+fd+'</CreationDate>');
                Memo5.Lines.Add('            <ModificationDate>'+fd+'</ModificationDate>');
                Memo5.Lines.Add('          </ShapeTool>');
             end;
             Memo5.Lines.Add('        </ShapeTools>');
             Memo5.Lines.Add('        <SettingTables>');

             //find out how many different undersize types there are for current electrode id
             ums:=0;
             feum:=False;
             for j:=1 to 10 do distinct_um[j]:='_';
             //first_empty_um=1;
             for j:=1 to aoe do begin
                 new_um:=True;
                 for k:=1 to 10 do begin
                     if distinct_um[k]=elv[(2+j)] then new_um:=False;
                 end;
                 if new_um then begin
                     distinct_um[(ums+1)]:=elv[(2+j)];
                     inc(ums);
                 end;
             end;

             if aoe=1 then passnbr:=1
             else passnbr:=2;
             for j:=1 to passnbr do begin
                Memo5.Lines.Add('          <SettingTable FT="'+inttostr(j)+'">');
                Memo5.Lines.Add('            <CreationDate>'+fd+'</CreationDate>');
                Memo5.Lines.Add('            <ModificationDate>'+fd+'</ModificationDate>');
                Memo5.Lines.Add('            <CodeS>0</CodeS>');
                if ums=1 then begin //if only 1 undersize type, then use first for all passes
                   Memo5.Lines.Add('            <PrepUnderSize>'+floattostr(strtofloat(distinct_um[1])/2)+'</PrepUnderSize>');
                   Memo5.Lines.Add('            <UnderSize>'+floattostr(strtofloat(distinct_um[1])/2)+'</UnderSize>');
                end
                else begin  //different undersize types - use as many as there are passes (2)
                     Memo5.Lines.Add('            <PrepUnderSize>'+floattostr(strtofloat(distinct_um[j])/2)+'</PrepUnderSize>');
                     Memo5.Lines.Add('            <UnderSize>'+floattostr(strtofloat(distinct_um[j])/2)+'</UnderSize>');
                end;
                Memo5.Lines.Add('            <HCorrection></HCorrection>');
                Memo5.Lines.Add('            <WCorrection></WCorrection>');
                Memo5.Lines.Add('            <EStart>0</EStart>');
                Memo5.Lines.Add('            <EEnd>0</EEnd>');
                Memo5.Lines.Add('            <PrepToolLength>'+inttostr(floor((strtofloat(ListBox6.Items[rii])*(-1)))+1)+'</PrepToolLength>');
                Memo5.Lines.Add('            <ToolLength>'+inttostr(floor((strtofloat(ListBox6.Items[rii])*(-1)))+1)+'</ToolLength>');
                if ((j=2) and (elv[19]='3')) then isogapstep:=ust.ReadString('settings','isogap_i2','4')
                else isogapstep:=ust.ReadString('settings','isogap_i1','3');
                Memo5.Lines.Add('            <ISOGAPStrategy>'+isogapstep+'</ISOGAPStrategy>');
                Memo5.Lines.Add('            <PrepISOGAPStrategy>'+isogapstep+'</PrepISOGAPStrategy>');
                Memo5.Lines.Add('            <ISOGAPStep>'+isogapstep+'</ISOGAPStep>');
                Memo5.Lines.Add('            <PrepISOGAPStep>'+isogapstep+'</PrepISOGAPStep>');
                tmpLine:='            <ISOGAPPendul>';
                if ((j=2) and (elv[19]='0')) then tmpLine:=tmpLine+'4'; //only for finishing electrode, when Equimode selected
                tmpLine:=tmpLine+'</ISOGAPPendul>';
                Memo5.Lines.Add(tmpLine);
                tmpLine:='            <PrepISOGAPPendul>';
                if ((j=2) and (elv[19]='0')) then tmpLine:=tmpLine+'4'; //only for finishing electrode, when Equimode selected
                tmpLine:=tmpLine+'</PrepISOGAPPendul>';
                Memo5.Lines.Add(tmpLine);
                Memo5.Lines.Add('            <WearPartType>0</WearPartType>');
                Memo5.Lines.Add('            <WearPartSetting>2</WearPartSetting>');
                Memo5.Lines.Add('          </SettingTable>');
             end;
             Memo5.Lines.Add('        </SettingTables>');
             Memo5.Lines.Add('        <FuturaSettings>');
             Memo5.Lines.Add('          <FuturaMemo>AE6A0D</FuturaMemo>');
             Memo5.Lines.Add('          <CreationDate>'+fd+'</CreationDate>');
             Memo5.Lines.Add('          <ModificationDate>'+fd+'</ModificationDate>');
             Memo5.Lines.Add('          <FuturaMemoRef>2D640A</FuturaMemoRef>');
             Memo5.Lines.Add('          <Estimation></Estimation>');
             Memo5.Lines.Add('        </FuturaSettings>');
             if xmljVersion='9.3.1' then begin
                 Memo5.Lines.Add('        <ExtendShape>');
                 Memo5.Lines.Add('            <CreationDate>'+fd+'</CreationDate>');
                 Memo5.Lines.Add('            <ModificationDate>'+fd+'</ModificationDate>');
                 Memo5.Lines.Add('            <SteppedToolNum>1</SteppedToolNum>');
                 Memo5.Lines.Add('            <execSteppedToolNum>1</execSteppedToolNum>');
                 Memo5.Lines.Add('            <PrepSteppedToolXml><slices><slice n="1"><type>1</type><height>'+currentEDMDepth+'</height><shapetype>0</shapetype><surface>'+ListBox8.Items[rii]+'</surface><pattern>1</pattern></slice></slices></PrepSteppedToolXml>');
                 Memo5.Lines.Add('            <SteppedToolXml><slices><slice n="1"><type>1</type><height>'+currentEDMDepth+'</height><shapetype>0</shapetype><surface>'+ListBox8.Items[rii]+'</surface><pattern>1</pattern></slice></slices></SteppedToolXml>');
                 for j:=2 to 5 do begin
                    Memo5.Lines.Add('            <PrepHeaderPriority'+inttostr(j)+'>2</PrepHeaderPriority'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <HeaderPriority'+inttostr(j)+'>2</HeaderPriority'+inttostr(j)+'>');
                 end;
                 for j:=2 to 5 do begin
                    Memo5.Lines.Add('            <PrepHLS'+inttostr(j)+'></PrepHLS'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <HLS'+inttostr(j)+'></HLS'+inttostr(j)+'>');
                 end;
                 for j:=2 to 5 do begin
                    Memo5.Lines.Add('            <PrepHeaderAuto'+inttostr(j)+'>1</PrepHeaderAuto'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <HeaderAuto'+inttostr(j)+'>1</HeaderAuto'+inttostr(j)+'>');
                 end;
                 for j:=2 to 5 do begin
                    Memo5.Lines.Add('            <PrepKeepSurfaceEvol'+inttostr(j)+'>0</PrepKeepSurfaceEvol'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <KeepSurfaceEvol'+inttostr(j)+'>0</KeepSurfaceEvol'+inttostr(j)+'>');
                 end;
                 for j:=1 to 5 do begin
                    Memo5.Lines.Add('            <PrepApplicationTypePass'+inttostr(j)+'>1</PrepApplicationTypePass'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <ApplicationTypePass'+inttostr(j)+'>1</ApplicationTypePass'+inttostr(j)+'>');
                 end;
                 for j:=1 to 5 do begin
                    Memo5.Lines.Add('            <PrepAutoSettingsAmount'+inttostr(j)+'>1</PrepAutoSettingsAmount'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <AutoSettingsAmount'+inttostr(j)+'>1</AutoSettingsAmount'+inttostr(j)+'>');
                 end;
                 for j:=1 to 5 do begin
                    Memo5.Lines.Add('            <PrepAutoFinalCurrent'+inttostr(j)+'>1</PrepAutoFinalCurrent'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <AutoFinalCurrent'+inttostr(j)+'>1</AutoFinalCurrent'+inttostr(j)+'>');
                 end;
                 for j:=1 to 5 do begin
                    Memo5.Lines.Add('            <PrepAutoFinalVDI'+inttostr(j)+'>1</PrepAutoFinalVDI'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <AutoFinalVDI'+inttostr(j)+'>1</AutoFinalVDI'+inttostr(j)+'>');
                 end;
                 for j:=1 to 5 do begin
                    Memo5.Lines.Add('            <PrepSettingsAmount'+inttostr(j)+'>40|5</PrepSettingsAmount'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <SettingsAmount'+inttostr(j)+'>40|5</SettingsAmount'+inttostr(j)+'>');
                 end;
                 for j:=1 to 5 do begin
                    Memo5.Lines.Add('            <PrepFinalCurrent'+inttostr(j)+'></PrepFinalCurrent'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <FinalCurrent'+inttostr(j)+'></FinalCurrent'+inttostr(j)+'>');
                 end;
                 for j:=1 to 5 do begin
                    Memo5.Lines.Add('            <PrepFinalVDI'+inttostr(j)+'></PrepFinalVDI'+inttostr(j)+'>');
                    Memo5.Lines.Add('            <FinalVDI'+inttostr(j)+'></FinalVDI'+inttostr(j)+'>');
                 end;
                 Memo5.Lines.Add('            <OpenCavity>1</OpenCavity>');
                 Memo5.Lines.Add('            <PrepOpenCavity>1</PrepOpenCavity>');
                 Memo5.Lines.Add('        </ExtendShape>');
             end;
             Memo5.Lines.Add('      </Shape>');
             end;
          //end;
          end; //shape_names if
          Memo5.Lines.Add('    </Shapes>');
          ProgressBar1.Position:=50;
          Memo5.Lines.Add('    <Related_Files>');
          Memo5.Lines.Add('      <Related_File Name="O0001.iso">');
          Memo5.Lines.Add('        <Line N="1">O0001 ('+Edit3.Text+')</Line>');
          Memo5.Lines.Add('        <Line N="2"></Line>');
          Memo5.Lines.Add('        <Line N="3"></Line>');
          Memo5.Lines.Add('        <Line N="4">M30</Line>');
          Memo5.Lines.Add('        <Line N="5"></Line>');
          Memo5.Lines.Add('      </Related_File>');
          Memo5.Lines.Add('    </Related_Files>');
          Memo5.Lines.Add('    <Machining_Reports>');
          Memo5.Lines.Add('    </Machining_Reports>');
          Memo5.Lines.Add('  </Job>');
          Memo5.Lines.Add('</Jobs>');
          //CloseFile(xj);
          if vm>=2 then showmessage('Finished. Now saving...');
          Memo5.Lines.SaveToFile(SaveDialog3.FileName);
          ProgressBar1.Position:=60;
          logToFile(Application.Location,'OK Saved program for X400 ('+SaveDialog3.FileName+')');
          if vm>=1 then Showmessage('Program '+Edit3.Text+'.xmlj zapisany');
          //SysUtils.ExecuteProcess('explorer.exe','/select,'+SaveDialog3.FileName);
        ust.Free;
  end
  else if vm>=1 then ShowMessage('Uzupełnij dane elektrod.');
end;

procedure TForm1.Button11Click(Sender: TObject);
begin

end;

procedure TForm1.Button13Click(Sender: TObject);

begin
  MessageDlg('Zmiana kierunku drążenia','Przy wysyłaniu zlecenia do Certy, działa tylko po kliknięciu ikony "Certa Fix"',mtInformation,[mbOk],0,mbOk);
end;

procedure TForm1.Button14Click(Sender: TObject); //old wyslij
var rnumber,rname,str,dir,strat,gnam,z_in_mach,mach_add,z_in_geo,geo_add,geo_add2,iname,iusing,sp_coords,sp_coordsa,drbok,mtd,only_ret,only_vector,pozp,ksp,pline,elmname,phase2,eip2,elno,multi_tf,umode,le,f00f,f00_sk,fold,nap,strange_number,littledot,elnamem,tmpstr,value,lsus,newlin,um_message:string;
pval,eval,pval2,tf_val,pe_val,lb1,prefil,p_elval,p_elam,isoval,chck,fmel,elv,memv,elv2,zfix:TArrayOfString;
  min_z,i,j,f2i,f2j,k,ii,using_nr,amount_of_el,f2amount_of_el,kapiel,last_using,bea_nr,check_preset,check_user,jjj,aoe,cvdi9,elnon,lino,wpcount,piece_count,elcount,elcount_pr,celc,ae,ad,aoett,distinct_us,ij:integer;
  job,jor,tek,ter,iso,isr,fut,fur,f0r,f00,j00:TextFile;
  ust:TIniFile;
  phase,eip:Array[1..4] of integer;
  disc_us:Array of integer;
  el_am:Array of real;
  ar_strat:Array of string;
  do_this_el,exists_in_list,line_changed,preset_ok:boolean;
  oldx,oldy,oldc,newx,oldz,newy,el_h_diff,el_um_diff:real;
  l:TArrayOfString;
begin
 ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
 strat:=ust.ReadString('settings','electrodeStrategy','1');
 fold:=ust.ReadString('settings','createFolder','1');
 nap:=ust.ReadString('settings','naPen','0');
 if fold='1' then begin
    if nap='1' then dir:=extractfiledir(OpenDialog3.FileName)+'\'+Form1.Edit3.Text
    else dir:=ust.ReadString('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output')+'\'+Form1.Edit3.Text;
 end
 else begin
      if nap='1' then dir:=extractfiledir(OpenDialog3.FileName)
      else dir:=ust.ReadString('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output');
 end;
 um_message:='Znalezione problemy:';
 ListBox10.Clear;
 Form12.Memo1.Clear;
 Form2.ListBox2.Clear;
    ProgressBar1.Position:=(Form2.CheckListBox1.Count-1)*10;
   if Form2.Label13.Caption='done' then begin // save FUT then JOB
      preset_ok:=False;
      if Form2.Edit16.Enabled then begin
      logToFile(Application.Location,'INF using Z values typed by hand!');
         //create fake .mes file with only Z values from Form2
         //AssignFile(fakemes,Application.Location+'fmes.mes');
         //rewrite(fakemes);
         Memo3.Clear;
         //for i:=0 to Form2.ListBox1.Count-1 do begin
         //
         //
         //end;
         for i:=0 to Form2.ListBox1.Count-1 do begin
             fmel:=SplitString(';',Form2.ListBox1.Items[i]);
             if ((fmel[3]<>fmel[4]) and (fmel[4]<>'0')) then begin
                el_h_diff:=abs(strtofloat(fmel[22])-strtofloat(fmel[23]));
                el_um_diff:=abs(strtofloat(fmel[3])-strtofloat(fmel[4]))/2;
                //showmessage('el_h_diff: '+floattostr(el_h_diff)+AnsiString(#13#10)+'el_um_diff: '+floattostr(el_um_diff));

                if ((el_h_diff>(el_um_diff + strtofloat(ust.ReadString('settings','elCheckZdiff','0.03')))) or (el_h_diff<(el_um_diff - strtofloat(ust.ReadString('settings','elCheckZdiff','0.03'))))) then begin
                   showmessage('Uwaga!'+AnsiString(#13#10)+'Elektroda '+fmel[0]+AnsiString(#13#10)+
                   'UM '+fmel[3]+', Z: '+fmel[22]+AnsiString(#13#10)+
                   'UM '+fmel[4]+', Z: '+fmel[23]);
                end;

             end;
             if length(fmel[22])>0 then begin
             Memo3.Lines.Add(fmel[15]+';R1,U,,0,,,,,,,0,0,'+fmel[22]+',0.000,0.000,0,0,0,0,,0.000,,,,,,');
             //writeln(fakemes,fmel[0]+';R1,U,,0,,,,,,,0,0,'+fmel[22]+',0.000,0.000,0,0,0,0,,0.000,,,,,,');
             for j:=0 to 4 do if fmel[(4+j)]<>'0' then begin
                //if ((fmel[16]='1') and (((2+j) mod 2)=0)) then begin
                //writeln(fakemes,fmel[0]+';R'+inttostr(2+j)+',U,,0,,,,,,,0,0,'+fmel[(23+j)]+',0.000,0.000,180,0,0,0,,0.000,,,,,,'); //multi electrode
                //Memo3.Lines.Add(fmel[0]+';R'+inttostr(2+j)+',U,,0,,,,,,,0,0,'+fmel[(23+j)]+',0.000,0.000,180,0,0,0,,0.000,,,,,,');
                //end
                //else begin
                    Memo3.Lines.Add(fmel[15]+';R'+inttostr(2+j)+',U,,0,,,,,,,0,0,'+fmel[(23+j)]+',0.000,0.000,0,0,0,0,,0.000,,,,,,');
                    //writeln(fakemes,fmel[0]+';R'+inttostr(2+j)+',U,,0,,,,,,,0,0,'+fmel[(23+j)]+',0.000,0.000,0,0,0,0,,0.000,,,,,,'); //non multi electrode
                //end;
             end;
             end;
         end;
         //CloseFile(fakemes);
         OpenDialog3.FileName:=Application.Location+'fmes.mes'; //actually use generated file.
         preset_ok:=True;
      end
      else if OpenDialog3.Execute then begin //real .mes from preset
         preset_ok:=True;
      end;
      if preset_ok then begin //any valid .mes file
           if ExtractFileExt(OpenDialog3.FileName)='.CMD' then begin
                 logToFile(Application.Location,'INF Loaded .CMD file from Zeiss CMM. Calculating rotation');
                 Memo2.Lines.LoadFromFile(OpenDialog3.FileName);
                 wpcount:=0; //global workpiece count in .cmd
                 for i:=0 to Memo2.Lines.Count-1 do begin
                     if AnsiContainsStr(Memo2.Lines[i],'M') then inc(wpcount);
                 end;
                 elcount:=0; //global electrode count in cmd
                 elcount_pr:=0;
                 SetLength(el_am,Form2.ListBox1.Items.Count);
                 // generate table with electrode amounts
                 for i:=0 to Form2.ListBox1.Items.Count-1 do begin

                     elv2:=SplitString(';',Form2.ListBox1.Items[i]);
                     //showmessage(elv2[0]);
                     el_am[(i+1)]:=0;    // it was el_am[(i+1)] before. WHY +1 ?
                     if strtoint(elv2[9])<>0 then el_am[(i+1)]:=el_am[(i+1)]+1;
                     if strtoint(elv2[10])<>0 then el_am[(i+1)]:=el_am[(i+1)]+1;
                     if strtoint(elv2[11])<>0 then el_am[(i+1)]:=el_am[(i+1)]+1;
                     if strtoint(elv2[12])<>0 then el_am[(i+1)]:=el_am[(i+1)]+1;
                     if strtoint(elv2[13])<>0 then el_am[(i+1)]:=el_am[(i+1)]+1;
                     if strtoint(elv2[14])<>0 then el_am[(i+1)]:=el_am[(i+1)]+1;
                     //showmessage('el_am value ['+inttostr(i)+']: '+floattostr(el_am[i]));
                     //elcount_pr:=elcount_pr+inttostr(el_am[i]);

                 end;
                 // count electrodes in cmd file
                 for i:=1 to length(el_am) do elcount_pr:=elcount_pr+floor(el_am[i]);
                 //showmessage('sum: '+inttostr(elcount_pr));
                 for i:=0 to Memo2.Lines.Count-1 do begin
                     if AnsiContainsStr(Memo2.Lines[i],'T') then inc(elcount);
                 end;

                 if elcount=elcount_pr then begin
                     showmessage('ok '+inttostr(elcount));
                 end
                 else if elcount=(elcount_pr+length(el_am)) then begin //first of every electrode needs deleting
                 //showmessage('electrodes need deleting');
                 celc:=0;
                     ae:=1; //current electrode
                     ad:=0;
                     for i:=0 to Memo2.Lines.Count-1 do begin
                         if AnsiContainsStr(Memo2.Lines[i],'T') then begin
                            inc(celc);
                            if celc=(ad+1) then Memo2.Lines[i]:='';
                            if celc=(ad+(el_am[ae]+1)) then begin
                               ad:=ad+1+Math.floor(el_am[ae]);
                               inc(ae);

                            end;
                         end;
                     end;
                 end
                 else if elcount<>sum(el_am) then begin
                     logToFile(Application.Location,'ERR wrong electrode number in cmd file');
                     showmessage('Niezgodnosc ilosci elektrod w pliku .cmd'+AnsiString(#13#10)+'elcount: '+inttostr(elcount)+AnsiString(#13#10)+'sum(el_am):'+floattostr(sum(el_am)));
                 end;
                 Memo3.Clear;
                 elnon:=0;
                 lino:=0;
                 wpcount:=0;
                 for i:=0 to Memo2.Lines.Count-1 do begin
                  if length(Memo2.Lines[i])>3 then begin
                    if Memo2.Lines[i][1]='M' then begin
                         inc(wpcount);
                         memv:=SplitString(',',Memo2.Lines[i]);
                         tmpstr:=memv[1];
                         delete(tmpstr,1,1);
                         oldx:=strtofloat(tmpstr);
                         tmpstr:=memv[2];
                         delete(tmpstr,1,1);
                         oldy:=strtofloat(tmpstr);
                         tmpstr:=memv[4];
                         delete(tmpstr,1,1);
                         oldc:=strtofloat(tmpstr);
                         tmpstr:=memv[3];
                         delete(tmpstr,1,1);
                         oldz:=strtofloat(tmpstr);
                         if oldx=0 then oldx:=0.0001;
                         if oldy=0 then oldy:=0.0001;
                         newx:=roundto((oldx*cos(degtorad(-oldc)))-(oldy*sin(degtorad(-oldc))),4);
                         newy:=roundto((oldx*sin(degtorad(-oldc)))+(oldy*cos(degtorad(-oldc))),4);
                         newlin:=Edit3.Text;
                         //write(fakemes,Edit3.Text);
                         //if wpcount<>1 then write(fakemes,':'+inttostr(wpcount-1));
                         if wpcount<>1 then newlin:=newlin+':'+inttostr(wpcount-1);
                         newlin:=newlin+',W,,,,,,,,,'+floattostr(newx)+','+floattostr(newy)+','+floattostr(oldz)+',0.000,0.000,'+floattostr(oldc)+',,,,,,,,,';
                         //writeln(fakemes,',W,,,,,,,,,'+floattostr(newx)+','+floattostr(newy)+','+floattostr(oldz)+',0.000,0.000,'+floattostr(oldc)+',,,,,,,,,');
                         Memo3.Lines.Add(newlin);
                    end;
                    if Memo2.Lines[i][1]='T' then begin
                        elv:=SplitString(';',Form2.ListBox1.Items[lino]);
                        //showmessage(elv[(4+elnon)]);
                        if elv[(3+elnon)]<>'0' then begin
                           elnamem:=elv[0];
                           inc(elnon);
                        end
                        else begin
                           //showmessage('ok1');
                           elnon:=0;
                           inc(lino);
                           //showmessage(elv[0]);
                           if lino<Form2.ListBox1.Count then begin
                              elv:=SplitString(';',Form2.ListBox1.Items[lino]);
                              elnamem:=elv[0];
                              inc(elnon);
                           end;
                        end;

                        memv:=SplitString(',',Memo2.Lines[i]);
                        //showmessage('ok 1');
                         tmpstr:=memv[1];
                         delete(tmpstr,1,1);
                         oldx:=strtofloat(tmpstr);
                         tmpstr:=memv[2];
                         delete(tmpstr,1,1);
                         oldy:=strtofloat(tmpstr);
                         tmpstr:=memv[4];
                         delete(tmpstr,1,1);
                         oldc:=strtofloat(tmpstr);
                         tmpstr:=memv[3];
                         delete(tmpstr,1,1);
                         zfix:=SplitString('.',tmpstr);   // 20211012 fix for issue with invisible unciode character in files from Zeiss CMM
                         oldz:=strtofloat(zfix[0]+'.'+zfix[1][1]+zfix[1][2]+zfix[1][3]); // 20211012 fix for issue with invisible unciode character in files from Zeiss CMM

                         if oldx=0 then oldx:=0.0001; //zero causes unecpected behavior (very large numbers)
                         if oldy=0 then oldy:=0.0001; //hence this insignificant number is placed here instead of 0
                         newx:=roundto((oldx*cos(degtorad(-oldc)))-(oldy*sin(degtorad(-oldc))),4);
                         newy:=roundto((oldx*sin(degtorad(-oldc)))+(oldy*cos(degtorad(-oldc))),4);
                         Memo3.Lines.Add(elnamem+';R'+inttostr(elnon)+',U,,0,,,,,,,'+floattostr(newx)+','+floattostr(newy)+','+floattostr(oldz)+',0.000,0.000,'+floattostr(oldc)+',0,0,0,,0.000,,,,,,');
                    end;
                    end;
                 end;
                 //showmessage('converting .cmd to .mes done');
           end; //if .CMD file
           check_preset:=0;
           check_user:=0;

           ij:=0;
           Memo4.Clear;
           //repeat
           //showmessage('Memo3.Lines.Count: '+inttostr(Memo3.Lines.Count)+AnsiString(#13#10)+'Form2.ListBox1.Count: '+inttostr(Form2.ListBox1.Count));
           forcedirectories(dir);
           for ij:=0 to Memo3.Lines.Count-1 do begin
                //readln(preset,pline);
               //showmessage(inttostr(ij)+': '+Memo3.Lines[ij]);
                if length(Memo3.Lines[ij])>2 then begin //to prevent errors with 2 empty lines at end
                   prefil:=SplitString(',',Memo3.Lines[ij]);
                   //showmessage(prefil[0]);
                   pval2:=SplitString(';',prefil[0]);
                   line_changed:=False;
                   //showmessage('ok2.5 pvval2[1]: '+pval2[1]);
                   for f2i:=0 to Form2.ListBox1.Count-1 do begin //add multi electrodes to mes file
                    lb1:=SplitString(';',Form2.ListBox1.Items[f2i]);
                    //showmessage(lb1[0]+' '+lb1[22]+' '+inttostr(length(lb1[22])));
                    if (((lb1[15]=pval2[0]) and (lb1[16]='1')) and (length(lb1[22])=0)) then begin  //if is multi electrode and real name matched, ano not fakemes, as it generates multi electrodes already
                      // showmessage('multi '+pval2[0]);
                        line_changed:=True;
                        if pval2[1]='R1' then begin
                           Memo4.Lines.Add(Memo3.Lines[ij]);
                           Memo4.Lines.Add(pval2[0]+';R2,U,,0,,,,,,,'+floattostr(strtofloat(prefil[10])*(-1))+','+floattostr(strtofloat(prefil[11])*(-1))+','+prefil[12]+',0.000,0.000,'+floattostr(strtofloat(prefil[15])+180)+',0,0,0,,0.000,,,,,,');
                        end;
                        if pval2[1]='R2' then begin
                           Memo4.Lines.Add(pval2[0]+';R3,U,,0,,,,,,,'+prefil[10]+','+prefil[11]+','+prefil[12]+',0.000,0.000,'+prefil[15]+',0,0,0,,0.000,,,,,,');
                           Memo4.Lines.Add(pval2[0]+';R4,U,,0,,,,,,,'+floattostr(strtofloat(prefil[10])*(-1))+','+floattostr(strtofloat(prefil[11])*(-1))+','+prefil[12]+',0.000,0.000,'+floattostr(strtofloat(prefil[15])+180)+',0,0,0,,0.000,,,,,,');
                        end;
                        if pval2[1]='R3' then begin
                           Memo4.Lines.Add(pval2[0]+';R5,U,,0,,,,,,,'+prefil[10]+','+prefil[11]+','+prefil[12]+',0.000,0.000,'+prefil[15]+',0,0,0,,0.000,,,,,,');
                           Memo4.Lines.Add(pval2[0]+';R6,U,,0,,,,,,,'+floattostr(strtofloat(prefil[10])*(-1))+','+floattostr(strtofloat(prefil[11])*(-1))+','+prefil[12]+',0.000,0.000,'+floattostr(strtofloat(prefil[15])+180)+',0,0,0,,0.000,,,,,,');
                        end;
                        if pval2[1]='R4' then begin
                          Memo4.Lines.Add(pval2[0]+';R7,U,,0,,,,,,,'+prefil[10]+','+prefil[11]+','+prefil[12]+',0.000,0.000,'+prefil[15]+',0,0,0,,0.000,,,,,,');
                          Memo4.Lines.Add(pval2[0]+';R8,U,,0,,,,,,,'+floattostr(strtofloat(prefil[10])*(-1))+','+floattostr(strtofloat(prefil[11])*(-1))+','+prefil[12]+',0.000,0.000,'+floattostr(strtofloat(prefil[15])+180)+',0,0,0,,0.000,,,,,,');

                        end;
                    end;
                   end;
                   //if not line_changed then writeln(tempp,pline); //save line without changes
                   if not line_changed then begin
                     //showmessage('not line_changed '+pval2[0]);
                     Memo4.Lines.Add(Memo3.Lines[ij]);
                   end;

                end;
           //until eof(preset);
           end;
           //showmessage('converting mes for possible multielectrodes done.');
           //Application.Terminate;
           Memo4.Lines.SaveToFile(dir+'\'+Edit3.Text+'.mes');
           for ij:=0 to Memo4.Lines.Count-1 do begin
           //repeat
              //readln(preset,pline); //read mes file
              inc(check_preset);
              pval:=SplitString(',',Memo4.Lines[ij]);
              //if pval[1]='U' then begin
              for ii:=0 to (Form2.ListBox1.Count-1) do begin  //fill Form2.ListBox2 with real electrode data
                  eval:=SplitString(';',Form2.ListBox1.Items[ii]);
                  pval2:=SplitString(';',pval[0]);
                  if eval[15]=pval2[0] then begin  // if electrode name matched
                     if eval[28]<>'0' then logToFile(Application.Location,'INF Using drawingpoint Z: '+eval[28]);
                     //showmessage(eval[15]);
                     if pval2[1]='R1' then begin //0             1            2            3            4          5          6              7                                                          8            9         10
                                           //  name             Rx           mat          fp           u1          x          y              z                                                          c           poz        dxf name
                         Form2.ListBox2.Items.Add(eval[15]+';'+pval2[1]+';'+eval[1]+';'+eval[2]+';'+eval[3]+';'+pval[10]+';'+pval[11]+';'+floattostr(strtofloat(pval[12])+strtofloat(eval[28]))+';'+pval[15]+';'+eval[9]+';'+eval[0]);
                     end
                     else if ((pval2[1]='R2') and (eval[4]<>'0')) then Form2.ListBox2.Items.Add(eval[15]+';'+pval2[1]+';'+eval[1]+';'+eval[2]+';'+eval[4]+';'+pval[10]+';'+pval[11]+';'+floattostr(strtofloat(pval[12])+strtofloat(eval[28]))+';'+pval[15]+';'+eval[10]+';'+eval[0])
                     else if ((pval2[1]='R3') and (eval[5]<>'0')) then Form2.ListBox2.Items.Add(eval[15]+';'+pval2[1]+';'+eval[1]+';'+eval[2]+';'+eval[5]+';'+pval[10]+';'+pval[11]+';'+floattostr(strtofloat(pval[12])+strtofloat(eval[28]))+';'+pval[15]+';'+eval[11]+';'+eval[0])
                     else if ((pval2[1]='R4') and (eval[6]<>'0')) then Form2.ListBox2.Items.Add(eval[15]+';'+pval2[1]+';'+eval[1]+';'+eval[2]+';'+eval[6]+';'+pval[10]+';'+pval[11]+';'+floattostr(strtofloat(pval[12])+strtofloat(eval[28]))+';'+pval[15]+';'+eval[12]+';'+eval[0])
                     else if ((pval2[1]='R5') and (eval[7]<>'0')) then Form2.ListBox2.Items.Add(eval[15]+';'+pval2[1]+';'+eval[1]+';'+eval[2]+';'+eval[7]+';'+pval[10]+';'+pval[11]+';'+floattostr(strtofloat(pval[12])+strtofloat(eval[28]))+';'+pval[15]+';'+eval[13]+';'+eval[0])
                     else if ((pval2[1]='R6') and (eval[8]<>'0')) then Form2.ListBox2.Items.Add(eval[15]+';'+pval2[1]+';'+eval[1]+';'+eval[2]+';'+eval[8]+';'+pval[10]+';'+pval[11]+';'+floattostr(strtofloat(pval[12])+strtofloat(eval[28]))+';'+pval[15]+';'+eval[14]+';'+eval[0]);
                  end;
              end;
              //end
              //else begin

              //end;

           end;
           //until eof(preset);
           //CloseFile(preset);
           //showmessage('ok 6');
           //select strategy for every electrode, based on electrode number
           SetLength(disc_us,Form2.ListBox1.Count);
           SetLength(ar_strat,Form2.ListBox1.Count);

           //Automatically find best strat for every electrode based on undersize and electrode amount
           for i:=0 to Form2.ListBox1.Count-1 do begin
               distinct_us:=0;
               chck:=SplitString(';',Form2.ListBox1.Items[i]);
               aoett:=0;
               for j:=3 to 8 do begin
                   if chck[j]<>'0' then begin
                      aoett:=j-2;
                   end;
               end;
               //showmessage('aoett: '+inttostr(aoett));
               lsus:=chck[3];
               distinct_us:=1;
               for j:=2 to aoett do begin
                   if chck[2+j]<>lsus then begin
                      lsus:=chck[2+j];
                      inc(distinct_us);
                   end;
               end;
               //showmessage('ok13');
               disc_us[i]:=distinct_us;
               //showmessage(chck[0]+' '+inttostr(distinct_us));
               if ((chck[3]=chck[4]) and (distinct_us>1)) then ar_strat[i]:='2'
               else ar_strat[i]:='1';
           end;

           //save FUT files

           //forcedirectories(dir); //create folders if needed
           //showmessage('start saving FUT files');
           if Form2.ListBox1.Count>0 then begin //if any electrodes exist in listbox1
               for f2i:=0 to Form2.ListBox1.Count-1 do begin //for every electrode family
                   //strat:=ar_strat[f2i]; //causes problems
                   //showmessage('strat: '+strat);
                      //count based on virtual electrodes
                  for jjj:=0 to Form2.ListBox1.Count-1 do begin
                    chck:=SplitString(';',Form2.ListBox1.Items[jjj]);
                      if chck[8]<>'0' then aoe:=6
                      else if chck[7]<>'0' then aoe:=5
                      else if chck[6]<>'0' then aoe:=4
                      else if chck[5]<>'0' then aoe:=3
                      else if chck[4]<>'0' then aoe:=2
                      else if chck[3]<>'0' then aoe:=1;
                    end;
                  check_user:=check_user+aoe;

                   if Form2.CheckListBox1.Checked[f2i]=True then begin
                   tf_val:=SplitString(';',Form2.ListBox1.Items[f2i]);
                   if strtofloat(tf_val[3])>=1 then um_message:=um_message+AnsiString(#13#10)+'Elektroda '+tf_val[0]+ '(R1) wpisany podwymiar: '+tf_val[3]+AnsiString(#13#10)+'Upwenij się czy napewno OK';
                   if strtofloat(tf_val[4])>=1 then um_message:=um_message+AnsiString(#13#10)+'Elektroda '+tf_val[0]+ '(R2) wpisany podwymiar: '+tf_val[4]+AnsiString(#13#10)+'Upwenij się czy napewno OK';
                   if strtofloat(tf_val[5])>=1 then um_message:=um_message+AnsiString(#13#10)+'Elektroda '+tf_val[0]+ '(R3) wpisany podwymiar: '+tf_val[5]+AnsiString(#13#10)+'Upwenij się czy napewno OK';
                   if strtofloat(tf_val[6])>=1 then um_message:=um_message+AnsiString(#13#10)+'Elektroda '+tf_val[0]+ '(R4) wpisany podwymiar: '+tf_val[6]+AnsiString(#13#10)+'Upwenij się czy napewno OK';

                   //select strategy for this electrde
                   f2amount_of_el:=0;   //count based on real electrodes
                   for f2j:=0 to Form2.ListBox2.Count-1 do begin
                       pe_val:=SplitString(';',Form2.ListBox2.Items[f2j]);
                       if tf_val[15]=pe_val[0] then inc(f2amount_of_el);
                   end;
                   //if aoe<>f2amount_of_el then ShowMessage('Warning! Difference between real and virtual amount of electrodes!'); //debug
                   if tf_val[17]<>'Z' then f00f:='6'
                   else f00f:='2';
                   //showmessage(tf_val[0]+' '+f00f); //debug (undersize type)
                   AssignFile(fut,dir+'\'+tf_val[21]+'.FUT');
                   rewrite(fut);                             //   name                            fp
                   write(fut,'TRON,05.01.0'+AnsiString(#10)+'F,'+tf_val[15]+',2,0,1,2,0.,0.,0.,'+tf_val[2]+',0.,0.,0.,0,'+inttostr(f2amount_of_el)+',0,1,0,0001,0,'+f00f+',2,1,1,0,0,1;0;2;0;2;0;4;3;1;$;2;'+matforagie(tf_val[1])+';T;1;'+AnsiString(#10));
                   AssignFile(f00,dir+'\'+tf_val[21]+'.F00');
                   rewrite(f00);
                   write(f00,'_TRON_,AGIEFUT_05.01.0'+AnsiSTring(#10)+'F,1,16678904,'+tf_val[15]+',2,0,1,2,0.,0.,0.,'+tf_val[2]+',0.,0.,0.,0,'+inttostr(f2amount_of_el)+',0,0,1,0,'+f00f+',2,1,1,0,0'+AnsiString(#10));
                   if Form2.ListBox2.Count>0 then begin // add physical electrodes
                       for f2j:=0 to Form2.ListBox2.Count-1 do begin //for every entry in physical electrode list
                          pe_val:=SplitString(';',Form2.ListBox2.Items[f2j]);
                          if tf_val[15]=pe_val[0] then begin
                              if pe_val[1]='R1' then begin
                                 phase2:='1';
                                 eip2:='1';
                                 elno:='1';
                              end
                              else if pe_val[1]='R2' then begin
                                  if ((strat<>'1') and (tf_val[6]<>'0')) then begin //second roughing el
                                     phase2:='1';
                                     eip2:='2';
                                     elno:='2';
                                  end
                                  else begin
                                     phase2:='2';
                                     eip2:='1';
                                     elno:='2';
                                  end;
                              end
                              else if pe_val[1]='R3' then begin
                                   if ((tf_val[6]='0') and (strat='3')) then begin // phase 3
                                      phase2:='3';
                                      eip2:='1';
                                      elno:='3';
                                   end
                                   else begin //phase 2
                                      if (strat='1') or ((tf_val[6]='0') and (strat='2')) then begin
                                         phase2:='2';
                                         eip2:='2';
                                         elno:='3';
                                      end
                                      else if ((strat='2') and (tf_val[6]<>'0')) then begin
                                         phase2:='2';
                                         eip2:='1';
                                         elno:='3';
                                      end;
                                   end;
                              end
                              else if pe_val[1]='R4' then begin
                                   if strat='3' then begin // phase 3
                                      phase2:='3';
                                      eip2:='1';
                                      elno:='4';
                                   end
                                   else if strat='2' then begin //phase 2
                                      phase2:='2';
                                      eip2:='2';
                                      elno:='4';
                                   end
                                   else if strat='1' then begin //phase 2
                                      phase2:='2';
                                      eip2:='3';
                                      elno:='4';
                                   end;
                              end
                              else if pe_val[1]='R5' then begin
                                 if strat='3' then begin
                                      phase2:='3';
                                      eip2:='2';
                                      elno:='5';
                                 end
                                 else if strat='2' then begin
                                      phase2:='2';
                                      eip2:='3';
                                      elno:='5'
                                 end
                                 else if strat='1' then begin
                                      phase2:='2';
                                      eip2:='4';
                                      elno:='5';
                                 end;
                              end
                              else if pe_val[1]='R6' then begin
                                 if strat='3' then begin
                                     phase2:='3';
                                     eip2:='3';
                                     elno:='6';
                                 end
                                 else if strat='2' then begin
                                     phase2:='2';
                                     eip2:='4';
                                     elno:='6';
                                 end
                                 else if strat='1' then begin
                                     phase2:='2';
                                     eip2:='5';
                                     elno:='6';
                                 end;
                              end;

                              if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                              else umode:='1';
                              if tf_val[16]='1' then le:='LE'+pe_val[9]
                              else le:='$';
                              if tf_val[17]<>'Z' then begin
                                 f00_sk:=pe_val[4];
                              end
                              else begin
                                   f00_sk:='0.';
                              end;

                              if CheckBox9.Checked then begin //case of misconfigured preset
                                 oldx:=strtofloat(pe_val[5]);
                                 oldy:=strtofloat(pe_val[6]);
                                 if oldx=0 then oldx:=0.0001;
                                 if oldy=0 then oldy:=0.0001;
                                 oldc:=strtofloat(pe_val[8]);
                                 newx:=roundto((oldx*cos(degtorad(oldc)))-(oldy*sin(degtorad(oldc))),4);
                                 newy:=roundto((oldx*sin(degtorad(oldc)))+(oldy*cos(degtorad(oldc))),4);
                                 if ((tf_val[16]='1') and ((elno='2') or (elno='4') or (elno='6'))) then begin //multi
                                    newx:=-newx;
                                    newy:=-newy;
                                 end;
                                 pe_val[5]:=floattostr(newx);
                                 pe_val[6]:=floattostr(newy);
                              end;


                              write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+pe_val[4]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                              write(fut,'U,R'+elno+',1,2,'+pe_val[9]+',3,'+pe_val[4]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,'+le+',F,0,0,T,0.,1,'+inttostr(strtoint(tf_val[16])+1)+',V'+elno+','+tf_val[15]+AnsiString(#10));
                              write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+pe_val[4]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                              write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+pe_val[9]+',3,'+pe_val[4]+','+pe_val[5]+','+pe_val[6]+','+pe_val[7]+','+pe_val[8]+',0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,'+le+',F,0,0,T,'+f00_sk+',1,'+inttostr(strtoint(tf_val[16])+1)+',1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                          end;
                       end;
                   end; //listbox2 - physical electrodes
                   CloseFile(fut);
                   CloseFile(f00);
                   AssignFile(fur,dir+'\'+tf_val[21]+'.FUR');
                   rewrite(fur);
                   write(fur,'AGIE.VERSION 2,05.01.0;'+AnsiString(#10)+'.LONGNAME '+tf_val[15]+';'+AnsiString(#10)+'AGIE.USING_1 IMPORT COUNT_0 '+tf_val[21]+'.F00;');
                   CloseFile(fur);
                   AssignFile(f0r,dir+'\'+tf_val[21]+'.F0R');
                   rewrite(f0r);
                   write(f0r,'AGIE.VERSION 2,05.01.0;'+AnsiSTring(#10)+'.LONGNAME '+tf_val[15]+';');
                   CloseFile(f0r);
                   Form2.Label12.Caption:=Form2.Label12.Caption+'.';
                   end; //if checked
               end; //iterating through Listbox1
               //showmessage('finished saving FUT files');
           end; //if any electrodes exist in listbox1

        end //if .mes file opened
        else begin //do electrodes based on Form2.ListBox1, without .mes file and listbox2 -- failsafe
            SetLength(disc_us,Form2.ListBox1.Count);
           SetLength(ar_strat,Form2.ListBox1.Count);

           for i:=0 to Form2.ListBox1.Count-1 do begin
               //showmessage('ok11');
               distinct_us:=0;
               chck:=SplitString(';',Form2.ListBox1.Items[i]);
               aoett:=0;
               for j:=3 to 8 do begin
                   if chck[j]<>'0' then begin
                      aoett:=j-2;
                   end;
               end;
               //showmessage('aoett: '+inttostr(aoett));
               lsus:=chck[3];
               distinct_us:=1;
               for j:=2 to aoett do begin
                   if chck[2+j]<>lsus then begin
                      lsus:=chck[2+j];
                      inc(distinct_us);
                   end;
               end;
               //showmessage('ok13');
               disc_us[i]:=distinct_us;
               //showmessage(chck[0]+' '+inttostr(distinct_us));
               if ((chck[3]=chck[4]) and (distinct_us>1)) then ar_strat[i]:='2'
               else ar_strat[i]:='1';
           end;

            for i:=0 to Form2.ListBox1.Count-1 do begin
                 if Form2.CheckListBox1.Checked[i]=True then begin
                 tf_val:=SplitString(';',Form2.ListBox1.Items[i]);

                   if strtofloat(tf_val[3])>=1 then um_message:=um_message+AnsiString(#13#10)+'Elektroda '+tf_val[0]+ '(R1) wpisany podwymiar: '+tf_val[3]+AnsiString(#13#10)+'Upwenij się czy napewno OK';
                   if strtofloat(tf_val[4])>=1 then um_message:=um_message+AnsiString(#13#10)+'Elektroda '+tf_val[0]+ '(R2) wpisany podwymiar: '+tf_val[4]+AnsiString(#13#10)+'Upwenij się czy napewno OK';
                   if strtofloat(tf_val[5])>=1 then um_message:=um_message+AnsiString(#13#10)+'Elektroda '+tf_val[0]+ '(R3) wpisany podwymiar: '+tf_val[5]+AnsiString(#13#10)+'Upwenij się czy napewno OK';
                   if strtofloat(tf_val[6])>=1 then um_message:=um_message+AnsiString(#13#10)+'Elektroda '+tf_val[0]+ '(R4) wpisany podwymiar: '+tf_val[6]+AnsiString(#13#10)+'Upwenij się czy napewno OK';

                 if fold='1' then dir:=ust.ReadString('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output')+'\'+Form1.Edit3.Text
                 else dir:=ust.ReadString('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output');
                 strat:=ust.ReadString('settings','electrodeStrategy','1');
                 forcedirectories(dir); //create folders if needed
                 strat:=ar_strat[i];
                 AssignFile(fur,dir+'\'+tf_val[21]+'.FUR');
                 rewrite(fur);
                 write(fur,'AGIE.VERSION 2,05.01.0;'+AnsiString(#10)+'.LONGNAME '+tf_val[15]+';'+AnsiString(#10)+'AGIE.USING_1 IMPORT COUNT_0 '+tf_val[21]+'.F00;');
                 CloseFile(fur);
                 AssignFile(f0r,dir+'\'+tf_val[21]+'.F0R');
                 rewrite(f0r);
                 write(f0r,'AGIE.VERSION 2,05.01.0;'+AnsiSTring(#10)+'.LONGNAME '+tf_val[15]+';');
                 CloseFile(f0r);
                 if tf_val[8]<>'0' then amount_of_el:=6
                 else if tf_val[7]<>'0' then amount_of_el:=7
                 else if tf_val[6]<>'0' then amount_of_el:=4
                 else if tf_val[5]<>'0' then amount_of_el:=3
                 else if tf_val[4]<>'0' then amount_of_el:=2
                 else amount_of_el:=1;
                 AssignFile(fut,dir+'\'+tf_val[21]+'.FUT');
                 rewrite(fut);                             //   name                            fp
                 write(fut,'TRON,05.01.0'+AnsiString(#10)+'F,'+tf_val[0]+',2,0,1,2,0.,0.,0.,'+tf_val[2]+',0.,0.,0.,0,'+inttostr(amount_of_el)+',0,1,0,0001,0,2,2,1,1,0,0,1;0;2;0;2;0;4;3;1;$;2;'+matforagie(tf_val[1])+';T;1;'+AnsiString(#10));
                 AssignFile(f00,dir+'\'+tf_val[21]+'.F00');
                 rewrite(f00);
                 if tf_val[17]<>'Z' then begin
                      f00f:='6';   //undersize type - 6=jednakowo dolegly, 2=boczny
                     // f00_sk:=pe_val[4];    //wrong!
                   end
                   else begin
                        f00f:='2';
                      //
                   end;
                   f00_sk:='0.';
                 write(f00,'_TRON_,AGIEFUT_05.01.0'+AnsiString(#10)+'F,1,16678904,'+tf_val[15]+',2,0,1,2,0.,0.,0.,'+tf_val[2]+',0.,0.,0.,0,'+inttostr(amount_of_el)+',0,0,1,0,'+f00f+',2,1,1,0,0'+AnsiString(#10));
                 if strat='1' then begin
                    elno:='1';
                    phase2:='1';
                    eip2:='1';
                    if tf_val[17]<>'Z' then f00_sk:=tf_val[3];
                    //u1
                    if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                    else umode:='1';
                    write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[3]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                     write(fut,'U,R'+elno+',1,2,'+tf_val[9]+',3,'+tf_val[3]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                     write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[3]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                     write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[9]+',3,'+tf_val[3]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                     if amount_of_el>=2 then begin
                        elno:='2';
                        phase2:='2';
                        eip2:='1';//u1
                        if (strat='2') then begin
                            phase2:='1';
                            eip2:='2';
                        end;
                        if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                        else umode:='1';
                        if tf_val[17]<>'Z' then f00_sk:=tf_val[4];
                        write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[4]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                        write(fut,'U,R'+elno+',1,2,'+tf_val[10]+',3,'+tf_val[4]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                        write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[4]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                        write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[10]+',3,'+tf_val[4]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                        if amount_of_el>=3 then begin
                           elno:='3';
                           phase2:='2';
                           eip2:='2';
                           if (strat='2') then begin
                            phase2:='2';
                            eip2:='1';
                        end; //u1
                           if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                           else umode:='1';
                           if tf_val[17]<>'Z' then f00_sk:=tf_val[5];
                           write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[5]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                           write(fut,'U,R'+elno+',1,2,'+tf_val[11]+',3,'+tf_val[5]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                           write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[5]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                           write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[11]+',3,'+tf_val[5]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                           if amount_of_el>=4 then begin
                              elno:='4';
                              phase2:='2';
                              eip2:='3';
                              if (strat='2') then begin
                            phase2:='2';
                            eip2:='2';
                        end; //u1
                              if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                              else umode:='1';
                              if tf_val[17]<>'Z' then f00_sk:=tf_val[6];
                              write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[6]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                              write(fut,'U,R'+elno+',1,2,'+tf_val[12]+',3,'+tf_val[6]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                              write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[6]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                              write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[12]+',3,'+tf_val[6]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                              if amount_of_el>=5 then begin
                                 elno:='5';
                                 phase2:='2';
                                 eip2:='4';                                                              //u1
                                 if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                                 else umode:='1';
                                 if tf_val[17]<>'Z' then f00_sk:=tf_val[7];
                                 write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[7]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                                 write(fut,'U,R'+elno+',1,2,'+tf_val[13]+',3,'+tf_val[7]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                                 write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[7]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                                 write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[13]+',3,'+tf_val[7]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                                 if amount_of_el>=6 then begin
                                    elno:='6';
                                    phase2:='2';
                                    eip2:='5';                                                              //u1
                                    if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                                    else umode:='1';
                                    if tf_val[17]<>'Z' then f00_sk:=tf_val[8];
                                    write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[8]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                                    write(fut,'U,R'+elno+',1,2,'+tf_val[14]+',3,'+tf_val[8]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                                    write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[8]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                                    write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[14]+',3,'+tf_val[8]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                                 end;
                              end;
                           end;
                        end;
                     end;
                 end //strat 1
                 else if strat='2' then begin
                     elno:='1';
                    phase2:='1';
                    eip2:='1';                                                              //u1
                    if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                    else umode:='1';
                    if tf_val[17]<>'Z' then f00_sk:=tf_val[3];
                     write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[3]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                     write(fut,'U,R'+elno+',1,2,'+tf_val[9]+',3,'+tf_val[3]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                     write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[3]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                     write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[9]+',3,'+tf_val[3]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                     if amount_of_el>=2 then begin
                        if amount_of_el<4 then begin
                             elno:='2';
                             phase2:='2';
                             eip2:='1';
                        end
                        else begin
                             elno:='2';
                             phase2:='1';
                             eip2:='2';
                        end;
                        if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                        else umode:='1';
                        if tf_val[17]<>'Z' then f00_sk:=tf_val[4];
                        write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[4]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                        write(fut,'U,R'+elno+',1,2,'+tf_val[10]+',3,'+tf_val[4]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                        write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[4]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                        write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[10]+',3,'+tf_val[4]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                        if amount_of_el>=3 then begin
                           if amount_of_el=4 then begin
                              elno:='3';
                             phase2:='2';
                             eip2:='1';
                           end
                           else begin
                              elno:='3';
                             phase2:='2';
                             eip2:='2';
                            end;
                           if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                           else umode:='1';
                           if tf_val[17]<>'Z' then f00_sk:=tf_val[5];
                           write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[5]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                           write(fut,'U,R'+elno+',1,2,'+tf_val[11]+',3,'+tf_val[5]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                           write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[5]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                           write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[11]+',3,'+tf_val[5]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                           if amount_of_el>=4 then begin
                               elno:='4';
                             phase2:='2';
                             eip2:='2';
                             if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                             else umode:='1';
                             if tf_val[17]<>'Z' then f00_sk:=tf_val[6];
                              write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[6]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                              write(fut,'U,R'+elno+',1,2,'+tf_val[12]+',3,'+tf_val[6]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                              write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[6]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                              write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[12]+',3,'+tf_val[6]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                              if amount_of_el>=5 then begin
                                 elno:='5';
                                 phase2:='2';
                                 eip2:='3';
                                 if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                                 else umode:='1';
                                 if tf_val[17]<>'Z' then f00_sk:=tf_val[7];
                                 write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[7]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                                 write(fut,'U,R'+elno+',1,2,'+tf_val[13]+',3,'+tf_val[7]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                                 write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[7]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                                 write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[13]+',3,'+tf_val[7]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                                 if amount_of_el>=6 then begin
                                    elno:='6';
                                    phase2:='2';
                                    eip2:='4';
                                    if ((strtoint(elno)>1) and (strtoint(phase2)>=2)) then umode:='2'
                                    else umode:='1';
                                    if tf_val[17]<>'Z' then f00_sk:=tf_val[8];
                                    write(fut,'O,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[8]+',1,'+umode+',0,1,0,0.,1,'+tf_val[15]+AnsiString(#10));
                                    write(fut,'U,R'+elno+',1,2,'+tf_val[14]+',3,'+tf_val[8]+',0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,'+phase2+','+eip2+',1,$,F,0,0,T,0.,1,1,V'+elno+','+tf_val[15]+AnsiString(#10));
                                    write(f00,'O,'+inttostr((strtoint(elno)*2))+',7166,V'+elno+','+matforagie(tf_val[1])+','+phase2+','+eip2+','+tf_val[8]+',1,'+umode+',0,1,0,'+inttostr((strtoint(elno)*2))+',0.,1,1'+AnsiSTring(#10));                 //'+inttostr((strtoint(elno)*2)+1)+' ??
                                    write(f00,'U,'+inttostr((strtoint(elno)*2)+1)+',4246470654+7,R'+elno+',1,2,'+tf_val[14]+',3,'+tf_val[8]+',0,0,0,0,0.,0.,0.,0.,0.,0.,0,$,$,F,T,V'+elno+',1,1,$,0,1,$,F,0,0,T,'+f00_sk+',1,1,1,'+inttostr((strtoint(elno)*2))+AnsiString(#10));
                                 end;
                             end;
                           end;
                        end;
                     end;
                 end //strat 2
                 else if strat='3' then begin
                    if vm>=2 then ShowMessage('Strategia nieobslugiwana! (3)');
                    logToFile(Application.Location,'ERR Strategy not supported (failsafe mode)');
                 end; //strat 3
                 CloseFile(fut);
                 CloseFile(f00);
                 end; //if electrode checked
             end;
        end;

     if ((check_preset<>check_user) and (vm>=2)) then ShowMessage('Uwaga! Możliwa niezgodność w danych z preseta! ('+inttostr(check_preset)+' ≠ '+inttostr(check_user)+')');
     ProgressBar1.max:=40;
     ProgressBar1.Position:=0;
     randomize;
     str:='0123456789ABCDEFGHIJKLMNOPQRSTUVYZ';
     rname:='JOB';
     for i:=1 to 5 do rname:=rname + str[random(length(str))+1];  //random filename for program files
     str:='0123456789';
     rnumber:='1';
     for i:=1 to 3 do rnumber:=rnumber + str[random(length(str))+1];
     strat:=ust.ReadString('settings','electrodeStrategy','1');
     pozp:=ust.ReadString('settings','pp','30');
     ust.Free;
     ProgressBar1.Position:=10;
     AssignFile(tek,dir+'\'+rname+'.TEK');
     rewrite(tek);  // .tek file is empty, but required
     CloseFile(tek);
     AssignFile(ter,dir+'\'+rname+'.TER');
     rewrite(ter);
     write(ter,'AGIE.VERSION 2,05.01.0;'+AnsiString(#10)+'.LONGNAME detal:'+rnumber+';'); //another useless random number required by the AGIEVISION
     CloseFile(ter);
     ProgressBar1.Position:=20;
     AssignFile(j00,dir+'\'+rname+'.J00');
     rewrite(j00);
     write(j00,'_TRON_,05.01.0'+AnsiString(#10)+'J,1,12,$,x123,P,1'+AnsiString(#10));
     write(j00,'H,7,2,7,T,T,2,$,0,0,-7.2792,0,0,0,0,0,0,0,0,T,1,1'+AnsiString(#10));
     write(j00,'H,37,2,37,T,T,2,$,0,0,-7.2792,0,0,0,0,0,0,0,0,T,1,1'+AnsiString(#10));
     write(j00,'H,67,2,67,T,T,2,$,0,0,-7.2792,0,0,0,0,0,0,0,0,T,1,1'+AnsiString(#10));
     write(j00,'H,97,2,97,T,T,2,$,0,0,-7.2792,0,0,0,0,0,0,0,0,T,1,1'+AnsiString(#10));
     write(j00,'W,2,4261414906+520,1111245n,1,AGIE.BEA_1,$,KW,2,0,0,30,100,100,0,0,0,0,0,0,0,0,0,0,0,-50,-50,-50,100,100,50,$,30,1,2,0,F,1,0,$,$,1,$,$,4,1'+AnsiString(#10));
     write(j00,'C,3,32766,Correzione_1,119.9875,65.8236,119.8974,0,0,-0.116,0,0,0,0,0,0,0,0,1,2,0,0,0,0'+AnsiString(#10));
     CloseFile(j00);
     AssignFile(jor,dir+'\'+rname+'.JOR');
     rewrite(jor);
     write(jor,'AGIE.VERSION 2,05.01.0;'+AnsiString(#10)+'.LONGNAME '+Edit3.Text+';'+AnsiString(#10)+'AGIE.USING_1 IMPORT COUNT_0 '+rname+'.TEK;'+AnsiString(#10)); //import empty technology file
     for i:=0 to Form2.ListBox1.Count-1 do begin //for every electrode in form2
         p_elval:=SplitString(';',Form2.ListBox1.Items[i]);
         if Form2.CheckListBox1.Checked[i]=True then begin //only when checked
            write(jor,'AGIE.USING_'+inttostr(i+2)+' IMPORT COUNT_1 '+p_elval[21]+'.FUT;'+AnsiString(#10)); //import every electrode for use in .JOB file
            last_using:=i+2;
         end;
     end;
      // new iso gen - per machining
      for i:=0 to Form1.ListBox9.Count-1 do begin
          if Form1.ListBox9.Items[i]<>'Z' then begin
            iname:='ISO';
            sleep(random(50*i)); //because otherwise random gives the same numbers for all iso files
            for j:=1 to 5 do iname:=iname + str[random(length(str))+1];
            inc(last_using);
            // num in listbox ; direction ; odsuniecie ; isoname ; using_nr
            ListBox10.Items.Add(inttostr(i)+';'+Form1.ListBox9.Items[i]+';'+Form1.ListBox11.Items[i]+';'+iname+';'+inttostr(last_using));
            write(jor,'AGIE.USING_'+inttostr(last_using)+' IMPORT COUNT_0 '+iname+'.ISO;'+AnsiString(#10)); //iso file for side eroding
          end;
      end;

      //make list of vdi names and bea numbers  (ItemIndex = bea_nr)
      for i:=0 to Form2.ListBox1.Count-1 do begin
          p_elval:=SplitString(';',Form2.ListBox1.Items[i]);
          if ListBox13.Count>0 then begin
              exists_in_list:=false;
              for j:=0 to ListBox13.Count-1 do begin
                  if p_elval[20]=ListBox13.Items[j] then exists_in_list:=True;
              end;
              if exists_in_list=false then ListBox13.Items.Add(p_elval[20]);
          end
          else ListBox13.Items.Add(p_elval[20]);
      end;
      //add each vdi once  TODO: move definitions to ini file
      for i:=0 to ListBox13.Count-1 do begin
          write(jor,'AGIE.BEA_'+inttostr(i+1)+' IMPORT COUNT_2 '+vdi_num_to_agie(ListBox13.Items[i])+',F,T,T,F,F;'+AnsiString(#10));
      end;
     CloseFile(jor);
     ProgressBar1.Position:=30;
     AssignFile(job,dir+'\'+rname+'.JOB');
     rewrite(job);
     if CheckBox3.Checked=True then gnam:='Group' //only create 1 group, to be copied on machine
     else gnam:='$';
     write(job,'TRON,05.01.0'+AnsiString(#10)+'J,$,x123,000,CNNPx,CNNPy,CNNCx,CNNCy,ZOOMPx,ZOOMPy,ZOOMCx,ZOOMCy,L,MinMax,Optmize'+AnsiString(#10)); //header

     write(job,'W,'+Edit3.Text+',4,000,'+ii_to_agie_pmat(ComboBox4.ItemIndex)+',AGIE.BEA_1,,1,2,'+pozp+',1,0,F,0,T,2,40,'+floattostr(strtofloat(Edit11.Text)*(-1))+','+floattostr(strtofloat(Edit12.Text)*(-1))+','+floattostr(strtofloat(Edit13.Text)*(-1))+',0.0,0.0,'+Edit14.Text+',0.0,0.0,0.0,0.0,0.0,100,100,50,-50,-50,-50,30,1,0,KW,0,F,0,F,0,F,0,0,F,1.3,T,0.8,F,$,$,1,$,$,$,$,2,TipoEdit2,TipoGraph,65536,0,0,0,65536,0,5000,5000,1,TipoGraph,65536,0,0,0,65536,0,10000,10000,1');
     if CheckBox3.Checked= True then write(job,AnsiString(#10)+'G,'+gnam+','+inttostr(ListBox2.Count)+',+0.0000,+0.0000,0.0,0,0,0.0,0,0,0,0,0,1,1,1,1,0,F,0,T,2,40,AGIE.BEA_1,,0,1,0,0,F,0,F,0,0,F,1.3,'+ii_to_agie_pmat(ComboBox4.ItemIndex)+',0,F,'+Edit3.Text+',$,2,1.0000,1.0000,2,65536,0,0,0,65536,0,10000,10000,1,TipoGraph,65536,0,0,0,65536,0,10000,10000,1');
     for i:=0 to ListBox2.Count-1 do begin //for every entry in table
         min_z:=200;
         for j:=0 to Form2.ListBox1.Count-1 do begin
             p_elval:=SplitString(';',Form2.ListBox1.Items[j]);
             min_z:=min(min_z,round(strtofloat(p_elval[7])));
             if trim(ListBox2.Items[i])=p_elval[0] then begin
               using_nr:=(j+2);
               if Form2.CheckListBox1.Checked[j]=True then do_this_el:=True
               else do_this_el:=False;
             end;
         end;
         kapiel:=40;
         if min_z<(strtofloat(ListBox6.Items[i])-20) then kapiel:=20; //TODO: test the exact value on machine
         if do_this_el=True then begin
           amount_of_el:=0;
            if Form2.ListBox2.Count>0 then begin //if there is data from preset
               for j:=0 to Form2.ListBox2.Count-1 do begin
                   p_elam:=SplitString(';',Form2.ListBox2.Items[j]);
                   if ListBox2.Items[i]=p_elam[10] then inc(amount_of_el);
               end;
            end
            else begin
                for j:=0 to Form2.ListBox1.Count-1 do begin
                    p_elam:=SplitString(';',Form2.ListBox1.Items[j]);
                    if ListBox2.Items[i]=p_elam[0] then begin
                      if p_elam[8]<>'0' then amount_of_el:=6
                      else if p_elam[7]<>'0' then amount_of_el:=5
                      else if p_elam[6]<>'0' then amount_of_el:=4
                      else if p_elam[5]<>'0' then amount_of_el:=3
                      else if p_elam[4]<>'0' then amount_of_el:=2
                      else if p_elam[3]<>'0' then amount_of_el:=1;
                    end;
                end;
            end;

            //match vdi bea number to electrode
             for j:=0 to Form2.ListBox1.Count-1 do begin
                    p_elam:=SplitString(';',Form2.ListBox1.Items[j]);
                    if ListBox2.Items[i]=p_elam[0] then begin
                       for k:=0 to ListBox13.Count-1 do begin
                          //showmessage('pos. '+inttostr(k)+': '+ListBox13.Items[k]+' - '+p_elam[16]);
                          if ListBox13.Items[k]=p_elam[20] then bea_nr:=k+1;
                      end;
                    end;
                end;
             //find out el properties for eroding direction
                      if ListBox9.Items[i]<>'Z' then begin
                           iusing:='error';
                           for k:=0 to ListBox10.Count-1 do begin
                               isoval:=SplitString(';',ListBox10.Items[k]);
                               if isoval[0]=inttostr(i) then iusing:=isoval[4];
                           end;
                           case ListBox9.Items[i] of
                                'X+': sp_coordsa:='-'+ListBox11.Items[i]+',0.0, 0';
                                '+X': sp_coordsa:='-'+ListBox11.Items[i]+',0.0, 0';
                                'X-': sp_coordsa:=ListBox11.Items[i]+',0.0, 0';
                                '-X': sp_coordsa:=ListBox11.Items[i]+',0.0, 0';
                                'Y+': sp_coordsa:='0.0,-'+ListBox11.Items[i]+', 0';
                                '+Y': sp_coordsa:='0.0,-'+ListBox11.Items[i]+', 0';
                                'Y-': sp_coordsa:='0.0,'+ListBox11.Items[i]+', 0';
                                '-Y': sp_coordsa:='0.0,'+ListBox11.Items[i]+', 0';
                           end;
                           //showmessage(sp_coordsa);  //debug
                           z_in_mach:=ListBox6.Items[i];
                           mach_add:=' 8, '+inttostr(amount_of_el)+'; 0; '+ListBox11.Items[i]+'; 0; 0; 0';
                           z_in_geo:='0';
                           if iusing='error' then ShowMessage('Wrong using number for iso file!');
                           geo_add:='2,2,1,1,0.0,2,1,1,AGIE.USING_'+iusing;
                           geo_add2:='0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,2,0,0,0,0,0,45,0,1,3,0,0,0,0,1,F,F,1,0,1,0,0,0,0,0,0,0,T,1,1,2,3,4,0,0,0,0,0,0,F,2,0,0,-1,2,1,1,0,0,0,0,0,0';
                           only_vector:='T';
                           only_ret:='1';  //finishing shape
                           ksp:='3'; //kapiel od detalu
                           strange_number:='130';   //probably doesn't matter
                      end
                      else begin  // normal eroding (Z direction )
                           for j:=0 to Form2.ListBox1.Count-1 do begin
                               p_elam:=SplitString(';',Form2.ListBox1.Items[j]);
                               if p_elam[0]=ListBox2.Items[i] then mtd:=p_elam[19];
                           end;
                           sp_coordsa:='0.0000,0.0000,3.0000';
                           z_in_mach:='0.0';
                           mach_add:='0,0';
                           z_in_geo:=ListBox6.Items[i];
                           if strtofloat(z_in_geo)=0 then z_in_geo:='-0.001';
                           geo_add:='2,1,1,1,0.0,0,1,2,';
                           //get values for this electrode and set varribles to the coresponding EDM method
                           if mtd='1' then only_vector:='F'
                           else only_vector:='T';
                           if mtd='3' then only_ret:='2'
                           else only_ret:='1';  //finishing shape
                           if mtd='0' then      geo_add2:='0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,0,0,5,0,0,0,0,0,45,1,1,3,0,0,0,0,1,F,T,1,0,1,0,0,0,0,0,0,0,F,1,1,2,3,4,0,0,0,0,0,0,F,1,0,0,0,1,1,1,0,0,0,0,0,0'  //3d
                           else if mtd='3' then geo_add2:='0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,5,0,0,0,0,0,45,1,2,3,0,0,0,0,1,F,T,1,0,1,0,0,0,0,0,0,0,F,1,1,2,3,4,0,0,0,0,0,0,F,1,0,0,0,1,1,1,0,0,0,0,0,0'  //ret
                           else                 geo_add2:='0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,5,0,0,0,0,0,45,1,1,3,0,0,0,0,1,F,T,1,0,1,0,0,0,0,0,0,0,F,1,1,2,3,4,0,0,0,0,0,0,F,1,0,0,0,1,1,1,0,0,0,0,0,0'; //cyl & vect
                           ksp:='2'; //kapiel od pkt start
                           strange_number:='138';  //probably doesn't matter
                      end;
            // end of eroding direction things

            if CheckBox3.Checked=True then write(job,AnsiString(#10)+'R,Mach'+inttostr(i)+','+ListBox3.Items[i]+','+ListBox4.Items[i]+','+z_in_mach+',0,0,'+ListBox5.Items[i]+',0,0,0,0,0,F,F,1,1,0,F,0,T,'+ksp+','+inttostr(kapiel)+',AGIE.USING_'+inttostr(using_nr)+',0,Geo_Mach'+inttostr(i)+',1,'+ii_to_agie_pmat(ComboBox4.ItemIndex)+',AGIE.BEA_'+inttostr(bea_nr)+',F,,StartPoint,6,,-1,1,0,0,0,0,T,5,F,T,T,T,F,0,0,0,1,0,'+mach_add+',0,0,0,0,1,0,0,0,134,'+gnam+','+Edit3.Text+',$,1.0000,1.0000,1,65536,0,0,0,65536,0,10000,10000,1'+AnsiString(#10))
            else                           write(job,AnsiString(#10)+'A,Mach'+inttostr(i)+','+ListBox3.Items[i]+','+ListBox4.Items[i]+','+z_in_mach+',0,0,'+ListBox5.Items[i]+',0,0,0,0,0,F,F,1,1,0,F,0,T,'+ksp+','+inttostr(kapiel)+',AGIE.USING_'+inttostr(using_nr)+',0,Geo_Mach'+inttostr(i)+',1,'+ii_to_agie_pmat(ComboBox4.ItemIndex)+',AGIE.BEA_'+inttostr(bea_nr)+',F,,StartPoint,5,,-1,1,0,0,0,0,T,5,F,T,T,T,F,0,0,0,1,0,'+mach_add+',0,0,0,0,1,0,0,0,'+strange_number+','+Edit3.Text+',$,1.0000,1.0000,1,64420,11397,0,-11397,64420,0,11000,11000,1'+AnsiString(#10));
            write(job,'E,Geo_Mach'+inttostr(i)+',T,T,F,1,'+only_vector+','+geo_add+',0,0,'+z_in_geo+',0,0,0,T,0,0.0,0.0,F,'+only_ret+',0,0,0,0,0,0,0,360,0,F,'+geo_add2+',Mach'+inttostr(i)+','+gnam+','+Edit3.Text+',$');
            //next lines for every physical electrode of this family (copy of .FUT information basically, but in slightly different format, cannot be copied)

            for j:=1 to 6 do begin
                phase[j]:=0;
                eip[j]:=0;
            end;
            if strat='1' then begin
               for j:=1 to amount_of_el do begin
                   if j=1 then begin
                      phase[j]:=1;
                      eip[j]:=1;
                   end
                   else begin
                        phase[j]:=2;
                        eip[j]:=(j-1);
                   end;
               end;
            end
            else if strat='2' then begin
                 for j:=1 to amount_of_el do begin
                     if j=1 then begin
                        phase[j]:=1;
                        eip[j]:=1;
                     end
                 else if j=2 then begin
                      if amount_of_el=4 then begin
                         phase[j]:=1;
                         eip[j]:=2;
                      end
                      else begin
                           phase[j]:=2;
                           eip[j]:=1;
                      end;
                 end
                 else if j=3 then begin
                      if amount_of_el=4 then begin
                         phase[j]:=2;
                         eip[j]:=1;
                      end
                      else begin
                           phase[j]:=2;
                           eip[j]:=2;
                      end;
                 end
                 else begin //j=4,5,6
                    phase[j]:=2;
                    eip[j]:=(j-2);
                 end;
              end;
            end
            else if strat='3' then begin //not working for 6 electrodes!
                 for j:=1 to amount_of_el do begin
                     if j=1 then begin
                        phase[j]:=1;
                        eip[j]:=1;
                     end
                     else begin
                          if amount_of_el=4 then begin
                             phase[j]:=(j-1);
                             if j=2 then eip[j]:=2
                             else eip[j]:=1;
                          end
                          else begin
                               phase[j]:=j;
                               eip[j]:=1;
                          end;
                     end;
                 end;
             end;
             for j:=1 to amount_of_el do write(job,AnsiString(#10)+'p,0,'+inttostr(j)+',0,'+inttostr(phase[j])+','+inttostr(eip[j])+',0,3,32,127,0,1,0,1,10,35,35,1,5,0,20,50,50,1,0,0,0,0');
             for j:=1 to amount_of_el do write(job,AnsiString(#10)+'l,1,'+inttostr(j)+',0,'+inttostr(phase[j])+','+inttostr(eip[j])+',0,0,0,0,0,0,0');
             for j:=1 to amount_of_el do write(job,AnsiString(#10)+'a,2,'+inttostr(j)+',0,'+inttostr(phase[j])+','+inttostr(eip[j])+',0,0,1.000,1.000,2,0,5,0.020,0.008,0');
             write(job,AnsiString(#10)+'I,StartPoint,'+sp_coordsa+',0,3.0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,T,F,F,Mach'+inttostr(i)+','+gnam+','+Edit3.Text+',$');
         end; //do_this_el
     end;

     CloseFile(job);
     if ListBox10.Count>0 then begin //create iso files
        for i:=0 to ListBox10.Count-1 do begin
            isoval:=SplitString(';',ListBox10.Items[i]);
            AssignFile(iso,dir+'\'+isoval[3]+'.ISO');
            rewrite(iso);
            //if AnsiContainsStr(isoval[2],'.') then littledot:='.'
            //else littledot:='';
            littledot:='';
            case isoval[1] of
                 'X+': sp_coords:=' X-'+isoval[2]+littledot+' Y0.0';
                 '+X': sp_coords:=' X-'+isoval[2]+littledot+' Y0.0';
                 'X-': sp_coords:=' X'+isoval[2]+littledot+' Y0.0';
                 '-X': sp_coords:=' X'+isoval[2]+littledot+' Y0.0';
                 'Y+': sp_coords:=' X0.0 Y-'+isoval[2]+littledot;
                 '+Y': sp_coords:=' X0.0 Y-'+isoval[2]+littledot;
                 'Y-': sp_coords:=' X0.0 Y'+isoval[2]+littledot;
                 '-Y': sp_coords:=' X0.0 Y'+isoval[2]+littledot;
            end;
            case isoval[1] of
                 'X+': drbok:=' X'+isoval[2]+littledot;
                 '+X': drbok:=' X'+isoval[2]+littledot;
                 'X-': drbok:=' X-'+isoval[2]+littledot;
                 '-X': drbok:=' X-'+isoval[2]+littledot;
                 'Y+': drbok:=' Y'+isoval[2]+littledot;
                 '+Y': drbok:=' Y'+isoval[2]+littledot;
                 'Y-': drbok:=' Y-'+isoval[2]+littledot;
                 '-Y': drbok:=' Y-'+isoval[2]+littledot;
            end;

            write(iso,'N0G00'+sp_coords+'Z 0.;'+AnsiString(#10)+'N1G91;'+AnsiString(#10)+'N2G01'+drbok+';'+AnsiString(#10)+'N3M02;'+AnsiString(#10));
            CloseFile(iso);
            AssignFile(isr,dir+'\'+isoval[3]+'.ISR');
            rewrite(isr); //isr is the metadata file required for every iso
            write(isr,'AGIE.VERSION 2,05.01.0;'+AnsiString(#10)+'.LONGNAME Machiso'+isoval[4]+';');
            CloseFile(isr);
        end;
     end;
     ProgressBar1.Position:=40;
     logToFile(Application.Location,'OK program sent to Agie HP ('+Edit3.Text+')');
     //option send to cmm
     if CheckBox11.Checked then begin
       Memo12.Clear;
       Memo12.Lines.Add('workpiece');
       for i:=0 to Form2.ListBox1.Items.Count-1 do begin
           l:=SplitString(';',Form2.ListBox1.Items[i]);
           Memo12.Lines.Add(l[0]+':R1');
           if l[4]<>'0' then Memo12.Lines.Add(l[0]+':R2');
           if l[5]<>'0' then Memo12.Lines.Add(l[0]+':R3');
           if l[6]<>'0' then Memo12.Lines.Add(l[0]+':R4');
       end;
       Memo12.Lines.SaveToFile('P:\lus\agz\'+Edit3.Text+'.agz');
     end;
     Form9.ListBox1.Clear;
     for cvdi9:=0 to Form1.ListBox13.Count-1 do Form9.ListBox1.Items.Add(Form1.ListBox13.Items[cvdi9]);
     Form9.Label2.Caption:=Edit3.Text;
     Form12.Memo1.Lines.Add(um_message);
     //Form12.Memo1.Lines[0]:=;
     if um_message<>'Znalezione problemy:' then begin
        logToFile(Application.Location,'INF found errors: '+um_message);
        Form12.ShowModal;
     end;
     if Form9.ShowModal=mrOK then logToFile(Application.Location,'INF opened folder'); //results form
   end
   else ShowMessage('Uzupełnij dane elektrod.');
end;

procedure TForm1.Button15Click(Sender: TObject);
var sr:TSearchRec;
  i:integer;
  l:TArrayOfString;
  filepath:string;
  pieces_section:boolean;
  tmpx,tmpy,tmprot,tmpname,tmppos:string;
  pieces:array of TPiece;
begin
  ListBox16.Clear;
  ListBox17.Clear;
  filepath:='V:/Projects/'+Edit19.Text+'/Workpieces/'+Edit3.Text+'/'+Edit3.Text+'-EDM-'+Edit16.Text+'.xmlj.txt';
  //showmessage(filepath);
  logToFile(Application.Location,'INF clicked "Detale" button');
  if FileExists(filepath) then begin
     Memo13.Lines.LoadFromFile(filepath);
     pieces_section:=false;
     setLength(pieces,0);
     tmpname:='a';
     tmpx:='0';
     tmpy:='0';
     tmprot:='0';
     tmppos:='12';
     for i:=0 to Memo13.Lines.Count-1 do begin
      if AnsiContainsStr(Memo13.Lines[i],'[PIECE') then begin
        pieces_section:=true;
      end;
      if AnsiContainsStr(Memo13.Lines[i],'[ELECTRODE_STD') then begin
        pieces_section:=false;
      end;
      if pieces_section then begin
         if AnsiContainsStr(Memo13.Lines[i],'Name=') then begin
            l:=SplitString('=',Memo13.Lines[i]);
            tmpname:=l[1];
         end;
         if AnsiContainsStr(Memo13.Lines[i],'X=') then begin
            l:=SplitString('=',Memo13.Lines[i]);
            tmpx:=l[1];
         end;
         if AnsiContainsStr(Memo13.Lines[i],'Y=') then begin
            l:=SplitString('=',Memo13.Lines[i]);
            tmpy:=l[1];
         end;
         if AnsiContainsStr(Memo13.Lines[i],'Rot=') then begin
            l:=SplitString('=',Memo13.Lines[i]);
            tmprot:=l[1];
         end;
         if AnsiContainsStr(Memo13.Lines[i],'MagPos=') then begin
            l:=SplitString('=',Memo13.Lines[i]);
            tmppos:=l[1];
            setLength(pieces,length(pieces)+1);
            pieces[high(pieces)].name:=tmpname;
            pieces[high(pieces)].x:=strtofloat(tmpx);
            pieces[high(pieces)].y:=strtofloat(tmpy);
            pieces[high(pieces)].c:=strtofloat(tmprot);
            pieces[high(pieces)].pos:=strtoint(tmppos);
         end;
      end;
  end;
  if length(pieces)>0 then begin
     logToFile(Application.Location,'There are actually '+inttostr(length(pieces))+' pieces to show!');
     Form18.pieces:=pieces;
  end;

  end;
  Form18.PaintBox1.Invalidate;
  //Form4.ShowModal;
     Form18.ShowModal;

end;

procedure TForm1.Button2Click(Sender: TObject); //elektrody...
var i,j,k:integer;
  el_exists:boolean;
  eld:TArrayOfString;
  ust:TIniFile;
  valstr,zstr:string;
begin
 BitBtn11.Click; // 1. sort by eroding depth
    BitBtn7.Click; //  2. sort by AZ
    BitBtn8.Click; //  3. then sort by Fp
  ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
      if ust.ReadString('settings','f2_ellist','magpos')='magpos' then Form2.Label10.Caption:='mag.'
      else Form2.Label10.Caption:='ilość';
  ust.Free;
  //showmessage('0 past settings');
  zstr:=';0;0;0;0;0;0';
 if ListBox2.Count>0 then begin
   for j:=0 to (ListBox2.Count-1) do begin //for each position in table
     //showmessage('1 el '+ListBox2.Items[j]);
     valstr:=';0;0;0;0;0;0;0;0;0;0;0;0;';
     if CheckBox10.Checked then begin //hypercad - get actual electrode undersizes
        if length(hcel)>0 then begin
           for i:=0 to high(hcel) do begin
             if hcel[i].name=ListBox2.Items[j] then break;
           end;
           valstr:=';'+floattostr(hcel[i].roughness_v)+';'+floattostr(hcel[i].roughness_vv)+';0;0;0;0;'+inttostr(hcel[i].number_v)+';'+inttostr(hcel[i].number_vv)+';0;0;0;0;';
         end;
     end;

     el_exists:=False; //mark electrode as not exist
     if Form2.CheckListBox1.Count>0 then begin
        for k:=0 to (Form2.CheckListBox1.Count-1) do begin //for each already known electrode
            if Form2.CheckListBox1.Items[k]=trim(ListBox2.Items[j]) then el_exists:=True; //mark electrode that already exist
        end;
     end;
     //showmessage('2 past existing check');
     if el_exists=False then begin //if electrode is marked not existing
       //showmessage('2.1 adding');
        Form2.CheckListBox1.Items.Add(trim(ListBox2.Items[j])); //add to visible list
        Form2.CheckListBox1.Checked[(Form2.CheckListBox1.Count-1)]:=True;
        if CheckBox1.Checked=False then begin
           if CheckBox4.Checked=False then Form2.ListBox1.Items.Add(trim(ListBox2.Items[j])+';'+ListBox7.Items[j]+';'+ListBox8.Items[j]+valstr+trim(ListBox2.Items[j])+';0;'+ListBox9.Items[j]+';5;0;'+ListBox12.Items[j]+zstr) //add parameters to invisible list
           else Form2.ListBox1.Items.Add(trim(ListBox2.Items[j])+';'+ListBox7.Items[j]+';'+ListBox8.Items[j]+valstr+trim(ListBox2.Items[j])+';0;'+ListBox9.Items[j]+';5;0;'+vdi_ii_to_nr(ComboBox2.ItemIndex)+zstr); // replace vdi
        end
        else begin
            if CheckBox4.Checked=False then Form2.ListBox1.Items.Add(trim(ListBox2.Items[j])+';'+ComboBox1.Items[ComboBox1.ItemIndex]+';'+ListBox8.Items[j]+valstr+trim(ListBox2.Items[j])+';0;'+ListBox9.Items[j]+';5;0;'+ListBox12.Items[j]+zstr)  // replace material if choosen so
            else Form2.ListBox1.Items.Add(trim(ListBox2.Items[j])+';'+ComboBox1.Items[ComboBox1.ItemIndex]+';'+ListBox8.Items[j]+valstr+trim(ListBox2.Items[j])+';0;'+ListBox9.Items[j]+';5;0;'+vdi_ii_to_nr(ComboBox2.ItemIndex)+zstr);  // replace material if choosen so + replace vdi
        end;
     end;
     //showmessage('2.2 adding end');
   end;
   //showmessage('0 start');
   Form2.CheckListBox1.ItemIndex:=0; //set position to first electrode
   //showmessage('1 after itemindex');
   Form2.Label11.Caption:=Edit3.Text; //copy program name
   //showmessage('2 after edit3 text');
   //try
   Form2.editel(Form2);    // load values of first electrode into fields for editing
   //except
     //on E:Exception do showmessage('AV on editel: '+E.ClassName+' - '+E.Message);
   //end;
   //showmessage('3 after editel call');
   //ProgressBar1.Position:=0; //reset progress bar
   //ProgressBar1.Max:=(Form2.ListBox1.Count)*10; //set max as number of electrodes times ten
   //showmessage('3 before Form2 ShowModal');
   if Form2.ShowModal=mrOK then begin //show filled Form2
      //change electrode material, and fP in Form1 according to changes made in Form2
      for j:=0 to Form2.ListBox1.Count-1 do begin
        eld:=SplitString(';',Form2.ListBox1.Items[j]);
        for k:=0 to ListBox2.Count-1 do begin
            if eld[0]=ListBox2.Items[k] then begin
              //showmessage(ListBox2.Items[k]+' - '+eld[1]); //debug
              ListBox7.Items[k]:=eld[1];
              ListBox8.Items[k]:=eld[2];
              ListBox12.Items[k]:=eld[20];
            end;
        end;
      end;
      Button3.Enabled:=True; //usuń dane el
      CheckBox1.Enabled:=False;
      CheckBox4.Enabled:=False;
      ComboBox1.Enabled:=False;
      ComboBox2.Enabled:=False;
   end;
 end;
end;

procedure TForm1.Button3Click(Sender: TObject); //usuń dane el.
begin
  Form2.CheckListBox1.Clear;
  Form2.ListBox1.Clear;
  Form2.Label13.Caption:='ready';
  logToFile(Application.Location,'INF deleted electrode data');
  Button3.Enabled:=False; //self disable
  CheckBox1.Enabled:=True;
      CheckBox4.Enabled:=True;
      ComboBox1.Enabled:=True;
      ComboBox2.Enabled:=True;
  setChanged(true);
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
  logToFile(Application.Location,'INF searched for next table in same drawing');
  Button1.Click;
end;

procedure TForm1.Button5Click(Sender: TObject);
//var newx,newy,oldx,oldy,oldc:real;         //debug calculation
var ss:TShiftState;
    mb:TMouseButton;
begin
   //  oldx:=strtofloat(Edit2.Text);
   //  oldy:=strtofloat(Edit4.Text);
   //  oldc:=strtofloat(Edit5.Text);
   //newx:=roundto((oldx*cos(degtorad(oldc)))-(oldy*sin(degtorad(oldc))),4);
   //newy:=roundto((oldx*sin(degtorad(oldc)))+(oldy*cos(degtorad(oldc))),4);
   // showmessage('X: '+floattostr(newx)+', Y: '+floattostr(newy));
 if ListBox9.ItemIndex>-1 then begin
   logToFile(Application.Location,'clicked direction button '+(Sender as TButton).Caption+' on electrode '+ListBox2.Items[ListBox9.ItemIndex]);
    //ListBox9.Items[ListBox9.ItemIndex]:=(Sender as TButton).Caption;
    case (Sender as TButton).Caption of
         'X+': begin
           ListBox9.Items[ListBox9.ItemIndex]:='AB';
           ListBox14.Items[ListBox9.ItemIndex]:='180';
           ListBox15.Items[ListBox9.ItemIndex]:='90';
         end;
         'X-': begin
           ListBox9.Items[ListBox9.ItemIndex]:='AB';
           ListBox14.Items[ListBox9.ItemIndex]:='0';
           ListBox15.Items[ListBox9.ItemIndex]:='90';
         end;
         'Y+': begin
           ListBox9.Items[ListBox9.ItemIndex]:='AB';
           ListBox14.Items[ListBox9.ItemIndex]:='270';
           ListBox15.Items[ListBox9.ItemIndex]:='90';
         end;
         'Y-': begin
           ListBox9.Items[ListBox9.ItemIndex]:='AB';
           ListBox14.Items[ListBox9.ItemIndex]:='90';
           ListBox15.Items[ListBox9.ItemIndex]:='90';
         end;
         'Z': begin
           ListBox9.Items[ListBox9.ItemIndex]:='Z';
           ListBox14.Items[ListBox9.ItemIndex]:='0';
           ListBox15.Items[ListBox9.ItemIndex]:='0';
         end;
    end;
    Form1.loadpos(ListBox9, mb,ss, 0,0);
 end;
end;

procedure TForm1.Button6Click(Sender: TObject);
begin
  if Form10.ShowModal=mrOK then showmessage(inttostr(Form10.TrackBar1.Position)+' '+inttostr(Form10.TrackBar2.Position));
end;

procedure TForm1.Button7Click(Sender: TObject);
var i,xc,yc,j,k,factor:integer;
  maxdim,trsize:real;
  ust:TIniFile;
  tempPos:TPoint;
  elP:Array of TPoint;
begin
   Form1.WindowState:=wsMaximized;
   Button7.Left:=20;
   Button7.Top:=5;
   Button8.Visible:=True;
   Button8.Top:=5;
   Button8.Left:=Button7.Left+Button7.Width+10;
   Button8.Caption:='Koniec';
   ListBox2.Visible:=False;
   ListBox3.Visible:=False;
   ListBox4.Visible:=False;
   ListBox5.Visible:=False;
   ListBox6.Visible:=False;
   ListBox7.Visible:=False;
   ListBox8.Visible:=False;
   ListBox9.Visible:=False;
   //ListBox10.Visible:=False;  // side eroding table - made not visible at all.
   ListBox11.Visible:=False;
   ListBox12.Visible:=False;
   //ListBox13.Visible:=False; // vdi used - visible one moved to another form
   ListBox14.Visible:=False;
   ListBox15.Visible:=False;
   PageControl1.Visible:=False;
   CheckBox1.Visible:=False;
   //CheckBox2.Visible:=False;  // reversed checkbox - now done automatically
   //CheckBox3.Visible:=False;
   CheckBox4.Visible:=False;
   //CheckBox8.Visible:=False; //dodaj skaner
   CheckBox10.Visible:=False; //HyperCAD
   Button2.Visible:=False;
   Button3.Visible:=False;
   Button5.Visible:=False;
   Button9.Visible:=False;
   Button10.Visible:=False;
   Button11.Visible:=False;
   Button12.Visible:=False;
   Button13.Visible:=False;
   Button15.Visible:=False;
   //Button4.Visible:=False; //szukaj innej tabeli
   //Button14.Visible:=False; //old wyslij
   BitBtn1.Visible:=False;
   BitBtn2.Visible:=False;
   BitBtn3.Visible:=False;
   BitBtn4.Visible:=False;
   BitBtn5.Visible:=False;
   BitBtn6.Visible:=False;
   BitBtn7.Visible:=False;
   BitBtn8.Visible:=False;
   BitBtn9.Visible:=False;
   BitBtn10.Visible:=False;
   BitBtn11.Visible:=False;
   //ProgressBar1.Visible:=False;
   Label1.Visible:=False;
   Label2.Visible:=False;
   Label3.Visible:=False;
   Label4.Visible:=False;
   Label5.Visible:=False;
   Label6.Visible:=False;
   Label7.Visible:=False;
   Label8.Visible:=False;
   Label9.Visible:=False;
   Label10.Visible:=False;
   Label11.Visible:=False;
   //Label14.Visible:=False;  //sit
   //Label15.Visible:=False;  //sit
   Label16.Visible:=False;
   Label17.Visible:=False;
   Label22.Visible:=False;
   Label23.Visible:=False;
   LabeledEdit1.Visible:=False;
   ComboBox1.Visible:=False;
   ComboBox2.Visible:=False;
   ComboBox3.Visible:=False;
   ComboBox4.Visible:=False;
   COmboBox5.Visible:=False;
   Edit1.Visible:=False;
   Edit2.Visible:=False;
   Edit3.Visible:=False;
   Edit4.Visible:=False;
   Edit5.Visible:=False;
   Edit6.Visible:=False;
   Edit7.Visible:=False;
   Edit8.Visible:=False;
   Edit9.Visible:=False;
   Edit10.Visible:=False;
   Edit15.Visible:=False;
   Edit16.Visible:=False;
   Edit17.Visible:=False;
   GroupBox1.Visible:=False;
   PaintBox1.Top:=10+Button7.Height;
   PaintBox1.Height:=Form1.Height-Button7.Height-50;
   PaintBox1.Left:=15;
   PaintBox1.Width:=Form1.Width-30;
   logToFile(Application.Location,'INF Grafickeck clicked');

   maxdim:=0;
   for i:=0 to ListBox3.Count-1 do begin
         if abs(strtofloat(ListBox3.Items[i]))>maxdim then maxdim:=abs(strtofloat(ListBox3.Items[i]))
     end;
    for i:=0 to ListBox4.Count-1 do begin
         if abs(strtofloat(ListBox4.Items[i]))>maxdim then maxdim:=abs(strtofloat(ListBox4.Items[i]))
     end;
    maxdim:=floor(maxdim)+5;
    Form1.Color:=clNavy;
    with PaintBox1.Canvas do
    begin
        Repaint;
        Pen.Style:=psSolid;
        Brush.Color:=clNavy;
        Pen.Color:=clNavy;
        Rectangle(0,0,PaintBox1.Width,PaintBox1.Height);
        Brush.Color:=clRed;
        MoveTo(floor(PaintBox1.Width/2),0);
        Pen.Color:=clRed;
        LineTo(floor(PaintBox1.Width/2),floor(PaintBox1.Height));
        MoveTo(0,floor(PaintBox1.Height/2));
        LineTo(floor(PaintBox1.Width),floor(PaintBox1.Height/2));
        j:=0;
        factor:=0;

        repeat
              inc(factor);
        until (TextWidth('-3')*2)<((factor*floor(PaintBox1.Height/2))/maxdim); //fit dimensions to the screen
        maxdim:=maxdim*factor;
         //Refresh;

        Pen.Color:=clRed;
        Brush.Color:=clRed;
        Font.Color:=clRed;
        Brush.Style:=bsClear;
        Font.Height:=48;
        TextOut(PaintBox1.Width-80,(floor(PaintBox1.Height/2))-50,'X');
        TextOut(floor(PaintBox1.Width/2)+20,10,'Y');

        ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
        if ust.ReadString('settings','GCDrawWorkPiece','1')='1' then begin //draw workpiece rectangle defined in settings
           Pen.Color:=clGreen;
           Pen.Style:=psSolid;
           Brush.Color:=clGreen;
           MoveTo(floor((PaintBox1.Width/2)+((strtofloat(ust.ReadString('settings','GCn1x','0')))*((PaintBox1.Height/2)/maxdim)*factor)),floor((PaintBox1.Height/2)+((strtofloat(ust.ReadString('settings','GCn1y','0'))*(-1))*((PaintBox1.Height/2)/maxdim)*factor)));
           LineTo(floor((PaintBox1.Width/2)+((strtofloat(ust.ReadString('settings','GCn1x','0')))*((PaintBox1.Height/2)/maxdim)*factor)),floor((PaintBox1.Height/2)+((strtofloat(ust.ReadString('settings','GCn2y','20'))*(-1))*((PaintBox1.Height/2)/maxdim)*factor)));
           LineTo(floor((PaintBox1.Width/2)+((strtofloat(ust.ReadString('settings','GCn2x','20')))*((PaintBox1.Height/2)/maxdim)*factor)),floor((PaintBox1.Height/2)+((strtofloat(ust.ReadString('settings','GCn2y','20'))*(-1))*((PaintBox1.Height/2)/maxdim)*factor)));
           LineTo(floor((PaintBox1.Width/2)+((strtofloat(ust.ReadString('settings','GCn2x','20')))*((PaintBox1.Height/2)/maxdim)*factor)),floor((PaintBox1.Height/2)+((strtofloat(ust.ReadString('settings','GCn1y','0'))*(-1))*((PaintBox1.Height/2)/maxdim)*factor)));
           LineTo(floor((PaintBox1.Width/2)+((strtofloat(ust.ReadString('settings','GCn1x','0')))*((PaintBox1.Height/2)/maxdim)*factor)),floor((PaintBox1.Height/2)+((strtofloat(ust.ReadString('settings','GCn1y','0'))*(-1))*((PaintBox1.Height/2)/maxdim)*factor)));

        end;
        ust.Free;
        repeat
              j:=j+factor;
              Pen.Color:=clRed;       // this has to be
              Brush.Color:=clRed;     // inside the loop
              Font.Color:=clRed;      // otherwise filled rectangles are drawn
              Brush.Style:=bsClear;   // instead of text
              Font.Height:=16;        // its werid, ik
              MoveTo(floor(PaintBox1.Width/2)+floor((j*factor*(PaintBox1.Height/2))/maxdim),floor(PaintBox1.Height/2)+5);
              LineTo(floor(PaintBox1.Width/2)+floor((j*factor*(PaintBox1.Height/2))/maxdim),floor(PaintBox1.Height/2)-5);
              TextOut(floor(PaintBox1.Width/2)+floor((j*factor*(PaintBox1.Height/2))/maxdim)-(TextWidth(inttostr(j))div 2),floor(PaintBox1.Height/2)+15,inttostr(j));
              MoveTo(floor(PaintBox1.Width/2)-floor((j*factor*(PaintBox1.Height/2))/maxdim),floor(PaintBox1.Height/2)+5);
              LineTo(floor(PaintBox1.Width/2)-floor((j*factor*(PaintBox1.Height/2))/maxdim),floor(PaintBox1.Height/2)-5);
              TextOut(floor(PaintBox1.Width/2)-floor((j*factor*(PaintBox1.Height/2))/maxdim)-(TextWidth('-'+inttostr(j))div 2),floor(PaintBox1.Height/2)+15,'-'+inttostr(j));
              MoveTo(floor(PaintBox1.Width/2)+5,floor(PaintBox1.Height/2)+floor((j*factor*(PaintBox1.Height/2))/maxdim));
              LineTo(floor(PaintBox1.Width/2)-5,floor(PaintBox1.Height/2)+floor((j*factor*(PaintBox1.Height/2))/maxdim));
              TextOut(floor(PaintBox1.Width/2)-10-TextWidth('-'+inttostr(j)),floor(PaintBox1.Height/2)+floor((j*factor*(PaintBox1.Height/2))/maxdim)-(TextHeight('-'+inttostr(j))div 2),'-'+inttostr(j));
              MoveTo(floor(PaintBox1.Width/2)+5,floor(PaintBox1.Height/2)-floor((j*factor*(PaintBox1.Height/2))/maxdim));
              LineTo(floor(PaintBox1.Width/2)-5,floor(PaintBox1.Height/2)-floor((j*factor*(PaintBox1.Height/2))/maxdim));
              TextOut(floor(PaintBox1.Width/2)-10-TextWidth(inttostr(j)),floor(PaintBox1.Height/2)-floor((j*factor*(PaintBox1.Height/2))/maxdim)-(TextHeight('-'+inttostr(j))div 2),inttostr(j));
        until j>maxdim;
        Pen.Color:=clYellow;
        Brush.Color:=clYellow;
        Font.Color:=clYellow;
        Brush.Style:=bsClear;
        Font.Height:=16;
        trsize:=20;
        for i:=0 to ListBox2.Count-1 do begin
            xc:=floor((strtofloat(ListBox3.Items[i])*(PaintBox1.Height/2))/maxdim)*factor;
            yc:=floor((strtofloat(ListBox4.Items[i])*(PaintBox1.Height/2))/maxdim)*factor;
            Ellipse(floor(PaintBox1.Width/2)-5+xc,floor(PaintBox1.Height/2)-5-yc,floor(PaintBox1.Width/2)+5+xc,floor(PaintBox1.Height/2)+5-yc);
            //Arc(floor(PaintBox1.Width/2)-5+xc,floor(PaintBox1.Height/2)-5-yc,floor(PaintBox1.Width/2)+5+xc,floor(PaintBox1.Height/2)+5-yc,floor(PaintBox1.Width/2)+5+xc,yc,xc,floor(PaintBox1.Height/2)+5-yc);
            MoveTo(floor(PaintBox1.Width/2)+xc,floor(PaintBox1.Height/2)-yc);
            LineTo(floor(PaintBox1.Width/2)+xc+round(sin(DegToRad(strtofloat(ListBox5.Items[i])))*trsize),floor(PaintBox1.Height/2)-yc+round(cos(DegToRad(strtofloat(ListBox5.Items[i])))*trsize));
            //littletriangle
            MoveTo(floor(PaintBox1.Width/2)+xc+round(sin(DegToRad(strtofloat(ListBox5.Items[i])))*(trsize/2)),floor(PaintBox1.Height/2)-yc+round(cos(DegToRad(strtofloat(ListBox5.Items[i])))*(trsize/2)));
            LineTo(floor(PaintBox1.Width/2)+xc+round(sin(DegToRad(strtofloat(ListBox5.Items[i])))*(trsize/2))+round(sin(DegToRad(strtofloat(ListBox5.Items[i])+90))*(trsize/4)),floor(PaintBox1.Height/2)-yc+round(cos(DegToRad(strtofloat(ListBox5.Items[i])))*(trsize/2))+round(cos(DegToRad(strtofloat(ListBox5.Items[i])+90))*(trsize/4)));
            LineTo(floor(PaintBox1.Width/2)+xc+round(sin(DegToRad(strtofloat(ListBox5.Items[i])))*trsize),floor(PaintBox1.Height/2)-yc+round(cos(DegToRad(strtofloat(ListBox5.Items[i])))*trsize));
            //side erosion offset
            //Brush.Color:=clLime;
            //Pen.Color:=clLime;
            //if ListBox9.Items[i]<>'Z' then begin
            //    MoveTo(floor(PaintBox1.Width/2)+xc,floor(PaintBox1.Height/2)-yc);
            //
            //    LineTo(0,0);
            //end;
            //Brush.Color:=clYellow;
            //Pen.Color:=clYellow;
            //electrode name
            tempPos.x:=floor(PaintBox1.Width/2)+10+xc;
            tempPos.y:=floor(PaintBox1.Height/2)-yc-10;
            for k:=0 to High(elP) do begin
               if ((abs(abs(elP[k].x)-abs(tempPos.x))<20) and (abs(abs(elP[k].y)-abs(tempPos.y))<10)) then begin
                 tempPos.y:=tempPos.y+10;
            end;
               end;
            setLength(elP,length(elP)+1);
            elP[High(elp)]:=tempPos;

            TextOut(elP[High(elP)].x,elP[High(elP)].y,ListBox2.Items[i]);


        end;
        Refresh;
    end;
end;

procedure TForm1.Button8Click(Sender: TObject);
var ust:TIniFile;
  path,hp,x400,certa:string;
begin
 ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   Form1.Color:=clDefault;
  Form1.WindowState:=wsNormal;
   Button7.Left:=302;
   Button7.Top:=56;
   Button8.Visible:=False;
   hp:=ust.readString('settings','exportAgieHP','0');
   x400:=ust.readString('settings','exportX400','0');
   certa:=ust.readString('settings','exportCERTA','0');
   ListBox2.Visible:=True;
   ListBox3.Visible:=True;
   ListBox4.Visible:=True;
   ListBox5.Visible:=True;
   ListBox6.Visible:=True;
   ListBox7.Visible:=True;
   ListBox8.Visible:=True;
   ListBox9.Visible:=True;
   ListBox11.Visible:=True;
   ListBox12.Visible:=True;
   ListBox14.Visible:=True;
   ListBox15.Visible:=True;
   CheckBox1.Visible:=True;
   //CheckBox3.Visible:=True;
   CheckBox4.Visible:=True;
   CheckBox10.Visible:=True;
   PageControl1.Visible:=True;
   if x400='1' then CheckBox8.Visible:=True;
   Button2.Visible:=True;
   Button3.Visible:=True;
   //Button4.Visible:=True; //szukaj innej tabeli
   Button5.Visible:=True;
   Button9.Visible:=True;
   Button10.Visible:=True;
   Button11.Visible:=True;
   Button12.Visible:=True;
   Button13.Visible:=True;
   Button15.Visible:=True;
   BitBtn1.Visible:=True;
   BitBtn2.Visible:=True;
   BitBtn3.Visible:=True;
   BitBtn4.Visible:=True;
   if hp='1' then BitBtn5.Visible:=True;
   if certa='1' then BitBtn6.Visible:=True;
   BitBtn7.Visible:=True;
   BitBtn8.Visible:=True;
   if x400='1' then BitBtn9.Visible:=True;
   BitBtn10.Visible:=True;
   BitBtn11.Visible:=True;
   //ProgressBar1.Visible:=True;
   Label1.Visible:=True;
   Label2.Visible:=True;
   Label3.Visible:=True;
   Label4.Visible:=True;
   Label4.Visible:=True;
   Label5.Visible:=True;
   Label6.Visible:=True;
   Label7.Visible:=True;
   Label8.Visible:=True;
   Label9.Visible:=True;
   Label10.Visible:=True;
   Label11.Visible:=True;
   //Label14.Visible:=True; //sit
   //Label15.Visible:=True; //sit
   Label16.Visible:=True;
   path:=ust.readstring('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output');
   Label17.Visible:=directoryExists(path+'\'+Edit3.Text);
   Label22.Visible:=True;
   Label23.Visible:=True;
   if x400='1' then LabeledEdit1.Visible:=True;
   ComboBox1.Visible:=True;
   ComboBox2.Visible:=True;
   ComboBox3.Visible:=True;
   ComboBox4.Visible:=True;
   COmboBox5.Visible:=True;
   Edit1.Visible:=True;
   Edit2.Visible:=True;
   Edit3.Visible:=True;
   Edit4.Visible:=True;
   Edit5.Visible:=True;
   Edit6.Visible:=True;
   Edit7.Visible:=True;
   Edit8.Visible:=True;
   Edit9.Visible:=True;
   Edit10.Visible:=True;
   Edit15.Visible:=True;
   Edit16.Visible:=True;
   Edit17.Visible:=True;
   GroupBox1.Visible:=True;
   ust.Free;
end;

procedure TForm1.Button9Click(Sender: TObject);
begin

end;

procedure TForm1.chkeckTypedDir(Sender: TObject; var Key: Word;
  Shift: TShiftState);
var is_ok:boolean;
begin
  is_ok:=false;
  case (Sender as TEdit).Text of
       'Z': is_ok:=True;
       'AB': is_ok:=True;
  end;
  if is_ok=false then (Sender as TEdit).Color:=clRed
   else (Sender as TEdit).Color:=clDefault;
  is_ok:=false;
  case (Sender as TEdit).Text of
       'AB': is_ok:=True;
  end;
  Edit10.Enabled:=is_ok;
  if (Sender as TEdit).Text='AB' then begin
      Edit7.Enabled:=True;
      Edit17.Enabled:=True;
  end
  else begin
      Edit7.Enabled:=False;
      Edit17.Enabled:=False;
  end;
end;

procedure TForm1.comatodot(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if AnsiContainsStr((Sender as TEdit).Text,',') then begin
        (Sender as TEdit).Text:=StringReplace((Sender as TEdit).Text,',','.',[rfReplaceAll]);
        (Sender as TEdit).SelStart:=high(Integer);
     end;
  if isSignedFloat((Sender as TEdit).Text) then (Sender as TEdit).color:=clDefault
  else if ((AnsiContainsStr((Sender as TEdit).Text,'+')) or (AnsiContainsStr((Sender as TEdit).Text,'-'))) then (Sender as TEdit).color:=clLime
  else (Sender as TEdit).color:=clRed;
  setChanged(true);
end;

procedure TForm1.ComboBox3Change(Sender: TObject);
begin

end;

procedure TForm1.ComboBox4Change(Sender: TObject);
begin

end;

procedure TForm1.Edit3Change(Sender: TObject);
var i,j:integer;
  matchingOrders:Array of TFifoBox;
  selectedOrder:TFifoBox;
  qal_exists,com_exists:boolean;
  actualComs:Array of TComment;
  ust:TIniFile;
  imnaz:string;
begin
  //try load order number
  if Length(Edit3.Text)=7 then begin
  setLength(matchingOrders,0);
  Form16.ListBox1.Clear;
  Shape1.Visible:=false;
  Shape2.Visible:=false;
  Label32.Visible:=false;
  Label33.Visible:=false;
  Label34.Visible:=false;
  Label35.Visible:=false;
  Label36.Visible:=false;
  Label38.Visible:=False;
  Image3.Visible:=false;
  if length(activeOrders)>0 then begin
     for i:=0 to high(activeOrders) do begin
        if Edit3.Text=activeOrders[i].identNumber then begin
           setLength(matchingOrders,length(matchingOrders)+1);
           matchingOrders[high(matchingOrders)]:=activeOrders[i];
        end;
     end;
     if ((length(matchingOrders)>0) and (length(Edit3.Text)=7)) then begin
        if length(matchingOrders)=1 then begin
          selectedOrder:=matchingOrders[0];

        end
        else begin
            for i:=0 to high(matchingOrders) do begin
               //populate new form, then show it
               Form16.ListBox1.Items.Add(matchingOrders[i].orderNumber+' - '+matchingOrders[i].fifoNumber);

            end;
            if Form16.ShowModal=mrOk then begin
               selectedOrder:=matchingOrders[Form16.ListBox1.ItemIndex];
               //Edit19.Text:=matchingOrders[Form16.ListBox1.ItemIndex].orderNumber;
               //Label30.Caption:='Czas: '+inttostr(matchingOrders[Form16.ListBox1.ItemIndex].confirmedTime)+' / '+inttostr(matchingOrders[Form16.ListBox1.ItemIndex].plannedTime);
            end;
        end;
        Edit19.Text:=selectedOrder.orderNumber;
        Edit20.Text:=inttostr(selectedOrder.quantity);
        Label30.Caption:='Czas: '+inttostr(selectedOrder.confirmedTime)+' / '+inttostr(selectedOrder.plannedTime);
        if selectedOrder.klient='ST' then begin
            Shape1.Brush.Color:=stringtoColor('$0000A3FB');
        end
        else begin
            if selectedOrder.linia='skyblue' then begin
                Shape1.Brush.Color:=clSkyBlue;
            end
            else begin
                Shape1.Brush.Color:=clLime;
            end;
        end;

        if selectedOrder.dotColor='black' then begin
          Shape2.Brush.Color:=clBlack;
        end
        else if selectedOrder.dotColor='red' then begin
          Shape2.Brush.Color:=clRed;
        end
        else if selectedOrder.dotColor='yellow' then begin
          Shape2.Brush.Color:=clYellow;
        end
        else Shape2.Brush.Color:=Shape1.Brush.Color;

        Label32.Caption:=selectedOrder.fifoNumber;
        Label33.Caption:=selectedOrder.orderNumber;
        Label34.Caption:=selectedOrder.identNumber;
        Label35.Caption:=selectedOrder.kwzNumber;
        ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
        imnaz:=ust.ReadString('settings','imnaz','none');
        if imnaz<>'none' then begin
           Label38.Visible:=true;
           if imnaz='technolog' then Label38.Caption:=selectedOrder.technolog;
           if imnaz='konstruktor' then Label38.Caption:=selectedOrder.konstruktor;
           if Label38.Caption='null' then Label38.Visible:=false;
        end;
        Label37.Visible:=selectedOrder.onMachine;
        Label39.Caption:=selectedOrder.projectSize;
        Shape3.Brush.Color:=Shape1.Brush.Color;
        if ust.ReadBool('settings','fifoSize',false) then begin
          Shape3.Visible:=True;
          Label39.Visible:=True;
        end
        else begin
           Shape3.Visible:=False;
          Label39.Visible:=False;
        end;
        ust.Free;
        Label40.Caption:='GTIS: '+selectedOrder.gtisNumber;
        Shape1.Visible:=true;
        //Shape1.Tag:=strtoint(selectedOrder.orderNumber);
        Shape2.Visible:=true;
        Label32.Visible:=true;
        Label33.Visible:=true;
        Label34.Visible:=true;
        Label35.Visible:=true;
        //info msg;
        msg_details:='Detal                   : '+selectedOrder.identNumber+' '+selectedOrder.matname+AnsiString(#13#10)+
                     'nr Fifo                 : '+selectedOrder.fifoNumber+AnsiString(#13#10)+
                     'nr Formy                : '+selectedOrder.kwzNumber+AnsiString(#13#10)+
                     'data wejścia na maszynę : '+selectedOrder.realDateEntry+AnsiString(#13#10)+
                     'MS7 Cel                 : '+selectedOrder.bm7Target+AnsiString(#13#10)+
                     'MS7 Plan                : '+selectedOrder.bm7Plan+AnsiString(#13#10)+
                     'Technolog               : '+selectedOrder.technolog+AnsiString(#13#10)+
                     'Konstruktor             : '+selectedOrder.konstruktor+AnsiString(#13#10)+
                     'Klient                  : '+selectedOrder.klient;

        //quality
        qal_exists:=false;
        for j:=0 to high(qal) do begin
            if selectedOrder.identNumber=qal[j].identNumber then begin
                qal_exists:=true;
                break;
            end;
        end;
        if qal_exists then begin
           Label36.Hint:=qal[j].comment;
           Label36.Visible:=true;
        end;
        setLength(actualComs,0);
        com_exists:=false;
        for j:=0 to high(coms) do begin
            if selectedOrder.orderNumber=coms[j].orderNumber then begin
               com_exists:=true;
               setLength(actualComs,length(actualComs)+1);
               actualComs[high(actualComs)]:=coms[j];
            end;
        end;
        if com_exists then begin
          msg_com:='Komentarze:'+AnsiString(#13#10);
          for j:=0 to high(actualComs) do begin
              msg_com:=msg_com+AnsiString(#13#10)+actualComs[j].author+': '+actualComs[j].comment;
          end;
          Image3.Visible:=true;

        end;
     end;
    end;
  end;
end;

procedure TForm1.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
  Application.Terminate;
  //MenuItem8Click(Form1);
  //logToFile('Exit','OK');

end;

procedure TForm1.FormCloseQuery(Sender: TObject; var CanClose: boolean);
var ust:TIniFile;
  lang:string;
begin
  ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
  lang:=ust.ReadString('settings','lang','PL');
  ust.Free;
   if CheckBox6.Checked then begin
     if CheckBox5.Checked then Form8.Label1.Caption:=DataModule1.getString(lang,96)+SaveDialog1.FileName+DataModule1.getString(lang,97)
     else Form8.Label1.Caption:=DataModule1.getString(lang,96);
     case Form8.ShowModal of
       mrOk: begin
           MenuItem13Click(Form1);
           CanClose:=true;
       end;
       mrCancel: begin
           CanClose:=false;
       end;
       mrClose: begin
           CanClose:=true;
       end;
  end;

   end;
   //if CanClose then Application.Terminate;
end;

procedure TForm1.FormCreate(Sender: TObject);
var ust:TIniFile;
  i,j,k,co,sleepDelay:integer;
  //dms,mcouts,mpouts,
    lang,str,strh,ds,dd,changelog:string;
  //mcurrent,mprev:TDCP_sha256;
  //mcout,mpout:array[0..31] of byte;
  sl2:TStringList;
  acl:TArrayOfString;
  exists:boolean;
  nf:TextFile;
begin
    ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
    DateTimeToString(str,'yyyy',Now());
    ds:=str+'-';
    DateTimeToString(str,'mm',Now());
    ds:=ds+str+'-';
    DateTimeToString(str,'dd',Now());
    dd:=ds+str+'_';
    ds:=ds+str+' ';
    DateTimeToString(str,'hh:nn:ss',Now());
    DateTimeToString(strh,'hh',Now());
    ds:=ds+str;
    dd:=dd+strh;
    Shape1.PopupMenu:=PopupMenu1;
    if ust.ReadString('api','lastUpd','2024-01-01_06')<>dd then begin
      //get data from api
      if not FileExists('test.bat') then begin
      //create the test.bat file
        AssignFile(nf,'test.bat');
        rewrite(nf);
        WriteLn(nf,'@echo off');
        Writeln(nf,'curl ^"http://narzedziownia.europe.phoenixcontact.com/api/fifo/list^" ^');
        Writeln(nf,'  -H ^"Accept: application/json, text/plain, */*^" ^');
        Writeln(nf,'  -H ^"Accept-Language: pl,en;q=0.9,en-GB;q=0.8,en-US;q=0.7^" ^');
        Writeln(nf,'  -H ^"Proxy-Connection: keep-alive^" ^');
        Writeln(nf,'  -H ^"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0^" ^');
        Writeln(nf,'  -H ^"credentials: include^" ^');
        Writeln(nf,'  -H ^"mode: cors^" --negotiate -u : -o out.txt');
        Writeln(nf,'curl ^"http://narzedziownia.europe.phoenixcontact.com/api/quality^" ^');
        Writeln(nf,'  -H ^"Accept: application/json, text/plain, */*^" ^');
        Writeln(nf,'  -H ^"Accept-Language: pl,en;q=0.9,en-GB;q=0.8,en-US;q=0.7^" ^');
        Writeln(nf,'  -H ^"Proxy-Connection: keep-alive^" ^');
        Writeln(nf,'  -H ^"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0^" ^');
        Writeln(nf,'  -H ^"credentials: include^" ^');
        Writeln(nf,'  -H ^"mode: cors^" --negotiate -u : -o qal.txt');
        Writeln(nf,'curl ^"http://narzedziownia.europe.phoenixcontact.com/api/comment^" ^');
        Writeln(nf,'  -H ^"Accept: application/json, text/plain, */*^" ^');
        Writeln(nf,'  -H ^"Accept-Language: pl,en;q=0.9,en-GB;q=0.8,en-US;q=0.7^" ^');
        Writeln(nf,'  -H ^"Proxy-Connection: keep-alive^" ^');
        Writeln(nf,'  -H ^"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0^" ^');
        Writeln(nf,'  -H ^"credentials: include^" ^');
        Writeln(nf,'  -H ^"mode: cors^" --negotiate -u : -o com.txt');
        CloseFile(nf);
      end;
      sleepDelay:=500;
      Sleep(sleepDelay);
      co:=0;
      if FileExists('out.txt') then DeleteFile('out.txt');
      Sleep(sleepDelay);
      if FileExists('qal.txt') then DeleteFile('qal.txt');
      Sleep(sleepDelay);
      if FileExists('com.txt') then DeleteFile('com.txt');
      Sleep(sleepDelay);

      ShellExecute(0,'OPEN',Pchar('test.bat'),'','',SW_HIDE);
      repeat
         Sleep(sleepDelay);
         inc(co);
      until ((FileExists('out.txt') and FileExists('qal.txt') and FileExists('com.txt')) or (co>=150));
      Sleep(sleepDelay);
      DeleteFile('test.bat');
      ust.WriteString('api','lastUpd',dd);
    end;
    if FileExists('out.txt') then begin
       logToFile(Application.Location,'OK Loaded data from API, after '+floattostr((co*500)/1000)+'s');
       getActiveOrders;
       getQual;
       getComs;
    end
    else logToFile(Application.Location,'ERR Error getting file from API');

    sizeset:=false;
    Form1.resizemainf(Form1);
    sw_ver:='27';
    sw_ver_minor:='1';

    if not FileExists(Application.Location+'upd.exe') then FileUtil.CopyFile('P:\edmpgm\upd.exe',Application.Location+'upd.exe',[cffPreserveTime],true);

    ImageList1.AddLazarusResource('open-file');  //0
    ImageList1.AddLazarusResource('new file');   //1
    ImageList1.AddLazarusResource('Help');       //2
    ImageList1.AddLazarusResource('Save');       //3
    ImageList1.AddLazarusResource('Settings');   //4
    ImageList1.AddLazarusResource('Information');//5
    ImageList1.AddLazarusResource('dxf-file');   //6
    ImageList1.AddLazarusResource('File-info');  //7
    Imagelist1.AddLazarusResource('seb_ic');     //8
    Imagelist1.AddLazarusResource('Printer');    //9

    BitBtn1.LoadGlyphFromLazarusResource('Copy');
    BitBtn2.LoadGlyphFromLazarusResource('Remove');
    BitBtn3.LoadGlyphFromLazarusResource('Edit-validated');
    BitBtn4.LoadGlyphFromLazarusResource('Add');

    //change strings to language selected in settings
    lang:=ust.ReadString('settings','lang','PL');
    vm:=strtoint(ust.ReadString('settings','verboseMode','1'));
    //mainmenu
    MenuItem7.Caption:=DataModule1.getString(lang,0); //plik
    MenuItem1.Caption:=DataModule1.getString(lang,1); //opcje
    MenuItem2.Caption:=DataModule1.getString(lang,2); //pomoc
    MenuItem8.Caption:=DataModule1.getString(lang,3); //nowy
    MenuItem17.Caption:=DataModule1.getString(lang,4); //import
    MenuItem18.Caption:=DataModule1.getString(lang,5); //export
    MenuItem10.Caption:=DataModule1.getString(lang,6); //otw edf
    MenuItem13.Caption:=DataModule1.getString(lang,7); //zapisz
    MenuItem11.Caption:=DataModule1.getString(lang,8); //zapisz jako
    MenuItem15.Caption:=DataModule1.getString(lang,9); //druk tabele
    MenuItem12.Caption:=DataModule1.getString(lang,10); //zakoncz
    MenuItem5.Caption:=DataModule1.getString(lang,11); //ustawienia
    MenuItem6.Caption:=DataModule1.getString(lang,12); //log
    MenuItem3.Caption:=DataModule1.getString(lang,13); //about
    MenuItem4.Caption:=DataModule1.getString(lang,14); //jak uzywac
    MenuItem16.Caption:=DataModule1.getString(lang,15); //otw istniejacy
    MenuItem14.Caption:=DataModule1.getString(lang,16); //import csv
    MenuItem9.Caption:=DataModule1.getString(lang,17); //import dxf
    MenuItem19.Caption:=DataModule1.getString(lang,18); //export agievision
    MenuItem20.Caption:=DataModule1.getString(lang,19); //export hmi
    MenuItem21.Caption:=DataModule1.getString(lang,20); //export certa
    //form1
    CheckBox1.Caption:=DataModule1.getString(lang,21); //zastąp material elektrody
    CheckBox4.Caption:=DataModule1.getString(lang,22); //zastąp jakosc pow
    Label22.Caption:=DataModule1.getString(lang,23); //mat det
    Label2.Caption:=DataModule1.getString(lang,24); //nazwa programu
    CheckBox3.Caption:=DataModule1.getString(lang,25); //utw grupę
    CheckBox3.Hint:=DataModule1.getString(lang,26)+AnsiSTring(#10)+DataModule1.getString(lang,27); //utw grupę hint
    Label17.Caption:=DataModule1.getString(lang,28); //już istnieje
    GroupBox1.Caption:=DataModule1.getString(lang,29); // odleglosc referencje -> punkt pom
    LabeledEdit1.EditLabel.Caption:=DataModule1.getString(lang,30); //pos detaliw w mag
    CheckBox8.Caption:=DataModule1.getString(lang,31); //dodaj skaner
    Button3.Caption:=DataModule1.getString(lang,32); //usun dane el
    Button2.Caption:=DataModule1.getString(lang,33); //elektrody...
    Button4.Caption:=DataModule1.getString(lang,34); //szukaj innej tabeli
    Label3.Caption:=DataModule1.getString(lang,35); //sortuj
    Label1.Caption:=DataModule1.getString(lang,36); //nazwa
    ListBox8.Hint:=DataModule1.getString(lang,37)+AnsiSTring(#10)+DataModule1.getString(lang,38); //fp hint
    Edit8.Hint:=ListBox8.Hint;
    Label9.Hint:=ListBox8.Hint;
    OpenDialog3.Title:=DataModule1.getString(lang,39); //open dialog from cmm
    Button8.Caption:=DataModule1.getString(lang,40);
    LabeledEdit1.Hint:=DataModule1.getString(lang,41)+AnsiString(#10)+'ITS50: 1,2,3,4,5,6,7,8,9,10,11,12'+AnsiSTring(#10)+'ITS148: 13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48';
    Edit16.Hint:=DataModule1.getString(lang,42); //ai
    Label11.Hint:=Edit16.Hint;
    BitBtn4.Hint:=DataModule1.getString(lang,43); //dodaj linie
    BitBtn3.Hint:=DataModule1.getString(lang,44); //akceptuj zmiany
    BitBtn1.Hint:=DataModule1.getString(lang,45); //kopiuj linie
    BitBtn2.Hint:=DataModule1.getString(lang,46); //usun linie
    BitBtn10.Hint:=DataModule1.getString(lang,47); //kopiuj wszystkie
    sl2:=TStringList.Create;
    sl2.Add(DataModule1.getString(lang,48)+' HP');
    //sl2.Add('Hyperspark');
    //SetWindowLong(BitBtn5.Handle, GWL_STYLE, BS_MULTILINE);
    BitBtn5.Caption:=sl2.Text;
    BitBtn6.Caption:=DataModule1.getString(lang,48)+' CERTA';
    Edit9.Hint:=DataModule1.getString(lang,95)+AnsiString(#10)+'Z'+AnsiString(#10)+'AB';
    //showmessage('test1');

    Edit15.Text:=ds;
    //showmessage('test3');
    //LEGACY, no longer used
    end_table_line:=0;
    plsr12sc:=False;
    tableno:=0; //abount of tables
    errorlevel:=0; //for dxf, max 4
    //END LEGACY

    SpinEdit1.Value:=strtoint(ust.ReadString('settings','defaultNoOfRows','10'));
    OpenDialog3.InitialDir:=ust.ReadString('settings','pathMES','C:\korekty\AGIEVISION_2');
    OpenDialog1.InitialDir:=ust.ReadString('settings','pathDXF','C:\Intel\LazarusPortable\dxf test');
    SaveDialog1.InitialDir:=ust.ReadString('settings','pathVDM','C:\VDM');
    OpenDialog2.InitialDir:=ust.ReadString('settings','pathVDM','C:\VDM');
    OpenDialog4.InitialDir:=ust.ReadString('settings','pathCSV','C:\VDM');
    SaveDialog2.InitialDir:=ust.ReadString('settings','pathCSVexport','C:\VDM');
    SaveDialog3.InitialDir:=ust.ReadString('settings','pathXMLJ','C:\XMLJ');
    OpenDialog7.InitialDir:=ust.ReadString('settings','pathCSV','C:\VDM');
    ComboBox5.ItemIndex:=elmatii_input(ust.ReadString('settings','defaultElectrodeMaterial','Graphite2'));
    Edit10.Text:=ust.ReadString('settings','defaultSideOffset','5');
    Edit13.Text:=ust.ReadString('settings','defaultZOffset','0');
    ComboBox4.ItemIndex:=strtoint(ust.ReadString('settings','defaultPieceMaterial','0'));
    ComboBox1.ItemIndex:=elmatii_input(ust.ReadString('settings','defaultElectrodeMaterial','Graphite2'));
    if ust.ReadString('settings','preCalculatedElectrodeData','1')='1' then CheckBox9.Checked:=true
    else CheckBox9.Checked:=false;

    Form1.Width:=1302; // old: 1140. old old: 1002
    Form1.Height:=460; // old: 356

    //computer name
    MenuItem22.Caption:=Sysutils.GetEnvironmentVariable('COMPUTERNAME');
    //Check for allowed computers
    acl:=SplitString(',',ust.ReadString('lic','allowedComputers','PXCW-M2043,PXCW-D0626,PXCW-D0500,PXCW-M2174,PXCW-M2194,PXCW-D0880'));
    exists:=false;
    for j:=0 to high(acl) do begin
        if acl[j]=MenuItem22.Caption then begin
            exists:=true;
            break;
        end;
    end;
    if not exists then Application.Terminate;
    //export buttons positioning
    //shuffle_buttons;
    Label25.Caption:=ust.ReadString('settings','xmljVersion','7.5.0');
    Label31.Caption:=Label25.Caption;
    allowWpPos:=SplitString(',',ust.ReadString('mag','workpiece','1,2,3'));
    LabeledEdit1.Text:=allowWpPos[0]+','+allowWpPos[1];
    LabeledEdit1.Hint:='Poprawne pozycje magazynu:'+AnsiString(#13#10);
    for i:=0 to high(allowWpPos) do begin
        LabeledEdit1.Hint:=LabeledEdit1.Hint+allowWpPos[i];
        if i<>high(allowWpPos) then LabeledEdit1.Hint:=LabeledEdit1.Hint+', ';
    end;
    Memo7.Clear;
    //if FileExists(ust.ReadString('mag','chipDBLocation','P:\lus\s1\chipdb.txt')) then begin
    //   Memo7.Lines.LoadFromFile(ust.ReadString('mag','chipDBLocation','P:\lus\s1\chipdb.txt')) ;
    //   logToFile('Chip BD loaded ('+inttostr(Memo7.Lines.Count)+')','OK');
    //end
    //else begin
    //    logToFile('Error Loading Chip DB','ERR');
    //    if vm>=2 then showmessage('Nie można załadować bazy danych chipów!');
    //end;
    PageControl1.PageIndex:=ust.ReadInteger('form','page',0);
    ust.Free;

    if FileExists('P:\edmpgm\version.txt') then begin
       Memo9.Lines.LoadFromFile('P:\edmpgm\version.txt');
       changelog:='';
       if Memo9.Lines.Count>1 then begin

         k:=0;
         repeat
            inc(k);
            changelog:=changelog+AnsiString(#13#10)+Memo9.Lines[k];
         until Memo9.Lines[k]='';

       end;
       if Memo9.Lines[0]<>sw_ver+'.'+sw_ver_minor then begin
          if MessageDlg('Dostępna nowa wersja!',changelog+AnsiString(#13#10)+AnsiString(#13#10)+'Czy wykonac aktualizacje?',mtConfirmation,[mbYes,mbNo],0)=mrYes then begin
             ShellExecute(0, 'open', PChar(Application.Location+'upd.exe'),nil,nil,SW_HIDE);
             Sleep(100);
             Halt(0);
          end;
          //showmessage('Dostępna nowa wersja!'+changelog);

       end;
    end;

    logToFile(Application.Location,'OK program opened v'+sw_ver+'.'+sw_ver_minor);
    setChanged(False);

end;

procedure TForm1.FormPaint(Sender: TObject);
begin

end;

procedure TForm1.handleparams(Sender: TObject);
begin
  if ParamCount>0 then begin
         if ExtractFileExt(ParamStr(1))='.edf' then load_edf(ParamStr(1)) //own save file format
         else if ExtractFileExt(ParamStr(1))='.csv' then load_csv(ParamStr(1)) //generated by SEB module
         else if ExtractFileExt(ParamStr(1))='.xml' then load_hypercad(ParamStr(1)) //ElectrodeMaterial from NcVisu2
         else if ExtractFileExt(ParamStr(1))='.xmlj' then load_xmlj(ParamStr(1)) // sparking program for HMI software
         else if ExtractFileExt(ParamStr(1))='.JOB' then load_agievision(ParamStr(1)) // sparking program AgieVision
         else begin //read as .dxf/.mi (legacy system)
         OpenDialog1.FileName:=ParamStr(1);
         Button1.Click;
         end;
    end;
end;

procedure TForm1.hcch(Sender: TObject);
begin
  //hyper cad selection change
  if CheckBox10.Checked then begin
    Edit18.Visible:=true;
    Edit18.Text:='0050_';
  end
  else begin
      Edit18.Visible:=false;
      Edit18.Text:='';
  end;
end;

procedure TForm1.hp2(Sender: TObject; const FileNames: array of String);
begin
   OpenDialog1.FileName:=FileNames[1];
   Button1.Click;
end;

procedure TForm1.Image3Click(Sender: TObject);
begin
  MessageDlg('Komenarze do zlecenia',msg_com,mtInformation,[mbOk],0);
end;

procedure TForm1.Label36Click(Sender: TObject);
begin
  MessageDlg('Alarm Jakościowy',(Sender as TLabel).Hint,mtWarning,[mbOk],0);
end;

procedure TForm1.ListBox11Click(Sender: TObject);
begin

end;


procedure TForm1.loadpos(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var is_ok:boolean;
begin
  if (Sender as TListBox).ItemIndex>=0 then begin
  ListBox2.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox3.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox4.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox5.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox6.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox7.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox8.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox9.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox11.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox12.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox14.ItemIndex:=(Sender as TListBox).ItemIndex;
  ListBox15.ItemIndex:=(Sender as TListBox).ItemIndex;

   Edit1.Text:=ListBox2.Items[(Sender as TListBox).ItemIndex];
   Edit2.Text:=ListBox3.Items[(Sender as TListBox).ItemIndex];
   Edit4.Text:=ListBox4.Items[(Sender as TListBox).ItemIndex];
   Edit5.Text:=ListBox5.Items[(Sender as TListBox).ItemIndex];
   Edit6.Text:=ListBox6.Items[(Sender as TListBox).ItemIndex];
   ComboBox5.Itemindex:=elmatii_input(ListBox7.Items[(Sender as TListBox).ItemIndex]);
  // Edit7.Text:=ListBox7.Items[(Sender as TListBox).ItemIndex];
   Edit8.Text:=ListBox8.Items[(Sender as TListBox).ItemIndex];
   Edit9.Text:=ListBox9.Items[(Sender as TListBox).ItemIndex];
   Edit10.Text:=ListBox11.Items[(Sender as TListBox).ItemIndex];
   ComboBox3.ItemIndex:=vdi_nr_to_ii(ListBox12.Items[(Sender as TListBox).ItemIndex]);
   is_ok:=false;
  case Edit9.Text of
       'X+': is_ok:=True;
       'X-': is_ok:=True;
       'Y+': is_ok:=True;
       'Y-': is_ok:=True;
       '+X': is_ok:=True;
       '-X': is_ok:=True;
       '+Y': is_ok:=True;
       '-Y': is_ok:=True;
       'AB': is_ok:=True; //new: direction defined in fields A and B instead of dir
  end;
  Edit10.Enabled:=is_ok;
  Edit7.Text:=ListBox14.Items[(Sender as TListBox).ItemIndex];
  Edit17.Text:=ListBox15.Items[(Sender as TListBox).ItemIndex];
  If Edit9.Text='AB' then begin
      Edit7.Enabled:=True;
      Edit17.Enabled:=True;
  end
  else begin
      Edit7.Enabled:=False;
      Edit17.Enabled:=False;
  end;
   //
  end;
end;

procedure TForm1.MenuItem10Click(Sender: TObject);
begin
  if OpenDialog2.Execute then begin
     load_edf(OpenDialog2.FileName);
     logToFile(Application.Location,'OK Loaded EDF manually');
  end;
end;

procedure TForm1.MenuItem11Click(Sender: TObject);
begin
  SaveDialog1.FileName:=Edit3.Text;
  if SaveDialog1.Execute then begin
  CheckBox5.Checked:=True; //mark this file is already 'saved as'
  Form1.Caption:='EDMPGM ['+SaveDialog1.FileName+']';
  MenuItem13Click(Form1);
  end;
end;

procedure TForm1.MenuItem12Click(Sender: TObject);
begin
  logToFile(Application.Location,'INF Closed by menu option. (strange)');
  Application.Terminate;
end;

procedure TForm1.MenuItem13Click(Sender: TObject);
var pvdm:TextFile;
  i:integer;
  chc:string;
begin
  if CheckBox5.Checked then begin
      AssignFile(pvdm,SaveDialog1.FileName);
     Rewrite(pvdm);
     writeln(pvdm,'DXF2AGIEHPv'+sw_ver);
     //form1
     if CheckBox1.Checked then writeln(pvdm,'zme:1') //overwrite electrode material
     else writeln(pvdm,'zme:0');
     if CheckBox4.Checked then writeln(pvdm,'zjp:1') //overwrite surface quality
     else writeln(pvdm,'zjp:0');
     writeln(pvdm,'matel:'+inttostr(ComboBox1.ItemIndex));
     writeln(pvdm,'vdisel:'+inttostr(ComboBox2.ItemIndex));
     writeln(pvdm,'matdet:'+inttostr(ComboBox4.ItemIndex));
     writeln(pvdm,'prname:'+Edit3.Text);
     if CheckBox3.Checked then writeln(pvdm,'crgr:1') //create group, for AgieVision only
     else writeln(pvdm,'crgr:0');
     writeln(pvdm,'odlx:'+Edit11.Text);
     writeln(pvdm,'odly:'+Edit12.Text);
     writeln(pvdm,'odlz:'+Edit13.Text);
     writeln(pvdm,'odlc:'+Edit14.Text);
     writeln(pvdm,'ilekol:'+inttostr(SpinEdit1.Value));
     writeln(pvdm,'wp_amount:'+Edit20.Text);
     writeln(pvdm,'name_cd:'+Edit18.Text);
     for i:=0 to ListBox1.Count-1 do writeln(pvdm,'lbpwt:'+ListBox1.Items[i]);
     for i:=0 to ListBox2.Count-1 do writeln(pvdm,'lbname:'+ListBox2.Items[i]);
     for i:=0 to ListBox3.Count-1 do writeln(pvdm,'lbx:'+ListBox3.Items[i]);
     for i:=0 to ListBox4.Count-1 do writeln(pvdm,'lby:'+ListBox4.Items[i]);
     for i:=0 to ListBox5.Count-1 do writeln(pvdm,'lbc:'+ListBox5.Items[i]);
     for i:=0 to ListBox6.Count-1 do writeln(pvdm,'lbz:'+ListBox6.Items[i]);
     for i:=0 to ListBox7.Count-1 do writeln(pvdm,'lbmat:'+ListBox7.Items[i]);
     for i:=0 to ListBox8.Count-1 do writeln(pvdm,'lbfp:'+ListBox8.Items[i]);
     for i:=0 to ListBox9.Count-1 do writeln(pvdm,'lbdirb:'+ListBox9.Items[i]);
     for i:=0 to ListBox11.Count-1 do writeln(pvdm,'lbodsb:'+ListBox11.Items[i]);
     for i:=0 to ListBox12.Count-1 do writeln(pvdm,'lbvdi:'+ListBox12.Items[i]);
     for i:=0 to ListBox14.Count-1 do writeln(pvdm,'lba:'+ListBox14.Items[i]);
     for i:=0 to ListBox15.Count-1 do writeln(pvdm,'lbb:'+ListBox15.Items[i]);
     writeln(pvdm,'date:'+Edit15.Text); //creation date - not sent to machines
     writeln(pvdm,'ai:'+Edit16.Text); //revision of source drawing - not sent to machines
     //added in v17
     writeln(pvdm,'magpos_x400:'+LabeledEdit1.Text); //Magazine positions of pieces for X400
     //added in v18
     if CheckBox7.Checked then writeln(pvdm,'generated:1') //csv generated by dxf2agie
     else writeln(pvdm,'generated:0');                     //generated by SEB
     if CheckBox8.Checked then writeln(pvdm,'dodsk:1')    //add scanner when creating program for X400
     else writeln(pvdm,'dodsk:0');
     if CheckBox10.Checked then writeln(pvdm, 'hypercad:1')
     else writeln(pvdm, 'hypercad:0');
     //added in v25
     writeln(pvdm,'order:'+Edit19.Text);
     //form2
     writeln(pvdm,'eld:'+Form2.Label13.Caption);
     for i:=0 to Form2.ListBox1.Count-1 do writeln(pvdm,'lbf21:'+Form2.ListBox1.Items[i]);
     for i:=0 to Form2.ListBox2.Count-1 do writeln(pvdm,'lbf22:'+Form2.ListBox2.Items[i]);
     for i:=0 to Form2.CheckListBox1.Count-1 do begin
        if Form2.CheckListBox1.Checked[i] then chc:='1'
        else chc:='0';
        writeln(pvdm,'clbf2:'+Form2.CheckListBox1.Items[i]+':'+chc);
     end;
     if Form2.Edit16.Enabled then writeln(pvdm,'zbyhand:1')
     else writeln(pvdm,'zbyhand:0');


     logToFile(Application.Location,'OK Saved EDF '+SaveDialog1.FileName);
     CloseFile(pvdm);
     setChanged(false);
  end
  else MenuItem11Click(Form1);
end;

procedure TForm1.MenuItem14Click(Sender: TObject);
var ust:TIniFile;
begin
  ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
  OpenDialog4.InitialDir:=ust.ReadString('settings','pathCSV','C:\');
  ust.Free;
   if OpenDialog4.Execute then load_csv(OpenDialog4.FileName);
end;

function interline:string;
 begin
     Result:='├───────────┼───────────┼───────────┼───────────┼───────────┼──────┼──────────┤';
 end;

procedure TForm1.MenuItem15Click(Sender: TObject);
var i,j,add_sp:integer;
fil:TextFile;
ml:boolean;
ust:TIniFile;
lang:string;
begin
    ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
    lang:=ust.ReadString('settings','lang','PL');
    if ust.ReadString('settings','moreInterlines','1')='1' then ml:=true
    else ml:=false;
    AssignFile(fil,Application.Location+'\tabela.txt');
    Rewrite(fil);
    writeln(fil,DataModule1.GetString(lang,101)+' '+Edit3.Text+'/'+Edit16.Text+' ('+FormatDateTime('yyyy-mm-dd HH:nn:ss',Now)+')');
    writeln(fil,'┌───────────┬───────────┬───────────┬───────────┬───────────┬──────┬──────────┐');
    writeln(fil,'│ Elektroda │     X     │     Y     │     C     │     Z     │  dir │    Fp    │');
    if not ml then writeln(fil,interline()); //'not' condtion to avoid double lines;
    for i:=0 to ListBox2.Count-1 do begin
         if ml then writeln(fil,interline());
         write(fil,'│');
         write(fil,ListBox2.Items[i]);
         for j:=length(ListBox2.Items[i]) to 10 do write(fil,' ');
         write(fil,'│');
         if abs(strtofloat(ListBox3.Items[i]))<1 then add_sp:=2
         else add_sp:=2-floor(log10(abs(strtofloat(ListBox3.Items[i]))));
         if ListBox3.Items[i]='-0.0000' then add_sp:=add_sp-1;
         if strtofloat(ListBox3.Items[i])>=0 then write(fil,' ');
         for j:=0 to add_sp do write(fil,' ');
         write(fil,ListBox3.Items[i]);
         for j:=length(ListBox3.Items[i]) to (8-add_sp) do write(fil,' ');
         if strtofloat(ListBox3.Items[i])<0 then write(fil,' ');
         write(fil,'│');
         if abs(strtofloat(ListBox4.Items[i]))<1 then add_sp:=2
         else add_sp:=2-floor(log10(abs(strtofloat(ListBox4.Items[i]))));
         if ListBox4.Items[i]='-0.0000' then add_sp:=add_sp-1;
         if strtofloat(ListBox4.Items[i])>=0 then write(fil,' ');
         for j:=0 to add_sp do write(fil,' ');
         write(fil,ListBox4.Items[i]);
         for j:=length(ListBox4.Items[i]) to (8-add_sp) do write(fil,' ');
         if strtofloat(ListBox4.Items[i])<0 then write(fil,' ');
         write(fil,'│');
         if abs(strtofloat(ListBox5.Items[i]))<1 then add_sp:=2
         else add_sp:=2-floor(log10(abs(strtofloat(ListBox5.Items[i]))));
         if strtofloat(ListBox5.Items[i])>=0 then write(fil,' ');
         for j:=0 to add_sp do write(fil,' ');
         write(fil,ListBox5.Items[i]);
         for j:=length(ListBox5.Items[i]) to (8-add_sp) do write(fil,' ');
         if strtofloat(ListBox5.Items[i])<0 then write(fil,' ');
         write(fil,'│');
         if abs(strtofloat(ListBox6.Items[i]))<1 then add_sp:=2
         else add_sp:=2-floor(log10(abs(strtofloat(ListBox6.Items[i]))));
         for j:=0 to add_sp do write(fil,' ');
         write(fil,ListBox6.Items[i]);
         for j:=length(ListBox6.Items[i]) to (9-add_sp) do write(fil,' ');
         write(fil,'│ '+ListBox9.Items[i]);
         for j:=length(ListBox9.Items[i]) to 4 do write(fil,' ');
         write(fil,'│ ');
         //add_sp:=2-(1+floor(log10(strtofloat(ListBox8.Items[i]))));
         //showmessage(inttostr(add_sp));
         //for j:=1 to add_sp do write(fil,' ');
         write(fil,ListBox8.Items[i]);
         for j:=length(ListBox8.Items[i]) to 8 do write(fil,' ');
         writeln(fil,'│');
    end;
    writeln(fil,'└───────────┴───────────┴───────────┴───────────┴───────────┴──────┴──────────┘');
    CloseFile(fil);
    SysUtils.ExecuteProcess('notepad.exe','"'+Application.Location+'\tabela.txt"'); //open generated file in notepad
end;

procedure TForm1.MenuItem16Click(Sender: TObject);
var fil,jor,fut:TextFile;
lin,el_str:string;
t0,t1,t2,unam,ufil,uele,uemat,bea_nam,bea_vdi,ufp:TArrayOfString;
el_pos: Array of TArrayOfString;
el_um: Array of TArrayOfString;
i,j:integer;
sp_x,sp_y,sp_z:real;
begin
  if OpenDialog5.Execute then begin
     if ExtractFileExt(OpenDialog5.FileName)='.xmlj' then begin
        load_xmlj(OpenDialog5.FileName);
     end
     else if ExtractFileExt(OpenDialog5.FileName)='.JOB' then begin  //Load program for AgieVision
         //solve USING varribles
         AssignFile(jor,ChangeFileExt(OpenDialog5.FileName,'.JOR'));
         reset(jor);
         SetLength(unam,1); // electrode using_x
         SetLength(ufil,1); // electrode filename
         SetLength(uele,1); // electrode long name
         SetLength(uemat,1); // electrode material
         SetLength(bea_nam,1); // agie.bea_x
         SetLength(bea_vdi,1); // vdi number only, ex. 26
         SetLength(ufp,1); // electrode fp
         SetLength(el_pos,0);
         SetLength(el_um,0);
         repeat
               readln(jor,lin);
               if AnsiContainsStr(lin,'.FUT') then begin  //look for electrode files
                   t0:=SplitString(' ',lin);
                   SetLength(unam,length(unam)+1);
                   unam[length(unam)-1]:=t0[0]; //save usung_x name
                   SetLength(ufil,length(ufil)+1);
                   SetLength(t0[3],length(t0[3])-1);
                   ufil[length(ufil)-1]:=t0[3]; //save filename of fut file
               end;
               if AnsiContainsStr(lin,'.BEA_') then begin
                  t0:=SplitString(' ',lin);
                  SetLength(bea_nam,length(bea_nam)+1);
                  bea_nam[length(bea_nam)-1]:=t0[0];
                  t1:=SplitString('_',t0[3]);  // t0[3] example: VDI_22Ra1.26oxxo,1,$,
                  t2:=SplitString('R',t1[1]);
                  SetLength(bea_vdi,length(bea_vdi)+1);
                  bea_vdi[length(bea_vdi)-1]:=t2[0];
               end;
               // .TEK line is ignored
         until eof(jor);
         CloseFile(jor);
         //match electrode name to using_x
         for i:=1 to length(ufil)-1 do begin
             if FileExists(ExtractFilePath(OpenDialog5.FileName)+ufil[i]) then begin
                SetLength(el_pos,length(el_pos)+1);
                SetLength(el_um,length(el_um)+1);

                 AssignFile(fut,ExtractFilePath(OpenDialog5.FileName)+ufil[i]);
                 reset(fut);
                 readln(fut,lin);
                 readln(fut,lin);
                 t0:=SplitString(',',lin);
                 if t0[0]='F' then begin
                    SetLength(uele,length(uele)+1);
                    uele[length(uele)-1]:=t0[1];
                    t1:=SplitString(';',t0[26]);
                    SetLength(uemat,length(uemat)+1);
                    uemat[length(uemat)-1]:=t1[11];
                    SetLength(ufp,length(ufp)+1);
                    ufp[length(ufp)-1]:=t0[9];
                 end;
                 //extract undersizes and magazine positions
                 repeat
                    readln(fut,lin);
                    t0:=SplitString(',',lin);
                    if t0[0]='U' then begin
                       SetLength(el_um[High(el_um)],length(el_um[High(el_um)])+1);
                       el_um[High(el_um)][High(el_um[High(el_um)])]:=t0[6];
                       SetLength(el_pos[High(el_pos)],length(el_pos[High(el_pos)])+1);
                       el_pos[High(el_pos)][High(el_pos[High(el_pos)])]:=t0[4];
                    end;
                 until eof(fut);
                 CloseFile(fut);

             end
             else begin
                 logToFile(Application.Location,'ERR Cannot find file with electrode definition ('+ufil[i]+') - this should never happen');
                  showmessage('Nie znaleziono pliku z definicją elektrody ('+ufil[i]+')');
             end;
         end;
         //showmessage('ok1');
         //showmessage(inttostr(length(el_pos))+AnsiString(#13#10)+inttostr(length(el_pos[0])));
         AssignFile(fil,OpenDialog5.FileName);
         reset(fil);
          //Clear listboxes
          ListBox2.Clear;
          ListBox3.Clear;
          ListBox4.Clear;
          ListBox5.Clear;
          ListBox6.Clear;
          ListBox7.Clear;
          ListBox8.Clear;
          ListBox9.Clear;
          ListBox11.Clear;
          ListBox12.Clear;
          ListBox14.Clear;
          ListBox15.Clear;
          //showmessage('ok1');
         repeat
          readln(fil,lin);

          t0:=SplitString(',',lin);
          //showmessage(lin+AnsiString(#13#10)+t0[0]);
          if t0[0]='W' then begin
             Edit3.Text:=t0[1]; //program name
             Edit11.Text:=floattostr(strtofloat(t0[17])*(-1)); //ods x
              Edit12.Text:=floattostr(strtofloat(t0[18])*(-1)); //ods y
              Edit13.Text:=floattostr(strtofloat(t0[19])*(-1)); //ods z
              Edit14.Text:=t0[22]; //ods c
          end;

          //read X Y and C from Machining
          if t0[0]='A' then begin
             CheckBox3.Checked:=False; //utw grupe nie
             ListBox3.Items.Add(t0[2]); //x
             ListBox4.Items.Add(t0[3]); //y
             ListBox5.Items.Add(t0[7]); //c

             for i:=1 to length(unam)-1 do begin
                 if unam[i]=t0[23] then begin
                    ListBox2.Items.Add(uele[i]);
                    ListBox7.Items.Add(agie_elmat_to_str(uemat[i]));
                    ListBox8.Items.Add(ufp[i]);
                 end;
             end;
             for i:=1 to length(bea_nam)-1 do begin
                 if bea_nam[i]=t0[28] then begin
                    ListBox12.Items.Add('VDI'+bea_vdi[i]);
                 end;
             end;
          end;
          if t0[0]='R' then begin
             CheckBox3.Checked:=True;  //utw grupe tak
             ListBox3.Items.Add(t0[2]); //x
             ListBox4.Items.Add(t0[3]); //y
             ListBox5.Items.Add(t0[7]); //c

             ListBox11.Items.Add(Edit10.Text); //fromdistance

             for i:=1 to length(unam)-1 do begin
                 if unam[i]=t0[23] then begin
                    ListBox2.Items.Add(uele[i]);
                    ListBox7.Items.Add(agie_elmat_to_str(uemat[i]));
                    ListBox8.Items.Add(ufp[i]);
                 end;
             end;
             for i:=1 to length(bea_nam)-1 do begin
                 if bea_nam[i]=t0[28] then begin
                    ListBox12.Items.Add('VDI'+bea_vdi[i]);
                 end;
             end;
          end;

          //read Z from Geo_Mach
          if t0[0]='E' then begin
             ListBox6.Items.Add(t0[18]);
          end;

          //read eroding direction from StartPoint
          if t0[0]='I' then begin
              sp_x:=strtofloat(t0[2]);
              sp_y:=strtofloat(t0[3]);
              sp_z:=strtofloat(trim(t0[4]));
              if ((sp_z > abs(sp_x)) and (sp_z > abs(sp_y))) then begin //z
                  ListBox9.Items.Add('Z');
                  ListBox11.Items.Add(floattostr(sp_z));
              end
              else if abs(sp_x) > abs(sp_y) then begin //x
                  if sp_x > 0 then ListBox9.Items.Add('X+')
                  else ListBox9.Items.Add('X-');
                  ListBox11.Items.Add(floattostr(abs(sp_x)));
              end
              else begin //y
                  if sp_y > 0 then ListBox9.Items.Add('Y+')
                  else ListBox9.Items.Add('Y-');
                  ListBox11.Items.Add(floattostr(abs(sp_y)));
              end;
              //fill a and b according to eroding direction
          case ListBox9.Items[ListBox9.Items.Count-1] of
               'Z': begin
                   ListBox14.Items.Add('0');
                   ListBox15.Items.Add('0');
               end;
               'X+': begin
                   ListBox14.Items.Add('90');
                   ListBox15.Items.Add('0');
               end;
               'X-': begin
                   ListBox14.Items.Add('90');
                   ListBox15.Items.Add('180');
               end;
               'Y+': begin
                   ListBox14.Items.Add('90');
                   ListBox15.Items.Add('90');
               end;
               'Y-': begin
                   ListBox14.Items.Add('90');
                   ListBox15.Items.Add('270');
               end;
          end;
          end;
         until eof(fil);
         CloseFile(fil);
         //fill in form2
         //showmessage('ok2');
         for i:=0 to length(el_pos)-1 do begin
             //CheckboxList1
              Form2.CheckListBox1.Items.Add(uele[i+1]);
              Form2.CheckListBox1.Checked[(Form2.CheckListBox1.Count-1)]:=True;
             //ListBox1
             el_str:=uele[i+1]+';'+agie_elmat_to_str(uemat[i+1])+';'+ufp[i+1]+';';
             for j:=0 to length(el_um[i])-1 do begin
                 el_str:=el_str+el_um[i][j]+';';
             end;
             for j:=length(el_um[i]) to 5 do begin
                 el_str:=el_str+'0;';
             end;
             for j:=0 to length(el_pos[i])-1 do begin
                 el_str:=el_str+el_pos[i][j]+';';
             end;
             for j:=length(el_pos[i]) to 5 do begin
                 el_str:=el_str+'0;';
             end;
             el_str:=el_str+uele[i+1]+';0;Z;3;0;VDI'+bea_vdi[1];
             Form2.ListBox1.Items.Add(el_str);
             //If mes exists, also Listbox2 ?
         end;
         logToFile(Application.Location,'OK Loaded file '+OpenDialog5.FileName);
     end
     else begin
         logToFile(Application.Location,'ERR Tried to open wrong file type');
         ShowMessage('Wrong file type');
     end;
     Button7.Enabled:=True;
  end;
end;

procedure TForm1.MenuItem17Click(Sender: TObject);
begin

end;

procedure TForm1.MenuItem19Click(Sender: TObject);
begin
  BitBtn5.Click;
end;


procedure TForm1.MenuItem1Click(Sender: TObject);
//var ust:TIniFile;
begin
  logToFile(Application.Location,'OK opened settings');
   // open new form with settings
   Form3.ShowModal;
   if Form3.ModalResult=mrOk then begin
       Label25.Caption:=Form3.LabeledEdit23.Text;
       Label31.Caption:=Label25.Caption;
       //shuffle_buttons;
   end;
end;

procedure TForm1.MenuItem20Click(Sender: TObject);
begin
  BitBtn9.Click;
end;

procedure TForm1.MenuItem21Click(Sender: TObject);
begin
  BitBtn6.Click;
end;

procedure TForm1.MenuItem22Click(Sender: TObject);
begin

end;

procedure TForm1.MenuItem23Click(Sender: TObject);
begin
  Form14.ShowModal; //electrode stats
end;

procedure TForm1.MenuItem24Click(Sender: TObject);
var nam:string;
i:integer;
l,l0,l1:TArrayOfString;

begin
  if OpenDialog6.Execute then begin
     Memo10.Lines.LoadFromFile(OpenDialog6.FileName);
     Form15.ListBox1.Clear;
     Form15.ListBox2.Clear;
     Form15.ListBox3.Clear;
     Form15.ListBox4.Clear;

     for i:=0 to Memo10.Lines.Count-1 do begin
         if AnsiContainsStr(Memo10.Lines[i],'<part SysId="') then begin
            l:=SplitString('"',Memo10.Lines[i]);
            nam:=l[3];
            if AnsiContainsStr(nam,'EL-FR') then Form15.ListBox4.Items.Add(nam)
            else if AnsiContainsStr(nam,'BG-EL') then Form15.ListBox2.Items.Add(nam)
            else Form15.ListBox1.Items.Add(nam);
         end;
     end;
     //if only 1 remaining available and 0 workpieces, assume its a workpiece
     if ((Form15.ListBox1.Items.Count=1) and (Form15.ListBox3.Items.Count=0)) then begin
        Form15.ListBox3.Items.Add(Form15.ListBox1.Items[0]);
        Form15.ListBox1.Items.Delete(0);
     end;

     if Form15.ShowModal=mrOk then begin
         Edit3.Text:=Form15.ListBox3.Items[0];
         if not FileExists(OpenDialog6.InitialDir+Edit3.Text+'.neu') then showmessage('Error, file not found.');

     end;
  end;
end;

procedure TForm1.MenuItem25Click(Sender: TObject);
begin
  if OpenDialog7.Execute then begin
     load_hypercad(OpenDialog7.FileName);
  end;
end;

procedure TForm1.MenuItem26Click(Sender: TObject);
begin
    //new api specifically for this function is needed
    //becouse object may be old - i don't want to run background updates
    // put_request.txt
end;

procedure TForm1.MenuItem28Click(Sender: TObject);
begin
   MessageDlg('Szczegółowe dane o zleceniu '+Form1.Label33.Caption,msg_details,mtInformation,[mbOk],0);
end;

procedure TForm1.MenuItem29Click(Sender: TObject);
var i:integer;
l:TArrayOfString;
sl:TStringList;
outv:string;
begin

  if OpenDialog8.Execute then begin
  //setLength(nxc,0);
     Memo14.Lines.LoadFromFile(OpenDialog8.FileName);

     for i:=0 to Memo14.Lines.Count-1 do begin
         //showmessage(inttostr(i));
         //showmessage(Memo14.Lines[i]);
         l:=SplitString(',',Memo14.Lines[i]);
         //showmessage(l[0]);
         if l[0]<>'Name' then FormZ.ListBox1.Items.Add(l[0]);
     end;
     //showmessage('pasi filling listbox');
     if FormZ.ShowModal = mrOk then begin
     //showmessage('showmodal = mrOk');
         outv:=ConvertToRelativeCoords(Memo14.Lines.Text,FormZ.ListBox1.Items[FormZ.ListBox1.ItemIndex]);
     sl:=tStringList.Create;
     sl.Text:=outv;
     for i:=0 to sl.Count-1 do begin
         //showmessage(sl[i]);
         l:=SplitString(',',sl[i]);
         ListBox2.Items.Add(l[0]); //el name
         ListBox3.Items.Add(l[1]); //x
         ListBox4.Items.Add(l[2]); //y
         ListBox6.Items.Add(l[3]); //z
         ListBox5.Items.Add(l[4]); //
         ListBox7.Items.Add('Graphite1');
         ListBox8.Items.Add('0');
         ListBox9.Items.Add('Z');
         ListBox11.Items.Add('10');
         ListBox12.Items.Add('VDI24');
         ListBox14.Items.Add('0');
         ListBox15.Items.Add('0');
     end;
     end;


     //showmessage(outv);
  end;
  //showmessage('Not implemented yet');

end;

procedure TForm1.MenuItem30Click(Sender: TObject);
begin
  if OpenDialog4.Execute then load_ncvisu_csv(OpenDialog4.FileName);
end;

procedure TForm1.MenuItem3Click(Sender: TObject);
var str,lang,datesep:string;
  ust:TIniFile;
  //dt:TDateTime;
  //l:TArrayOfString;
begin
  logToFile(Application.Location,'OK About Form shown');
  ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));

  lang:=ust.ReadString('settings','lang','PL');
  Form4.Label1.Caption:=DataModule1.getString(lang,82)+' '+sw_ver+'.'+sw_ver_minor+' (2026-10-14)';
  Form4.Label2.Caption:=DataModule1.getString(lang,83);
  Form4.Caption:=DataModule1.getString(lang,84);
  ust.Free;
  Form4.ShowModal; //about
end;

procedure TForm1.MenuItem4Click(Sender: TObject);
begin
  logToFile(Application.Location,'INF Help Form shown');
   //TODO: Change to .chm
   //wontfix 20220315
  Form5.ShowModal;
end;

procedure TForm1.MenuItem7Click(Sender: TObject);
begin

end;

procedure TForm1.MenuItem8Click(Sender: TObject);
var ust:TIniFile;
  lang:string;
begin
  //do if condition asking for save
  ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
  lang:=ust.ReadString('settings','lang','PL');
  ust.Free;
  if CheckBox6.Checked then begin
     if CheckBox5.Checked then Form8.Label1.Caption:=DataModule1.getString(lang,96)+SaveDialog1.FileName+DataModule1.getString(lang,97)
     else Form8.Label1.Caption:=DataModule1.getString(lang,98);
     if Form8.ShowModal=mrOK then MenuItem13Click(Form1)
     else logToFile(Application.Location,'INF Program was not saved ('+Edit3.Text+')');
  end;
  Form1.ListBox1.Clear;
     Form1.ListBox2.Clear;
     Form1.ListBox3.Clear;
     Form1.ListBox4.Clear;
     Form1.ListBox5.Clear;
     Form1.ListBox6.Clear;
     Form1.ListBox7.Clear;
     Form1.ListBox8.Clear;
     Form1.ListBox9.Clear;
     Form1.ListBox11.Clear;
     Form1.ListBox12.Clear;
     Form1.ListBox14.Clear;
     Form1.ListBox15.Clear;
     Form2.ListBox1.Clear;
     Form2.ListBox2.Clear;
     Form2.CheckListBox1.Clear;
     Form1.Memo1.Clear;
     Form1.Edit3.Text:=''; //program name
     Form1.LabeledEdit1.Text:='1,2'; //x400 magpos
     Form1.Edit16.Text:='1-0'; //edm no
     Form1.CheckBox8.Checked:=True; //dodaj skaner
     Form1.CheckBox3.Checked:=False; //utwórz grupe
     Form1.Edit19.Text:='';
     Form1.Edit20.Text:='';
     if Sender<>Form1 then logToFile(Application.Location,'OK Created new empty program');
     setChanged(false);

end;

procedure TForm1.MenuItem9Click(Sender: TObject);
begin
  logToFile(Application.Location,'INF clicked open file button manually');
  OpenDialog1.Execute;
  end_table_line:=0;
  CheckBox2.Checked:=False;
  Button1.Click;
end;

procedure TForm1.nospaces(Sender: TObject; var Key: Word; Shift: TShiftState);
var ust:TIniFile;
  path:string;
begin
  if (AnsiContainsStr((Sender as TEdit).Text,'-') or AnsiContainsStr((Sender as TEdit).Text,' ')) then begin
     (Sender as TEdit).Text:=StringReplace((Sender as TEdit).Text,' ','_',[rfReplaceAll]);
     (Sender as TEdit).Text:=StringReplace((Sender as TEdit).Text,'-','_',[rfReplaceAll]);
     (Sender as TEdit).SelStart:=high(Integer);
   end;
   if length((Sender as TEdit).Text)>1 then begin
   ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
   path:=ust.ReadString('settings','pathOutput','C:\Intel\LazarusPortable\dxf test\output');
   Label17.Visible:=directoryExists(path+'\'+Edit3.Text);
   ust.Free;
   setChanged(True);
   end;
end;

procedure TForm1.onlyNum(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if isOnlyNumber((Sender as TEdit).Text) then begin
      (Sender as TEdit).Color:=clDefault;
      BitBtn6.Enabled:=true;
  end
  else begin
      (Sender as TEdit).Color:=clRed;
      BitBtn6.Enabled:=false;
  end;
end;

procedure TForm1.PageControl1Change(Sender: TObject);
var ust:TIniFile;
begin
      ust:=TIniFile.Create(ChangeFileExt(Application.ExeName,'.ini'));
      ust.WriteInteger('form','page',PageControl1.PageIndex);
      ust.Free;
end;

procedure TForm1.resizemainf(Sender: TObject);
begin
     if not sizeset then begin
        Form1.Width:=1302;
        Form1.Height:=481;
        sizeset:=true;
     end;
    if Form1.Width<1140 then Form1.Width:=1302;
    if Form1.Height<481 then Form1.Height:=481;
    Form1.ListBox2.Height:=Form1.Height-141;
    Form1.ListBox3.Height:=Form1.Height-141;
    Form1.ListBox4.Height:=Form1.Height-141;
    Form1.ListBox5.Height:=Form1.Height-141;
    Form1.ListBox6.Height:=Form1.Height-141;
    Form1.ListBox7.Height:=Form1.Height-141;
    Form1.ListBox8.Height:=Form1.Height-141;
    Form1.ListBox9.Height:=Form1.Height-141;
    Form1.ListBox11.Height:=Form1.Height-141;
    Form1.ListBox12.Height:=Form1.Height-141;
    Form1.ListBox14.Height:=Form1.Height-141;
    Form1.ListBox15.Height:=Form1.Height-141;
    Form1.Button4.Top:=Form1.Height-84;
    Form1.Label14.Top:=Form1.Height-76;
    Form1.Label15.Top:=Form1.Height-76;

    Button10.Top:=Form1.Height-45;
    Button5.Top:=Button10.Top-20;
    Button9.Top:=Button10.Top-20;
    Button12.Top:=Button10.Top-20;

    Button11.Top:=Button10.Top-40;
    Button13.Top:=Button11.Top;
    //showmessage('resize ok');
end;

procedure TForm1.sds(Sender: TObject);
begin
  //showmessage('ok2');
end;

procedure TForm1.setchmathod(Sender: TObject);
begin
  setChanged(true);
end;

initialization
{$I myres.lrs}


end.

