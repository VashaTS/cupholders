unit Unit19;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls,
  ExtCtrls;

type

  { TForm17 }

  TForm17 = class(TForm)
    Button1: TButton;
    PaintBox1: TPaintBox;
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form17: TForm17;

implementation

{$R *.lfm}

end.

